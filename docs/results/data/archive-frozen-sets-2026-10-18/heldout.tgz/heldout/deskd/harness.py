"""Harness for the held-out grpc-go app ``deskd`` (Spike I, section 5): a helpdesk served over
gRPC on pure-Go SQLite (GORM + github.com/glebarez/sqlite, no cgo, no Docker).

What it gives the process runtime:

``make_app(db_path)``
    a :class:`~lattice.spec.process.ProcessApp` (not started) running the ``deskd`` binary
    with ``PORT`` and ``DB_PATH`` set. One port carries gRPC (HTTP/2 prior knowledge) and a
    plain HTTP page ``GET /healthz`` (200 once the database answers), so the app is ready
    under today's HTTP health wait and under ``ready="grpc"`` (``grpc.health.v1.Health/Check``
    answers ``SERVING``) once the process runtime has that field. ``DESKD_READY=grpc`` asks for
    the latter; it is ignored when ``ProcessApp`` has no ``ready`` field.
``build_db(path)``
    writes the schema and the seed rows (two members, their sessions, two queues).
``RUNTIME``
    ``process_runtime(framework="go", auth=...)``. Callers are logged in by the rpc
    ``desk.v1.Identity/SignIn`` when ``AuthDriver.rpc`` exists (see ``RPC_LOGIN``), else by a
    minter answering the seeded session tokens (``TOKENS``); either way the token travels as
    metadata ``authorization: Bearer <token>``.

The binary: ``$LATTICE_HELDOUT_DESKD_BIN`` if set, else built once per source hash with
``go build -trimpath -buildvcs=false -mod=readonly`` into ``$LATTICE_HELDOUT_BUILD`` (default: a
directory under the system temp dir). Nothing is written under the app's own root.
"""

from __future__ import annotations

import dataclasses
import hashlib
import inspect
import os
import shutil
import sqlite3
import subprocess
import tempfile
import threading
from pathlib import Path

from lattice.importer.transport import AuthDriver
from lattice.spec.process import ProcessApp, process_runtime

APP_ROOT = Path(__file__).resolve().parent
MAIN_PACKAGE = "./cmd/deskd"
BINARY_ENV = "LATTICE_HELDOUT_DESKD_BIN"
BUILD_ENV = "LATTICE_HELDOUT_BUILD"
READY_ENV = "DESKD_READY"
HEALTH_PATH = "/healthz"

# The contract: project-relative .proto paths and their include root.
PROTOS = (
    "proto/desk/v1/common.proto",
    "proto/desk/v1/identity.proto",
    "proto/desk/v1/queues.proto",
    "proto/desk/v1/tickets.proto",
    "proto/desk/v1/reports.proto",
)
PROTO_PATHS = ("proto",)

# handle -> (login handle, passphrase); the passphrases are stored as sha256 hex.
USERS = {"ann": ("ann", "pw-ann-123"), "ben": ("ben", "pw-ben-123")}
# Seeded sessions (access_tokens rows), one per user.
TOKENS = {"ann": "tok-ann", "ben": "tok-ben"}
# ann is a member, ben an agent (only agents close tickets or write internal remarks).
ROLES = {"ann": "member", "ben": "agent"}

# How a caller logs in by rpc: SignIn {handle, passphrase} -> {session_token, member}.
RPC_LOGIN = {
    "service": "desk.v1.Identity",
    "method": "SignIn",
    "username_field": "handle",
    "password_field": "passphrase",
    "token_field": "session_token",
}

_build_lock = threading.Lock()


def _source_hash() -> str:
    h = hashlib.sha256()
    for p in sorted(APP_ROOT.rglob("*")):
        if p.is_file() and (p.suffix in {".go", ".proto"} or p.name in {"go.mod", "go.sum"}):
            h.update(p.relative_to(APP_ROOT).as_posix().encode() + b"\0")
            h.update(p.read_bytes() + b"\0")
    return h.hexdigest()[:16]


def binary() -> str:
    """The ``deskd`` binary: ``$LATTICE_HELDOUT_DESKD_BIN``, else built (once per source hash)."""
    given = os.environ.get(BINARY_ENV)
    if given:
        return given
    base = Path(os.environ.get(BUILD_ENV) or Path(tempfile.gettempdir()) / "lattice-heldout-deskd")
    out = base / _source_hash() / "deskd"
    with _build_lock:
        if not out.exists():
            go = shutil.which("go") or "/usr/local/go/bin/go"
            out.parent.mkdir(parents=True, exist_ok=True)
            tmp = out.with_suffix(".tmp")
            subprocess.run(
                [
                    go,
                    "build",
                    "-trimpath",
                    "-buildvcs=false",
                    "-mod=readonly",
                    "-o",
                    str(tmp),
                    MAIN_PACKAGE,
                ],
                cwd=APP_ROOT,
                check=True,
                capture_output=True,
            )
            tmp.replace(out)
    return str(out)


def make_app(db_path: Path) -> ProcessApp:
    """``deskd`` on ``db_path`` (not started)."""
    kwargs: dict = {
        "db_path": db_path,
        "env": {},
        "health_path": HEALTH_PATH,
        "startup_timeout": 30.0,
    }
    fields = {f.name for f in dataclasses.fields(ProcessApp)}
    if os.environ.get(READY_ENV) == "grpc" and "ready" in fields:
        kwargs["ready"] = "grpc"
    return ProcessApp([binary()], **kwargs)


def _auth() -> AuthDriver:
    rpc = getattr(AuthDriver, "rpc", None)
    if rpc is not None:
        params = inspect.signature(rpc).parameters
        extra = {
            k: RPC_LOGIN[k]
            for k in ("username_field", "password_field", "token_field")
            if k in params
        }
        try:
            return rpc(RPC_LOGIN["service"], RPC_LOGIN["method"], USERS, **extra)
        except TypeError:
            pass
    return AuthDriver(mint=TOKENS.__getitem__)


RUNTIME = process_runtime(framework="go", auth=_auth())

# The schema, as GORM maps the structs of internal/repo/models.go.
DDL = """
CREATE TABLE members (
    id INTEGER PRIMARY KEY,
    handle TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL,
    pass_hash TEXT NOT NULL,
    display_name TEXT,
    role TEXT NOT NULL DEFAULT 'member'
);
CREATE TABLE access_tokens (
    token TEXT PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES members(id)
);
CREATE TABLE queues (
    id INTEGER PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    is_open NUMERIC NOT NULL
);
CREATE TABLE tickets (
    id INTEGER PRIMARY KEY,
    queue_id INTEGER NOT NULL REFERENCES queues(id),
    reporter_id INTEGER NOT NULL REFERENCES members(id),
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    priority INTEGER NOT NULL,
    state TEXT NOT NULL,
    labels TEXT NOT NULL,
    attrs TEXT NOT NULL,
    resolution TEXT,
    reopen_count INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME,
    updated_at DATETIME
);
CREATE TABLE ticket_notes (
    id INTEGER PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    author_id INTEGER NOT NULL REFERENCES members(id),
    text TEXT NOT NULL,
    internal NUMERIC NOT NULL
);
"""

QUEUES = (("billing", "Billing questions", 1), ("legacy", "Legacy products (shut)", 0))


def build_db(path: Path) -> Path:
    """A fresh database at ``path``: the schema, members ann (id 1) and ben (id 2), their
    sessions, and queues ``billing`` (open, id 1) and ``legacy`` (shut, id 2)."""
    conn = sqlite3.connect(path)
    try:
        conn.executescript(DDL)
        for i, (h, (name, pw)) in enumerate(USERS.items(), 1):
            digest = hashlib.sha256(pw.encode()).hexdigest()
            conn.execute(
                "INSERT INTO members (id, handle, email, pass_hash, display_name, role)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (i, name, f"{name}@example.org", digest, name.title(), ROLES[h]),
            )
            conn.execute(
                "INSERT INTO access_tokens (token, member_id) VALUES (?, ?)", (TOKENS[h], i)
            )
        for i, (slug, title, is_open) in enumerate(QUEUES, 1):
            conn.execute(
                "INSERT INTO queues (id, slug, title, is_open) VALUES (?, ?, ?, ?)",
                (i, slug, title, is_open),
            )
        conn.commit()
    finally:
        conn.close()
    return path
