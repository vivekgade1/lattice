// deskd is a small helpdesk served over gRPC (unary, plus one server stream) on pure-Go
// SQLite. One port carries both gRPC and a plain HTTP health page (GET /healthz).
//
// Environment: PORT (default 7400), DB_PATH (the SQLite file; its tables are created by the
// caller, or by the server itself when DESK_MIGRATE=1).
package main

import (
	"context"
	"errors"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/health"
	healthpb "google.golang.org/grpc/health/grpc_health_v1"

	"example.org/deskd/internal/gate"
	"example.org/deskd/internal/repo"
	"example.org/deskd/internal/svc"
	"example.org/deskd/internal/wire"
)

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "7400"
	}
	path := os.Getenv("DB_PATH")
	if path == "" {
		log.Fatal("DB_PATH is not set")
	}
	db, err := repo.Open(path)
	if err != nil {
		log.Fatalf("open %s: %v", path, err)
	}
	if os.Getenv("DESK_MIGRATE") == "1" {
		if err := repo.Migrate(db); err != nil {
			log.Fatalf("migrate: %v", err)
		}
	}
	raw, err := db.DB()
	if err != nil {
		log.Fatal(err)
	}
	raw.SetMaxOpenConns(1)

	keeper := gate.NewKeeper(db)
	server := grpc.NewServer(grpc.UnaryInterceptor(keeper.Check), grpc.StreamInterceptor(keeper.CheckStream))
	svc.Mount(server, db)
	healthpb.RegisterHealthServer(server, health.NewServer())

	lis, err := net.Listen("tcp", "127.0.0.1:"+port)
	if err != nil {
		log.Fatal(err)
	}
	split := wire.NewSplit(lis)
	pages := http.NewServeMux()
	pages.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) {
		if err := raw.PingContext(r.Context()); err != nil {
			http.Error(w, "database unavailable", http.StatusServiceUnavailable)
			return
		}
		_, _ = w.Write([]byte("ok\n"))
	})
	web := &http.Server{Handler: pages, ReadHeaderTimeout: 5 * time.Second}
	go func() {
		if err := server.Serve(split.GRPC()); err != nil && !errors.Is(err, grpc.ErrServerStopped) {
			log.Printf("grpc: %v", err)
		}
	}()
	go func() {
		if err := web.Serve(split.HTTP()); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Printf("http: %v", err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGTERM, syscall.SIGINT)
	<-stop
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	_ = web.Shutdown(ctx)
	done := make(chan struct{})
	go func() { server.GracefulStop(); close(done) }()
	select {
	case <-done:
	case <-ctx.Done():
		server.Stop()
	}
	_ = split.Close()
}
