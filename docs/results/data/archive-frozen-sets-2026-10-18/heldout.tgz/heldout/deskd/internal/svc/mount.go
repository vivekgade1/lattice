package svc

import (
	"google.golang.org/grpc"
	"gorm.io/gorm"

	"example.org/deskd/internal/deskpb"
)

// Mount registers the helpdesk's services on s. desk.v1.Reports is declared in the protos
// but deliberately not served.
func Mount(s *grpc.Server, db *gorm.DB) {
	deskpb.RegisterIdentityServer(s, NewIdentity(db))
	s.RegisterService(&deskpb.Queues_ServiceDesc, queueDesk{db: db})
	deskpb.RegisterTicketsServer(s, NewTickets(db))
}
