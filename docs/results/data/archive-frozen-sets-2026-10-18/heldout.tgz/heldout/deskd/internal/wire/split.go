// Package wire serves gRPC and a plain HTTP health page on one TCP port: a connection that
// opens with the HTTP/2 preface goes to the gRPC server, any other to the HTTP server.
package wire

import (
	"bufio"
	"bytes"
	"net"
	"sync"
	"time"
)

var preface = []byte("PRI * HTTP/2")

// Split divides one listener into two.
type Split struct {
	root  net.Listener
	h2    *side
	plain *side
	once  sync.Once
}

// NewSplit starts dividing root's connections.
func NewSplit(root net.Listener) *Split {
	s := &Split{root: root, h2: newSide(root.Addr()), plain: newSide(root.Addr())}
	go s.loop()
	return s
}

// GRPC is the listener of HTTP/2 connections.
func (s *Split) GRPC() net.Listener { return s.h2 }

// HTTP is the listener of every other connection.
func (s *Split) HTTP() net.Listener { return s.plain }

// Close stops both sides.
func (s *Split) Close() error {
	s.once.Do(func() { s.h2.shut(); s.plain.shut() })
	return s.root.Close()
}

func (s *Split) loop() {
	for {
		c, err := s.root.Accept()
		if err != nil {
			s.once.Do(func() { s.h2.shut(); s.plain.shut() })
			return
		}
		go s.route(c)
	}
}

func (s *Split) route(c net.Conn) {
	_ = c.SetReadDeadline(time.Now().Add(10 * time.Second))
	br := bufio.NewReader(c)
	head, err := br.Peek(len(preface))
	_ = c.SetReadDeadline(time.Time{})
	if err != nil && len(head) == 0 {
		_ = c.Close()
		return
	}
	pc := &peeked{Conn: c, r: br}
	if bytes.Equal(head, preface) {
		s.h2.put(pc)
	} else {
		s.plain.put(pc)
	}
}

type peeked struct {
	net.Conn
	r *bufio.Reader
}

func (p *peeked) Read(b []byte) (int, error) { return p.r.Read(b) }

type side struct {
	addr  net.Addr
	conns chan net.Conn
	done  chan struct{}
	once  sync.Once
}

func newSide(addr net.Addr) *side {
	return &side{addr: addr, conns: make(chan net.Conn), done: make(chan struct{})}
}

func (s *side) put(c net.Conn) {
	select {
	case s.conns <- c:
	case <-s.done:
		_ = c.Close()
	}
}

func (s *side) shut() { s.once.Do(func() { close(s.done) }) }

func (s *side) Accept() (net.Conn, error) {
	select {
	case c := <-s.conns:
		return c, nil
	case <-s.done:
		return nil, net.ErrClosed
	}
}

func (s *side) Close() error   { s.shut(); return nil }
func (s *side) Addr() net.Addr { return s.addr }
