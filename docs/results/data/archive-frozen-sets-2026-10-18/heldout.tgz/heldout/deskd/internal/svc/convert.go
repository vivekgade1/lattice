package svc

import (
	"encoding/json"

	"google.golang.org/protobuf/types/known/timestamppb"

	"example.org/deskd/internal/deskpb"
	"example.org/deskd/internal/repo"
)

var stateOut = map[string]deskpb.TicketState{
	repo.StateOpen:     deskpb.TicketState_TICKET_STATE_OPEN,
	repo.StatePending:  deskpb.TicketState_TICKET_STATE_PENDING,
	repo.StateResolved: deskpb.TicketState_TICKET_STATE_RESOLVED,
	repo.StateClosed:   deskpb.TicketState_TICKET_STATE_CLOSED,
}

var stateIn = map[deskpb.TicketState]string{
	deskpb.TicketState_TICKET_STATE_OPEN:     repo.StateOpen,
	deskpb.TicketState_TICKET_STATE_PENDING:  repo.StatePending,
	deskpb.TicketState_TICKET_STATE_RESOLVED: repo.StateResolved,
	deskpb.TicketState_TICKET_STATE_CLOSED:   repo.StateClosed,
}

func memberOut(m *repo.Member) *deskpb.Member {
	return &deskpb.Member{Id: m.ID, Handle: m.Handle, Email: m.Email, DisplayName: m.DisplayName, Role: m.Role}
}

func queueOut(q *repo.Queue) *deskpb.Queue {
	return &deskpb.Queue{Id: q.ID, Slug: q.Slug, Title: q.Title, IsOpen: q.IsOpen}
}

func remarkOut(r *repo.Remark) *deskpb.Remark {
	return &deskpb.Remark{Id: r.ID, TicketId: r.TicketID, AuthorId: r.AuthorID, Text: r.Text, Internal: r.Internal}
}

func ticketOut(t *repo.Ticket, slug string, remarks int64) *deskpb.Ticket {
	out := &deskpb.Ticket{
		Id:          t.ID,
		QueueSlug:   slug,
		ReporterId:  t.ReporterID,
		Subject:     t.Subject,
		Body:        t.Body,
		Priority:    deskpb.Priority(t.Priority),
		State:       stateOut[t.State],
		Resolution:  t.Resolution,
		ReopenCount: t.ReopenCount,
		Counts:      &deskpb.Ticket_Counts{Remarks: int32(remarks)},
		CreatedAt:   timestamppb.New(t.CreatedAt),
		UpdatedAt:   timestamppb.New(t.UpdatedAt),
	}
	_ = json.Unmarshal([]byte(t.Labels), &out.Labels)
	_ = json.Unmarshal([]byte(t.Attrs), &out.Attrs)
	if out.Labels == nil {
		out.Labels = []string{}
	}
	return out
}
