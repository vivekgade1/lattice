// Package gate is the server's session check: one unary interceptor (and its stream twin)
// that lets a fixed set of methods through and asks every other call for a session token.
package gate

import (
	"context"
	"strings"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"gorm.io/gorm"

	"example.org/deskd/internal/deskpb"
	"example.org/deskd/internal/fault"
	"example.org/deskd/internal/repo"
)

type callerKey struct{}

// Keeper checks sessions against the access_tokens table.
type Keeper struct {
	db *gorm.DB
}

// NewKeeper answers the session check over db.
func NewKeeper(db *gorm.DB) *Keeper { return &Keeper{db: db} }

// Check is the unary interceptor.
func (k *Keeper) Check(ctx context.Context, req any, info *grpc.UnaryServerInfo, next grpc.UnaryHandler) (any, error) {
	switch info.FullMethod {
	case deskpb.Identity_SignUp_FullMethodName,
		deskpb.Identity_SignIn_FullMethodName,
		deskpb.Queues_ListQueues_FullMethodName,
		deskpb.Queues_GetQueue_FullMethodName,
		"/grpc.health.v1.Health/Check":
		return next(ctx, req)
	}
	who, err := k.lookup(ctx)
	if err != nil {
		return nil, err
	}
	return next(context.WithValue(ctx, callerKey{}, who), req)
}

// CheckStream is the stream interceptor (every stream needs a session).
func (k *Keeper) CheckStream(srv any, ss grpc.ServerStream, info *grpc.StreamServerInfo, next grpc.StreamHandler) error {
	if info.FullMethod == "/grpc.health.v1.Health/Watch" {
		return next(srv, ss)
	}
	who, err := k.lookup(ss.Context())
	if err != nil {
		return err
	}
	return next(srv, &withCaller{ServerStream: ss, ctx: context.WithValue(ss.Context(), callerKey{}, who)})
}

func (k *Keeper) lookup(ctx context.Context) (*repo.Member, error) {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return nil, status.Error(codes.Unauthenticated, "no metadata")
	}
	vals := md.Get("authorization")
	if len(vals) == 0 {
		return nil, status.Error(codes.Unauthenticated, "no authorization")
	}
	scheme, token, found := strings.Cut(vals[0], " ")
	if !found || !strings.EqualFold(scheme, "bearer") || token == "" {
		return nil, status.Error(codes.Unauthenticated, "bad authorization")
	}
	var cred repo.Credential
	if err := k.db.WithContext(ctx).Where("token = ?", token).Take(&cred).Error; err != nil {
		return nil, status.Error(codes.Unauthenticated, "unknown session")
	}
	var m repo.Member
	if err := k.db.WithContext(ctx).Take(&m, cred.MemberID).Error; err != nil {
		return nil, status.Error(codes.Unauthenticated, "unknown member")
	}
	return &m, nil
}

type withCaller struct {
	grpc.ServerStream
	ctx context.Context
}

func (w *withCaller) Context() context.Context { return w.ctx }

// Caller is the signed-in member of ctx.
func Caller(ctx context.Context) (*repo.Member, error) {
	m, ok := ctx.Value(callerKey{}).(*repo.Member)
	if !ok || m == nil {
		return nil, fault.Anonymous()
	}
	return m, nil
}

// TokenOf is the bearer token the call carried ("" if none).
func TokenOf(ctx context.Context) string {
	md, _ := metadata.FromIncomingContext(ctx)
	vals := md.Get("authorization")
	if len(vals) == 0 {
		return ""
	}
	_, token, _ := strings.Cut(vals[0], " ")
	return token
}
