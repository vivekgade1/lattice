package svc

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strings"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/emptypb"
	"gorm.io/gorm"

	"example.org/deskd/internal/deskpb"
	"example.org/deskd/internal/fault"
	"example.org/deskd/internal/gate"
	"example.org/deskd/internal/repo"
)

// IdentityService serves desk.v1.Identity.
type IdentityService struct {
	deskpb.UnimplementedIdentityServer
	db *gorm.DB
}

// NewIdentity answers the Identity service over db.
func NewIdentity(db *gorm.DB) *IdentityService { return &IdentityService{db: db} }

func digest(pass string) string {
	sum := sha256.Sum256([]byte(pass))
	return hex.EncodeToString(sum[:])
}

func (s *IdentityService) SignUp(ctx context.Context, in *deskpb.SignUpRequest) (*deskpb.Member, error) {
	handle := strings.TrimSpace(in.GetHandle())
	if len(handle) < 3 || len(handle) > 32 {
		return nil, fault.Bad("handle", "3 to 32 characters")
	}
	if !strings.Contains(in.GetEmail(), "@") {
		return nil, fault.Bad("email", "not an address")
	}
	if len(in.GetPassphrase()) < 8 {
		return nil, fault.Bad("passphrase", "at least 8 characters")
	}
	var n int64
	s.db.WithContext(ctx).Model(&repo.Member{}).Where("handle = ?", handle).Count(&n)
	if n > 0 {
		return nil, fault.Taken("handle")
	}
	m := repo.Member{Handle: handle, Email: in.GetEmail(), PassHash: digest(in.GetPassphrase()),
		DisplayName: in.GetDisplayName(), Role: "member"}
	if err := s.db.WithContext(ctx).Create(&m).Error; err != nil {
		return nil, fmt.Errorf("sign up: %w", err)
	}
	return memberOut(&m), nil
}

func (s *IdentityService) SignIn(ctx context.Context, in *deskpb.SignInRequest) (*deskpb.SignInReply, error) {
	if in.GetHandle() == "" || in.GetPassphrase() == "" {
		return nil, fault.Bad("handle", "handle and passphrase are required")
	}
	var m repo.Member
	err := s.db.WithContext(ctx).Where("handle = ? AND pass_hash = ?", in.GetHandle(), digest(in.GetPassphrase())).
		Take(&m).Error
	if err != nil {
		return nil, status.New(codes.Unauthenticated, "wrong handle or passphrase").Err()
	}
	raw := make([]byte, 16)
	if _, err := rand.Read(raw); err != nil {
		return nil, status.Error(codes.Internal, "no entropy")
	}
	cred := repo.Credential{Token: hex.EncodeToString(raw), MemberID: m.ID}
	if err := s.db.WithContext(ctx).Create(&cred).Error; err != nil {
		return nil, fault.Store(err, "session")
	}
	return &deskpb.SignInReply{SessionToken: cred.Token, Member: memberOut(&m)}, nil
}

func (s *IdentityService) WhoAmI(ctx context.Context, _ *emptypb.Empty) (*deskpb.Member, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	return memberOut(me), nil
}

func (s *IdentityService) SignOut(ctx context.Context, _ *emptypb.Empty) (*emptypb.Empty, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	res := s.db.WithContext(ctx).Where("token = ? AND member_id = ?", gate.TokenOf(ctx), me.ID).Delete(&repo.Credential{})
	if res.Error != nil {
		return nil, fault.Store(res.Error, "session")
	}
	return &emptypb.Empty{}, nil
}
