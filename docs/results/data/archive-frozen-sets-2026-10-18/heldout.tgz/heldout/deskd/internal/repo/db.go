package repo

import (
	"example.org/deskd/internal/fault"
	"github.com/glebarez/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// Open opens the SQLite file at path.
func Open(path string) (*gorm.DB, error) {
	return gorm.Open(sqlite.Open(path+"?_pragma=foreign_keys(1)&_pragma=busy_timeout(5000)"),
		&gorm.Config{Logger: logger.Discard})
}

// Migrate creates the tables (used when DESK_MIGRATE=1; the test harness writes its own DDL).
func Migrate(db *gorm.DB) error {
	return db.AutoMigrate(&Member{}, &Credential{}, &Queue{})
}

// OwnedBy narrows a ticket query to the caller's own tickets.
func OwnedBy(memberID int64) func(*gorm.DB) *gorm.DB {
	return func(tx *gorm.DB) *gorm.DB {
		return tx.Where("tickets.reporter_id = ?", memberID)
	}
}

// QueueBySlug loads a queue; with open set, a shut queue is ErrQueueShut.
func QueueBySlug(db *gorm.DB, slug string, open bool) (*Queue, error) {
	var q Queue
	if err := db.Where("slug = ?", slug).First(&q).Error; err != nil {
		return nil, err
	}
	if open && !q.IsOpen {
		return nil, fault.ErrQueueShut
	}
	return &q, nil
}
