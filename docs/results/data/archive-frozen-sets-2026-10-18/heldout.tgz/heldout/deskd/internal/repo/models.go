// Package repo is the helpdesk's storage: GORM over pure-Go SQLite.
package repo

import "time"

// Member is an account.
type Member struct {
	ID          int64  `gorm:"column:id;primaryKey"`
	Handle      string `gorm:"column:handle;uniqueIndex;not null"`
	Email       string `gorm:"column:email;not null"`
	PassHash    string `gorm:"column:pass_hash;not null"`
	DisplayName string `gorm:"column:display_name"`
	Role        string `gorm:"column:role;not null;default:member"`
}

func (Member) TableName() string { return "members" }

// Credential is a session token.
type Credential struct {
	Token    string `gorm:"column:token;primaryKey"`
	MemberID int64  `gorm:"column:member_id;not null"`
}

func (Credential) TableName() string { return "access_tokens" }

// Queue is where tickets are filed.
type Queue struct {
	ID     int64  `gorm:"column:id;primaryKey"`
	Slug   string `gorm:"column:slug;uniqueIndex;not null"`
	Title  string `gorm:"column:title;not null"`
	IsOpen bool   `gorm:"column:is_open;not null"`
}

// Ticket is one request for help; State moves open -> pending -> resolved -> closed.
type Ticket struct {
	ID          int64     `gorm:"column:id;primaryKey"`
	QueueID     int64     `gorm:"column:queue_id;not null"`
	ReporterID  int64     `gorm:"column:reporter_id;not null"`
	Subject     string    `gorm:"column:subject;not null"`
	Body        string    `gorm:"column:body;not null"`
	Priority    int32     `gorm:"column:priority;not null"`
	State       string    `gorm:"column:state;not null"`
	Labels      string    `gorm:"column:labels;not null"`
	Attrs       string    `gorm:"column:attrs;not null"`
	Resolution  *string   `gorm:"column:resolution"`
	ReopenCount int32     `gorm:"column:reopen_count;not null"`
	CreatedAt   time.Time `gorm:"column:created_at"`
	UpdatedAt   time.Time `gorm:"column:updated_at"`
}

// Remark is a note on a ticket.
type Remark struct {
	ID       int64  `gorm:"column:id;primaryKey"`
	TicketID int64  `gorm:"column:ticket_id;not null"`
	AuthorID int64  `gorm:"column:author_id;not null"`
	Text     string `gorm:"column:text;not null"`
	Internal bool   `gorm:"column:internal;not null"`
}

func (Remark) TableName() string { return "ticket_notes" }

// Ticket states as stored.
const (
	StateOpen     = "open"
	StatePending  = "pending"
	StateResolved = "resolved"
	StateClosed   = "closed"
)
