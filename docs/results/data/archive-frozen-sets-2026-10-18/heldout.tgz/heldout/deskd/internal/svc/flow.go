package svc

import (
	"context"
	"fmt"
	"slices"
	"time"

	"gorm.io/gorm"

	"example.org/deskd/internal/fault"
	"example.org/deskd/internal/repo"
)

// everyone is the scope of a caller who may act on any ticket (an agent).
func everyone(tx *gorm.DB) *gorm.DB { return tx }

// mine loads the caller's own ticket id.
func (d *TicketDesk) mine(ctx context.Context, me *repo.Member, id int64) (*repo.Ticket, error) {
	if id <= 0 {
		return nil, fault.Bad("id", "must be positive")
	}
	var t repo.Ticket
	if err := d.db.WithContext(ctx).Where("id = ? AND reporter_id = ?", id, me.ID).First(&t).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	return &t, nil
}

// shift moves ticket id (visible through scope) to state to, when it is in one of from.
func (d *TicketDesk) shift(ctx context.Context, scope func(*gorm.DB) *gorm.DB, id int64, to string,
	extra map[string]any, from ...string) (*repo.Ticket, error) {
	if id <= 0 {
		return nil, fault.Bad("id", "must be positive")
	}
	var t repo.Ticket
	if err := d.db.WithContext(ctx).Scopes(scope).Where("tickets.id = ?", id).First(&t).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	if !slices.Contains(from, t.State) {
		return nil, fault.Wrong(fmt.Sprintf("ticket is %s, not %v", t.State, from))
	}
	changes := map[string]any{"state": to, "updated_at": time.Now().UTC()}
	for k, v := range extra {
		changes[k] = v
	}
	if err := d.db.WithContext(ctx).Model(&t).Updates(changes).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	if err := d.db.WithContext(ctx).First(&t, t.ID).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	return &t, nil
}

// view renders t with its queue slug and remark count.
func (d *TicketDesk) view(ctx context.Context, t *repo.Ticket) *ticketView {
	var q repo.Queue
	d.db.WithContext(ctx).Take(&q, t.QueueID)
	var n int64
	d.db.WithContext(ctx).Model(&repo.Remark{}).Where("ticket_id = ?", t.ID).Count(&n)
	return &ticketView{t: t, slug: q.Slug, remarks: n}
}

type ticketView struct {
	t       *repo.Ticket
	slug    string
	remarks int64
}
