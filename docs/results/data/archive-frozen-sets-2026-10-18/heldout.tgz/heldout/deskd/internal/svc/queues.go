package svc

import (
	"context"

	"gorm.io/gorm"

	"example.org/deskd/internal/deskpb"
	"example.org/deskd/internal/fault"
	"example.org/deskd/internal/repo"
)

// queueDesk serves desk.v1.Queues; it is registered with RegisterService directly.
type queueDesk struct {
	deskpb.UnimplementedQueuesServer
	db *gorm.DB
}

func (q queueDesk) ListQueues(ctx context.Context, in *deskpb.ListQueuesRequest) (*deskpb.ListQueuesReply, error) {
	tx := q.db.WithContext(ctx).Order("slug")
	if !in.GetIncludeClosed() {
		tx = tx.Where("is_open = ?", true)
	}
	var rows []repo.Queue
	if err := tx.Find(&rows).Error; err != nil {
		return nil, fault.Store(err, "queues")
	}
	out := &deskpb.ListQueuesReply{Queues: []*deskpb.Queue{}}
	for i := range rows {
		out.Queues = append(out.Queues, queueOut(&rows[i]))
	}
	return out, nil
}

func (q queueDesk) GetQueue(ctx context.Context, in *deskpb.GetQueueRequest) (*deskpb.Queue, error) {
	if in.GetSlug() == "" {
		return nil, fault.Bad("slug", "required")
	}
	row, err := repo.QueueBySlug(q.db.WithContext(ctx), in.GetSlug(), false)
	if err != nil {
		return nil, fault.Store(err, "queue")
	}
	return queueOut(row), nil
}
