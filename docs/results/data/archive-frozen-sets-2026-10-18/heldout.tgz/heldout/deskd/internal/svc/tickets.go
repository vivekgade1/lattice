package svc

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/emptypb"
	"gorm.io/gorm"

	"example.org/deskd/internal/deskpb"
	"example.org/deskd/internal/fault"
	"example.org/deskd/internal/gate"
	"example.org/deskd/internal/repo"
)

const (
	maxSubject  = 120
	maxBody     = 4000
	maxLabels   = 5
	maxRemark   = 2000
	maxReopens  = 2
	defaultPage = 20
	maxPage     = 100
)

// TicketDesk serves desk.v1.Tickets. MergeTickets and ImportTickets are left to the
// embedded Unimplemented server.
type TicketDesk struct {
	deskpb.UnimplementedTicketsServer
	db *gorm.DB
}

// NewTickets answers the Tickets service over db.
func NewTickets(db *gorm.DB) *TicketDesk { return &TicketDesk{db: db} }

func (d *TicketDesk) out(ctx context.Context, t *repo.Ticket) *deskpb.Ticket {
	v := d.view(ctx, t)
	return ticketOut(v.t, v.slug, v.remarks)
}

func (d *TicketDesk) OpenTicket(ctx context.Context, in *deskpb.OpenTicketRequest) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	subject := strings.TrimSpace(in.GetSubject())
	if subject == "" || len(subject) > maxSubject {
		return nil, fault.Bad("subject", "1 to 120 characters")
	}
	if len(in.GetBody()) > maxBody {
		return nil, fault.Bad("body", "at most 4000 characters")
	}
	prio := in.GetPriority()
	if prio == deskpb.Priority_PRIORITY_UNSPECIFIED {
		prio = deskpb.Priority_PRIORITY_NORMAL
	}
	if prio > deskpb.Priority_PRIORITY_URGENT || prio < 0 {
		return nil, fault.Bad("priority", "unknown value")
	}
	if len(in.GetLabels()) > maxLabels {
		return nil, fault.Bad("labels", "at most 5")
	}
	q, err := repo.QueueBySlug(d.db.WithContext(ctx), in.GetQueueSlug(), true)
	if err != nil {
		return nil, fault.Intake(err)
	}
	labels, _ := json.Marshal(append([]string{}, in.GetLabels()...))
	attrs := in.GetAttrs()
	if attrs == nil {
		attrs = map[string]string{}
	}
	attrJSON, _ := json.Marshal(attrs)
	now := time.Now().UTC()
	t := repo.Ticket{QueueID: q.ID, ReporterID: me.ID, Subject: subject, Body: in.GetBody(),
		Priority: int32(prio), State: repo.StateOpen, Labels: string(labels), Attrs: string(attrJSON),
		CreatedAt: now, UpdatedAt: now}
	if err := d.db.WithContext(ctx).Create(&t).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	return d.out(ctx, &t), nil
}

func (d *TicketDesk) GetTicket(ctx context.Context, in *deskpb.TicketRef) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	t, err := d.mine(ctx, me, in.GetId())
	if err != nil {
		return nil, err
	}
	return d.out(ctx, t), nil
}

func (d *TicketDesk) ListTickets(ctx context.Context, in *deskpb.ListTicketsRequest) (*deskpb.ListTicketsReply, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	size := int(in.GetPageSize())
	if size < 0 || size > maxPage {
		return nil, fault.Bad("page_size", "0 to 100")
	}
	if size == 0 {
		size = defaultPage
	}
	offset := 0
	if tok := in.GetPageToken(); tok != "" {
		n, err := strconv.Atoi(tok)
		if err != nil || n < 0 {
			return nil, fault.Bad("page_token", "not a token from this server")
		}
		offset = n
	}
	tx := d.db.WithContext(ctx).Model(&repo.Ticket{}).Select("tickets.*").Scopes(repo.OwnedBy(me.ID))
	switch f := in.GetFilter().(type) {
	case *deskpb.ListTicketsRequest_State:
		st, ok := stateIn[f.State]
		if !ok {
			return nil, fault.Bad("state", "unknown value")
		}
		tx = tx.Where("tickets.state = ?", st)
	case *deskpb.ListTicketsRequest_QueueSlug:
		tx = tx.Joins("JOIN queues ON queues.id = tickets.queue_id").Where("queues.slug = ?", f.QueueSlug)
	}
	var rows []repo.Ticket
	if err := tx.Order("tickets.id").Limit(size + 1).Offset(offset).Find(&rows).Error; err != nil {
		return nil, err
	}
	out := &deskpb.ListTicketsReply{Tickets: []*deskpb.Ticket{}}
	if len(rows) > size {
		rows = rows[:size]
		out.NextPageToken = strconv.Itoa(offset + size)
	}
	for i := range rows {
		out.Tickets = append(out.Tickets, d.out(ctx, &rows[i]))
	}
	return out, nil
}

func (d *TicketDesk) UpdateTicket(ctx context.Context, in *deskpb.UpdateTicketRequest) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	if in.GetId() <= 0 {
		return nil, fault.Bad("id", "must be positive")
	}
	var t repo.Ticket
	if err := d.db.WithContext(ctx).Scopes(repo.OwnedBy(me.ID)).Where("tickets.id = ?", in.GetId()).First(&t).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	if t.State == repo.StateClosed {
		return nil, fault.Wrong("a closed ticket cannot be edited")
	}
	changes := map[string]any{}
	if in.Subject != nil {
		s := strings.TrimSpace(in.GetSubject())
		if s == "" || len(s) > maxSubject {
			return nil, fault.Bad("subject", "1 to 120 characters")
		}
		changes["subject"] = s
	}
	if in.Body != nil {
		if len(in.GetBody()) > maxBody {
			return nil, fault.Bad("body", "at most 4000 characters")
		}
		changes["body"] = in.GetBody()
	}
	if in.Priority != nil {
		p := in.GetPriority()
		if p <= deskpb.Priority_PRIORITY_UNSPECIFIED || p > deskpb.Priority_PRIORITY_URGENT {
			return nil, fault.Bad("priority", "unknown value")
		}
		changes["priority"] = int32(p)
	}
	if len(changes) == 0 {
		return nil, fault.Bad("update", "nothing to change")
	}
	changes["updated_at"] = time.Now().UTC()
	if err := d.db.WithContext(ctx).Model(&t).Updates(changes).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	if err := d.db.WithContext(ctx).First(&t, t.ID).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	return d.out(ctx, &t), nil
}

func (d *TicketDesk) HoldTicket(ctx context.Context, in *deskpb.TicketRef) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	t, err := d.shift(ctx, repo.OwnedBy(me.ID), in.GetId(), repo.StatePending, nil, repo.StateOpen)
	if err != nil {
		return nil, err
	}
	return d.out(ctx, t), nil
}

func (d *TicketDesk) ResolveTicket(ctx context.Context, in *deskpb.ResolveTicketRequest) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	why := strings.TrimSpace(in.GetResolution())
	if why == "" || len(why) > 500 {
		return nil, fault.Bad("resolution", "1 to 500 characters")
	}
	t, err := d.shift(ctx, repo.OwnedBy(me.ID), in.GetId(), repo.StateResolved,
		map[string]any{"resolution": why}, repo.StateOpen, repo.StatePending)
	if err != nil {
		return nil, err
	}
	return d.out(ctx, t), nil
}

func (d *TicketDesk) ReopenTicket(ctx context.Context, in *deskpb.TicketRef) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	if in.GetId() <= 0 {
		return nil, fault.Bad("id", "must be positive")
	}
	var t repo.Ticket
	if err := d.db.WithContext(ctx).Where("id = ? AND reporter_id = ?", in.GetId(), me.ID).First(&t).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	if t.State != repo.StateResolved || t.ReopenCount >= maxReopens {
		refuse := codes.FailedPrecondition
		if t.State == repo.StateResolved {
			refuse = codes.ResourceExhausted
		}
		return nil, status.Errorf(refuse, "ticket %d cannot be reopened", t.ID)
	}
	err = d.db.WithContext(ctx).Model(&t).Updates(map[string]any{
		"state": repo.StateOpen, "reopen_count": t.ReopenCount + 1, "resolution": nil,
		"updated_at": time.Now().UTC(),
	}).Error
	if err != nil {
		return nil, fault.Store(err, "ticket")
	}
	if err := d.db.WithContext(ctx).First(&t, t.ID).Error; err != nil {
		return nil, fault.Store(err, "ticket")
	}
	return d.out(ctx, &t), nil
}

func (d *TicketDesk) CloseTicket(ctx context.Context, in *deskpb.TicketRef) (*deskpb.Ticket, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	if me.Role != "agent" {
		return nil, fault.Forbidden("only agents close tickets")
	}
	t, err := d.shift(ctx, everyone, in.GetId(), repo.StateClosed, nil, repo.StateResolved)
	if err != nil {
		return nil, err
	}
	return d.out(ctx, t), nil
}

func (d *TicketDesk) DeleteTicket(ctx context.Context, in *deskpb.TicketRef) (*emptypb.Empty, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	t, err := d.mine(ctx, me, in.GetId())
	if err != nil {
		return nil, err
	}
	if t.State != repo.StateOpen {
		return nil, fault.Wrong("only an open ticket can be deleted")
	}
	err = d.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("ticket_id = ?", t.ID).Delete(&repo.Remark{}).Error; err != nil {
			return err
		}
		return tx.Delete(t).Error
	})
	if err != nil {
		return nil, fault.Store(err, "ticket")
	}
	return &emptypb.Empty{}, nil
}

func (d *TicketDesk) AddRemark(ctx context.Context, in *deskpb.AddRemarkRequest) (*deskpb.Remark, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	text := strings.TrimSpace(in.GetText())
	if text == "" || len(text) > maxRemark {
		return nil, fault.Bad("text", "1 to 2000 characters")
	}
	if in.GetInternal() && me.Role != "agent" {
		return nil, fault.Forbidden("only agents write internal remarks")
	}
	t, err := d.mine(ctx, me, in.GetTicketId())
	if err != nil {
		return nil, err
	}
	if t.State == repo.StateClosed {
		return nil, fault.Wrong("ticket is closed")
	}
	r := repo.Remark{TicketID: t.ID, AuthorID: me.ID, Text: text, Internal: in.GetInternal()}
	if err := d.db.WithContext(ctx).Create(&r).Error; err != nil {
		return nil, fault.Store(err, "remark")
	}
	return remarkOut(&r), nil
}

func (d *TicketDesk) ListRemarks(ctx context.Context, in *deskpb.TicketRef) (*deskpb.ListRemarksReply, error) {
	me, err := gate.Caller(ctx)
	if err != nil {
		return nil, err
	}
	t, err := d.mine(ctx, me, in.GetId())
	if err != nil {
		return nil, err
	}
	tx := d.db.WithContext(ctx).Where("ticket_id = ?", t.ID).Order("id")
	if me.Role != "agent" {
		tx = tx.Where("internal = ?", false)
	}
	var rows []repo.Remark
	if err := tx.Find(&rows).Error; err != nil {
		return nil, fault.Store(err, "remarks")
	}
	out := &deskpb.ListRemarksReply{Remarks: []*deskpb.Remark{}}
	for i := range rows {
		out.Remarks = append(out.Remarks, remarkOut(&rows[i]))
	}
	return out, nil
}

// WatchQueue sends a snapshot of the caller's tickets in a queue (server streaming).
func (d *TicketDesk) WatchQueue(in *deskpb.WatchQueueRequest, stream grpc.ServerStreamingServer[deskpb.TicketEvent]) error {
	ctx := stream.Context()
	me, err := gate.Caller(ctx)
	if err != nil {
		return err
	}
	q, err := repo.QueueBySlug(d.db.WithContext(ctx), in.GetQueueSlug(), false)
	if err != nil {
		return fault.Store(err, "queue")
	}
	var rows []repo.Ticket
	if err := d.db.WithContext(ctx).Scopes(repo.OwnedBy(me.ID)).Where("queue_id = ?", q.ID).Order("id").Find(&rows).Error; err != nil {
		return fault.Store(err, "tickets")
	}
	for i := range rows {
		ev := &deskpb.TicketEvent{Kind: deskpb.TicketEvent_KIND_SNAPSHOT, Ticket: d.out(ctx, &rows[i])}
		if err := stream.Send(ev); err != nil {
			return err
		}
	}
	return nil
}
