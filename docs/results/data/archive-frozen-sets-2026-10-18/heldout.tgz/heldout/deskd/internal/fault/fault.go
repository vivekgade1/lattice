// Package fault holds the helpdesk's error constructors. Every one answers a gRPC status
// error, so a handler may return what it gets from them unchanged.
package fault

import (
	"errors"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"gorm.io/gorm"
)

// ErrQueueShut marks a queue that takes no new tickets.
var ErrQueueShut = errors.New("queue is shut")

// Missing reports an absent (or not visible) record.
func Missing(what string) error {
	return status.Errorf(codes.NotFound, "%s not found", what)
}

// Bad reports a rejected request field.
func Bad(field, why string) error {
	return status.Errorf(codes.InvalidArgument, "%s: %s", field, why)
}

// Taken reports a unique value that is already in use.
func Taken(what string) error {
	return status.Error(codes.AlreadyExists, what+" already taken")
}

// Wrong reports a request that does not fit the record's current state.
func Wrong(msg string) error {
	return status.New(codes.FailedPrecondition, msg).Err()
}

// Forbidden reports a caller who may not do this.
func Forbidden(msg string) error {
	return status.Error(codes.PermissionDenied, msg)
}

// Anonymous reports a call without a usable session.
func Anonymous() error {
	return status.Error(codes.Unauthenticated, "sign in first")
}

// Store turns a storage error into a status error.
func Store(err error, what string) error {
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		return status.Errorf(codes.NotFound, "%s not found", what)
	default:
		return status.Errorf(codes.Internal, "storage: %v", err)
	}
}

// Intake turns a queue lookup error (for a new ticket) into a status error.
func Intake(err error) error {
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		return status.Error(codes.NotFound, "queue not found")
	case errors.Is(err, ErrQueueShut):
		return status.Error(codes.FailedPrecondition, "queue is not taking tickets")
	default:
		return status.Errorf(codes.Internal, "storage: %v", err)
	}
}
