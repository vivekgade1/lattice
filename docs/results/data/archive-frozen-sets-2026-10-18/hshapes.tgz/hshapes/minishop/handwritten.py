"""Hand-written checks for the frozen minishop rule-shape set (Spike H, prereg section 3.1).

Written by the shapes agent as a spec author would write them, without any forms code:
minishop's profile, programs, machine and users (imported from ``tests.spec.minishop``),
the base fixture's two scenarios and two invariants, and one or more scenarios or
invariants per rule of ``REQUIREMENTS.md`` (next to this file). ``TRACE`` links every
rule to the elements that check it. ``CONTRACTS`` are minishop's attack contracts with
the body parameters' stored columns named (``ContractParam.column``); they type the
request fields the forms name and take no part in a CD run.

Import with the repository root on ``sys.path``:  ``SPEC``, ``TRACE``, ``LINKS``.
"""

from __future__ import annotations

from pathlib import Path

from lattice.spec import Invariant, Scenario, Spec, Step
from lattice.spec.model import Contract, ContractError, ContractParam
from lattice.spec.rules import Trace, extract_rules
from lattice.typesys import Scalar as S
from tests.spec import minishop

HERE = Path(__file__).resolve().parent
REQUIREMENTS = HERE / "REQUIREMENTS.md"

CONTRACTS = (
    Contract(
        "GET", "/orders", auth="Authenticated", table="Order", kind="list", owner_scope="owner"
    ),
    Contract(
        "GET",
        "/orders/{order_id}",
        auth="Authenticated",
        table="Order",
        kind="read",
        owner_scope="owner",
        params=(ContractParam("order_id", source="path", scalar=S.INT),),
        errors=(ContractError(401, when="unauthenticated"), ContractError(404, when="not_owned")),
    ),
    Contract(
        "POST",
        "/orders/{order_id}/cancel",
        auth="Authenticated",
        table="Order",
        kind="action",
        owner_scope="owner",
        params=(ContractParam("order_id", source="path", scalar=S.INT),),
    ),
    Contract(
        "POST",
        "/orders/{order_id}/items",
        auth="Authenticated",
        table="OrderItem",
        kind="create",
        owner_scope="owner",
        params=(
            ContractParam("order_id", source="path", scalar=S.INT),
            ContractParam(
                "product_id", source="body", scalar=S.INT, ge=1, column="OrderItem.product_id"
            ),
            ContractParam(
                "quantity", source="body", scalar=S.INT, ge=1, le=100, column="OrderItem.quantity"
            ),
        ),
    ),
)

INVARIANTS = (
    *minishop.INVARIANTS,  # order_total (R3), stock_non_negative (R4)
    Invariant("line_quantity_positive", "A stored line's quantity is always at least 1",
              "OrderItem.quantity >= 1"),
    Invariant("order_status_known", "An order's status is always a known state",
              'Order.status in ("pending", "paid", "shipped", "cancelled")'),
    Invariant("user_name_not_empty", "A user's name is never empty", 'User.name != ""'),
    Invariant("at_most_5_lines", "An order has at most 5 lines",
              'count(OrderItem, by="order_id") <= 5'),
    Invariant("product_once_per_order", "A product appears at most once in an order",
              'count(OrderItem, by=("order_id", "product_id")) <= 1'),
    Invariant("at_most_3_cancelled", "A buyer has at most 3 cancelled orders",
              'count(Order, by="user_id", where=Order.status == "cancelled") <= 3'),
)  # fmt: skip


def _add(order: int, product: int, quantity: int, status: int, **kw) -> Step:
    return Step(
        "POST",
        f"/orders/{order}/items",
        user=kw.pop("user", "ann"),
        json={"product_id": product, "quantity": quantity},
        expect_status=status,
        **kw,
    )


def _lines(order: int, n: int, **where) -> dict:
    return {"order_items": {"where": {"order_id": order, **where}, "count": n}}


def _order(order: int, status: str) -> dict:
    return {"orders": {"where": {"id": order}, "equals": {"status": status}}}


CRATE = {"id": 10, "name": "crate", "price": 1.0, "stock": 500}

SCENARIOS = (
    *minishop.SCENARIOS,  # "ann cancels her pending order" (R1), "ann adds a line ..." (R2)
    # R6
    Scenario(
        "quantity 0 is refused",
        steps=(
            _add(1, 2, 0, 422, expect_db=_lines(1, 1)),
            _add(1, 2, 1, 201, expect_db=_lines(1, 2)),
        ),
    ),
    # R7
    Scenario(
        "quantity 101 is refused",
        given={"products": [CRATE]},
        steps=(
            _add(1, 10, 101, 422, expect_db=_lines(1, 1)),
            _add(1, 10, 100, 201, expect_db=_lines(1, 1, product_id=10)),
        ),
    ),
    # R8
    Scenario(
        "product id 0 is refused",
        steps=(
            _add(1, 0, 1, 422, expect_db=_lines(1, 1)),
            _add(1, 2, 1, 201, expect_db=_lines(1, 2)),
        ),
    ),
    # R12
    Scenario(
        "a sixth line is refused",
        given={
            "products": [
                {"id": 11, "name": "cap", "price": 1.0, "stock": 10},
                {"id": 12, "name": "nib", "price": 1.0, "stock": 10},
                {"id": 13, "name": "pad", "price": 1.0, "stock": 10},
                {"id": 14, "name": "tag", "price": 1.0, "stock": 10},
            ],
            "orders": [{"id": 20, "user_id": 1, "status": "pending", "total": 9.5}],
            "order_items": [
                {"id": 101, "order_id": 20, "product_id": 1, "quantity": 1, "price": 2.5},
                {"id": 102, "order_id": 20, "product_id": 2, "quantity": 1, "price": 4.0},
                {"id": 103, "order_id": 20, "product_id": 11, "quantity": 1, "price": 1.0},
                {"id": 104, "order_id": 20, "product_id": 12, "quantity": 1, "price": 1.0},
                {"id": 105, "order_id": 20, "product_id": 13, "quantity": 1, "price": 1.0},
            ],
        },
        steps=(_add(20, 14, 1, 409, expect_db=_lines(20, 5)),),
    ),
    # R13
    Scenario(
        "the same product twice is refused",
        given={
            "orders": [{"id": 20, "user_id": 1, "status": "pending", "total": 2.5}],
            "order_items": [
                {"id": 101, "order_id": 20, "product_id": 1, "quantity": 1, "price": 2.5}
            ],
        },
        steps=(_add(20, 1, 1, 409, expect_db=_lines(20, 1, product_id=1)),),
    ),
    # R14
    Scenario(
        "a fourth cancel is refused",
        given={
            "orders": [
                {"id": 20, "user_id": 1, "status": "pending", "total": 0.0},
                {"id": 21, "user_id": 1, "status": "cancelled", "total": 0.0},
                {"id": 22, "user_id": 1, "status": "cancelled", "total": 0.0},
                {"id": 23, "user_id": 1, "status": "cancelled", "total": 0.0},
            ]
        },
        steps=(
            Step("POST", "/orders/20/cancel", user="ann", expect_status=409,
                 expect_db=_order(20, "pending")),
        ),
    ),  # fmt: skip
    # R15
    Scenario(
        "others cannot read an order",
        steps=(
            Step("GET", "/orders/1", user="ann", expect_status=200),
            Step("GET", "/orders/1", user="ben", expect_status=404),
            Step("GET", "/orders/1", user=None, expect_status=401),
        ),
    ),
    # R16
    Scenario(
        "others cannot cancel an order",
        steps=(
            Step("POST", "/orders/1/cancel", user="ben", expect_status=404,
                 expect_db=_order(1, "pending")),
            Step("POST", "/orders/1/cancel", user=None, expect_status=401,
                 expect_db=_order(1, "pending")),
        ),
    ),  # fmt: skip
    # R17
    Scenario(
        "an admin cannot read another user's order",
        steps=(
            Step("GET", "/orders/1", user="ada", expect_status=404),
            Step("GET", "/orders/1", user=None, expect_status=401),
        ),
    ),
    # R18 (with "ann cancels her pending order")
    Scenario(
        "a paid order cannot be cancelled",
        steps=(
            Step("POST", "/orders/2/cancel", user="ann", expect_status=409,
                 expect_db=_order(2, "paid")),
        ),
    ),  # fmt: skip
    # R19
    Scenario(
        "no line on an order that is not pending",
        given={"orders": [{"id": 21, "user_id": 1, "status": "cancelled", "total": 0.0}]},
        steps=(
            _add(21, 2, 1, 409, expect_db=_lines(21, 0)),
            _add(2, 1, 1, 409, expect_db=_lines(2, 1)),
        ),
    ),
    # R20
    Scenario(
        "the owner reads an order in any state",
        given={"orders": [{"id": 21, "user_id": 1, "status": "cancelled", "total": 0.0}]},
        steps=(
            Step("GET", "/orders/21", user="ann", expect_status=200,
                 expect_body={"id": 21, "status": "cancelled"}),
            Step("GET", "/orders/2", user="ann", expect_status=200,
                 expect_body={"id": 2, "status": "paid"}),
        ),
    ),  # fmt: skip
)

SPEC = Spec(
    profile=minishop.profile(),
    programs={"orders": minishop.ORDERS_PROGRAM},
    machines=minishop.SPEC.machines,
    invariants=INVARIANTS,
    scenarios=SCENARIOS,
    unchecked=minishop.SPEC.unchecked,
    users=dict(minishop.SPEC.users),
    contracts=CONTRACTS,
)

LINKS: dict[str, list[str]] = {
    "R1": ["scenario:ann cancels her pending order"],
    "R2": ["scenario:ann adds a line to a new order"],
    "R3": ["invariant:order_total"],
    "R4": ["invariant:stock_non_negative"],
    "R5": ["machine:Order.status"],
    "R6": ["scenario:quantity 0 is refused"],
    "R7": ["scenario:quantity 101 is refused"],
    "R8": ["scenario:product id 0 is refused"],
    "R9": ["invariant:line_quantity_positive"],
    "R10": ["invariant:order_status_known"],
    "R11": ["invariant:user_name_not_empty"],
    "R12": ["scenario:a sixth line is refused", "invariant:at_most_5_lines"],
    "R13": ["scenario:the same product twice is refused", "invariant:product_once_per_order"],
    "R14": ["scenario:a fourth cancel is refused", "invariant:at_most_3_cancelled"],
    "R15": ["scenario:others cannot read an order"],
    "R16": ["scenario:others cannot cancel an order"],
    "R17": ["scenario:an admin cannot read another user's order"],
    "R18": ["scenario:a paid order cannot be cancelled", "scenario:ann cancels her pending order"],
    "R19": ["scenario:no line on an order that is not pending"],
    "R20": ["scenario:the owner reads an order in any state"],
}

TRACE = Trace(
    source="REQUIREMENTS.md",
    rules=extract_rules(REQUIREMENTS.read_text()),
    links={k: list(v) for k, v in LINKS.items()},
)
