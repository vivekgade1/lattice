# Mini shop

## Orders

- A buyer can cancel their own pending order, and cancelling it again is refused with 409.
- A buyer can add a line to a pending order and the stored line has the requested quantity.
- An order's total is the sum of its lines.
- Stock is never negative.
- An order moves from pending to paid or cancelled, and from paid to shipped.

## Bounds

- A line's requested quantity is at least 1: adding a line with quantity 0 is refused with 422 and nothing is stored.
- A line's requested quantity is at most 100: adding a line with quantity 101 is refused with 422 and nothing is stored.
- A line's requested product id is at least 1: adding a line with product id 0 is refused with 422 and nothing is stored.
- A stored line's quantity is always at least 1.
- An order's status is always one of pending, paid, shipped or cancelled.
- A user's name is never empty.

## Limits

- An order has at most 5 lines: adding a sixth line is refused with 409 and nothing is stored.
- A product appears at most once in an order: adding a product the order already has is refused with 409 and nothing is stored.
- A buyer has at most 3 cancelled orders: cancelling a fourth order is refused with 409 and the order stays pending.

## Ownership

- Another buyer's read of a buyer's order is answered 404, and a read without a token is answered 401.
- Another buyer's cancel of a buyer's order is answered 404 and a cancel without a token is answered 401; neither changes the order.
- An admin has no override on reads: an admin's read of another user's order is answered 404, and a read without a token is answered 401.

## Order states

- Cancelling is accepted only for a pending order, which becomes cancelled (200); cancelling a paid, shipped or cancelled order is refused with 409 and leaves it unchanged.
- A line can be added only to a pending order (201, the order stays pending); adding a line to a paid, shipped or cancelled order is refused with 409 and nothing changes.
- An order's owner can read it in every state: pending, paid, shipped or cancelled (200).
