# H3: the round-3 frozen rule-shape set (minishop)

Written 2026-10-18 by a new, separate shapes agent (a Claude Code subagent, no API key, no
model calls) for `docs/results/2026-10-18-typed-conditions-round3-prereg.md` section 4 (with
Amendment 1). Nothing here was produced by, or checked with, `lattice/spec/forms*.py`.

## What the author read, and did not read

Read (from `/home/user/lattice`, branch `next-phases` at `41228f9`, read-only):
`tests/spec/minishop.py`, `tests/spec/fixtures/impact/base/` (REQUIREMENTS.md, spec.py,
spec.trace.json); the spec language as the library states it (`lattice/spec/model.py`,
`lattice/spec/invariants.py` docstring, `lattice/spec/rules.py`, `lattice/spec/check.py`'s
`check`/given handling, `lattice/spec/report.py`, `lattice/spec/rationale.py`'s `anchor_of`
and canonical sha); the round-3 prereg. Because the commissioning text this agent received did
not carry D1'', D6, D4'' or a layout section, the author also read the **decision sections**
of the round-1 and round-2 pre-registrations (`2026-10-17-typed-conditions-prereg.md` D1-D7
and section 3.1-3.2; `2026-10-17-typed-conditions-round2-prereg.md` sections 2, 3.1-3.2 and
its Amendments), to obtain D1, D1' (i-vii), D4/D4' (with F021, cause 7's list), D3 and D6
verbatim. This is disclosed as a deviation from section 4's "must not read any
`*typed-conditions*` doc". Those are pre-registrations written before any set existed.

Not read: `lattice/spec/forms*.py`, `dogfood/forms_*`, `tests/spec/test_forms*.py`,
`tests/spec/fixtures/forms*/`, any typed-conditions **results** doc or data directory,
`/home/user/wt/`, the round-1 set, H2 (`hshapes2`), `rc.json`, other agents' scratch
directories.

## Files

| file | content |
|---|---|
| `minishop/REQUIREMENTS.md` | 38 rules: R1-R5 base (verbatim), R6-R27 formed (7 bound, 4 row_limit, 6 ownership, 5 transition), R28-R38 not formed (used by `not_expressible.json` attempts) |
| `minishop/forms.json` | `lattice.forms/1`, 22 approved forms F1-F22, one per formed rule |
| `minishop/handwritten.py` | `SPEC`: minishop's profile, programs, machine and users, the base elements, plus the author's own scenarios (`h3 ...`) and invariants (`h3_...`) |
| `minishop/handwritten.trace.json` | the trace (`lattice.spec.rules.Trace`, ids by `extract_rules`) linking every rule |
| `minishop/mutants.json` | 22 single-edit app mutants |
| `minishop/truth.json` | 22 formed rules x 33 apps = 726 cells, judged from the English rule and the edit |
| `minishop/h_verdicts.json` | the hand-written checks run (existing `check`, layers CD) on all 33 apps |
| `pairs.json` | 28 form pairs |
| `invalid.json` | 29 invalid forms, 19 distinct codes |
| `not_expressible.json` | 16 rules, 13 categories, 11 attempted forms |
| `MANIFEST.sha256` | `sha256sum` of every file above, sorted by path |

## Layout (JSON shapes, as data types)

The prompt carried no layout section, so these shapes are this author's; a reader written for
another set may need a layout-only adaptation (prereg D3 (2)).

- **Form entry** (everywhere a form appears): `{id: "F<n>", rule: "R<n>", anchor: sha256 hex
  of the rule's normalised text (rationale.anchor_of), kind: "bound"|"row_limit"|"ownership"|
  "transition", form: object, status: "approved", author: "hand", approved_by: "shapes-agent",
  approved_sha: sha256 hex of json.dumps({kind, form}, sort_keys=True, separators=(",", ":"),
  ensure_ascii=False)}`.
- `forms.json`: `{schema: "lattice.forms/1", source: "REQUIREMENTS.md", forms: [entry]}`.
- `mutants.json`: `{schema: str, mutants: [{name: str, kind: str, rules: [rule id] (the rules
  it aims at), aim: str, tags: [str] ("path_bound_clamp" | "path_bound_ignored" |
  "write_then_refuse"), edit: {file: str (a key of minishop.FILES), old: str (occurs exactly
  once in that file), new: str}}]}`. Apply as `minishop.write_app(root, name, (file, old, new))`.
- `truth.json`: `{schema: str, apps: [app name], rules: [rule id], cells: {rule: {app:
  {violates: bool, reason: str}}}}`.
- `h_verdicts.json`: `{schema, layers: "CD", run: str, apps, rules, cells: {rule: {app:
  {verdict: "pass"|"fail", failing: ["scenario:<name>"|"invariant:<name>"], h_incomplete: bool,
  reason?: str (present iff h_incomplete)}}}, elements_failing: {app: [element]}}`.
- `pairs.json`: `{schema, pairs: [{id: "P<n>", class: "a"|"b"|"c"|"d"|"e", expect:
  "contradictory"|"compatible", forms: [entry] (two entries; one entry when the other side is
  hand-written), handwritten?: {name: str, scenario: {given: object|null, steps: [{method,
  path, user: handle|null, json?, expect_status}]}} (a scenario to add to `handwritten.SPEC`
  for that pair only), path_or_query_bound: bool, witness: object ({field, value} | {request:
  {method, path, user, json?}} | {state} | {counted_rows, request?}), why: str}]}`.
- `invalid.json`: `{schema, invalid: [{id: "I<n>", code: "F0nn", why: str, forms: [entry]}]}`
  (`forms` is the whole forms list to check; one entry except I22, F015, which has two).
- `not_expressible.json`: `{schema, rules: [{id: "N<n>", app: "minishop"|"streak-like", rule:
  rule id|null, text: str, category: D6 category, reason: str, attempt: entry|null,
  outcome_db_nonliteral: bool}]}`. Minishop attempts point at R28-R38 (in the trace).

**App names** (truth/h_verdicts order): `ok`, the 4 `minishop.BROKEN` keys, `sec:<name>` for
the 6 `minishop.SEC_BROKEN` keys (`write_sec_app(root, name)`), then the 22 mutant names.

## Conventions and reading of the rules

- **Path bounds (D1'' viii)**: F1 (`GET /orders/{order_id}`, `le 2147483647`), F2 (`POST
  /orders/{order_id}/items`, `ge 1`), F3 (`POST /orders/{order_id}/cancel`, `lt 2147483648`).
  minishop's endpoints read no query key, so every path/query bound is on a path placeholder.
  The rules bound the 64-bit range (order numbers past 2^63-1 make the clean app answer 500).
- **Row limits** are violated on the clean app by construction (minishop enforces no line
  limit): R13-R16 are `violates: true` on `ok` and on every app that does not implement them;
  the four `m_*_limit_*` mutants each implement one limit exactly (that cell is `false`).
  Limit rules read "accepted below the limit when no other rule refuses it"; the four limits
  are jointly satisfiable and each form's below/at_limit state stays inside the others.
- **Column-only bounds** (F5 `Order.total ge 0.0`, F7 `OrderItem.price ge 0.0`) state stored
  values; truth marks them violated wherever the app can reach a violating state. Two such
  cells are expected to be K6 misses: R10 x `sec:bounds` (negative quantities), R12 x
  `sec:mass` (client prices).
- Ownership forms name concrete users; their rules are worded for that pair of roles (a buyer
  vs an admin, a buyer vs another buyer), so a mutant that only opens access to admins violates
  only the admin-other rule (R19).
- Transition rows use fresh keys (54-58), never seed keys. Hand-written scenarios use their
  own `given` rows.
- `h_verdicts.json`: the hand-written checks fail on `ok` exactly on R13-R16 (truth: violated
  on ok); no hand-written check fails on `ok` against truth. H != T on 2 of 726 cells (the two
  column-only cells above, `h_incomplete` with reasons).

## Author's own consistency check (not part of the set's scoring)

The author expanded every form into scenarios and invariants by their own reading of D1''/D3
(a throw-away script, not the library) and ran them with the existing `check` (CD) on all 33
apps: they agree with `truth.json` on 724 of 726 cells; the 2 differences are the K6 cells
above.
