"""H3 hand-written spec for minishop: the shapes agent's own scenarios and invariants for
REQUIREMENTS.md (R1-R38), written the way a spec author would, without forms.

Profile, programs, machine, users and the base rules' elements (R1-R5) are minishop's own;
everything for R6-R27 is new. R28-R38 are left to `Unchecked` notes. The trace is
`handwritten.trace.json` beside this file.
"""

from __future__ import annotations

from lattice.spec import Invariant, Scenario, Spec, Step, Unchecked
from tests.spec import minishop

BIG = 2147483647  # the largest 32-bit order number
OVER = 2147483648  # the first number past it
TOP = 9223372036854775807  # the largest 64-bit number


def _order(oid: int, user_id: int, status: str = "pending", total: float = 0.0) -> dict:
    return {"id": oid, "user_id": user_id, "status": status, "total": total}


def _product(pid: int, name: str, price: float, stock: int) -> dict:
    return {"id": pid, "name": name, "price": price, "stock": stock}


def _status(oid: int, status: str) -> dict:
    return {"orders": {"where": {"id": oid}, "equals": {"status": status}}}


def _lines(where: dict, n: int) -> dict:
    return {"order_items": {"where": where, "count": n}}


ALL_LINES_3 = {"order_items": {"count": 3}}  # the seed's three lines, nothing added

INVARIANTS = (
    *minishop.INVARIANTS,
    Invariant("h3_order_total_non_negative", "An order's total is never negative", "Order.total >= 0"),
    Invariant("h3_line_price_non_negative", "A line's price is never negative", "OrderItem.price >= 0"),
)

SCENARIOS = (
    *minishop.SCENARIOS,
    # R6: read paths are 32-bit
    Scenario(
        "h3 ann reads order 2147483647 and nothing past it",
        given={"orders": [_order(BIG, 1)]},
        steps=(
            Step("GET", f"/orders/{OVER}", user="ann", expect_status=404),
            Step("GET", f"/orders/{TOP}", user="ann", expect_status=404),
            Step("GET", f"/orders/{BIG}", user="ann", expect_status=200),
        ),
    ),
    # R7: lines only for order numbers >= 1
    Scenario(
        "h3 ann adds ink to order 0 and to a negative order",
        steps=(
            Step("POST", "/orders/0/items", user="ann", json={"product_id": 2, "quantity": 1},
                 expect_status=404, expect_db=ALL_LINES_3),
            Step("POST", "/orders/-5/items", user="ann", json={"product_id": 2, "quantity": 1},
                 expect_status=404, expect_db=ALL_LINES_3),
            Step("POST", "/orders/1/items", user="ann", json={"product_id": 2, "quantity": 1},
                 expect_status=201),
        ),
    ),
    # R8: cancel paths are 32-bit
    Scenario(
        "h3 ben cancels past order 2147483647",
        given={"orders": [_order(BIG, 2)]},
        steps=(
            Step("POST", f"/orders/{OVER}/cancel", user="ben", expect_status=404,
                 expect_db=_status(BIG, "pending")),
            Step("POST", f"/orders/{BIG}/cancel", user="ben", expect_status=200),
        ),
    ),
    # R9: product_id >= 1
    Scenario(
        "h3 ben adds product 0 and product -1",
        steps=(
            Step("POST", "/orders/3/items", user="ben", json={"product_id": 0, "quantity": 1},
                 expect_status=422, expect_db=ALL_LINES_3),
            Step("POST", "/orders/3/items", user="ben", json={"product_id": -1, "quantity": 1},
                 expect_status=422, expect_db=ALL_LINES_3),
            Step("POST", "/orders/3/items", user="ben", json={"product_id": 1, "quantity": 2},
                 expect_status=201),
        ),
    ),
    # R11: at most 100 units per line
    Scenario(
        "h3 ann orders 101 then 100 crates",
        given={"products": [_product(9, "crate", 1.0, 500)]},
        steps=(
            Step("POST", "/orders/1/items", user="ann", json={"product_id": 9, "quantity": 101},
                 expect_status=422, expect_db=ALL_LINES_3),
            Step("POST", "/orders/1/items", user="ann", json={"product_id": 9, "quantity": 100},
                 expect_status=201),
        ),
    ),
    # R13: at most two ink lines per order
    Scenario(
        "h3 ann adds a third ink line",
        given={"orders": [_order(20, 1)]},
        steps=(
            Step("POST", "/orders/20/items", user="ann", json={"product_id": 2, "quantity": 1},
                 expect_status=201),
            Step("POST", "/orders/20/items", user="ann", json={"product_id": 2, "quantity": 1},
                 expect_status=201),
            Step("POST", "/orders/20/items", user="ann", json={"product_id": 2, "quantity": 1},
                 expect_status=409, expect_db=_lines({"order_id": 20}, 2)),
        ),
    ),
    # R14: at most three lines of one product per order
    Scenario(
        "h3 ben adds a fourth pen line",
        steps=(
            *(
                Step("POST", "/orders/3/items", user="ben", json={"product_id": 1, "quantity": 1},
                     expect_status=201)
                for _ in range(3)
            ),
            Step("POST", "/orders/3/items", user="ben", json={"product_id": 1, "quantity": 1},
                 expect_status=409, expect_db=_lines({"order_id": 3, "product_id": 1}, 3)),
        ),
    ),
    # R15: one ten-unit line per product per order
    Scenario(
        "h3 ann adds a second ten-unit box line",
        given={"orders": [_order(21, 1)], "products": [_product(12, "box", 1.0, 100)]},
        steps=(
            Step("POST", "/orders/21/items", user="ann", json={"product_id": 12, "quantity": 10},
                 expect_status=201),
            Step("POST", "/orders/21/items", user="ann", json={"product_id": 12, "quantity": 10},
                 expect_status=409, expect_db=_lines({"order_id": 21}, 1)),
        ),
    ),
    # R16: four lines per order in all
    Scenario(
        "h3 ann adds a fifth line",
        given={
            "orders": [_order(22, 1)],
            "products": [_product(13, "tag", 1.0, 50), _product(14, "pin", 1.0, 50)],
        },
        steps=(
            *(
                Step("POST", "/orders/22/items", user="ann", json={"product_id": p, "quantity": 1},
                     expect_status=201)
                for p in (1, 2, 13, 14)
            ),
            Step("POST", "/orders/22/items", user="ann", json={"product_id": 1, "quantity": 1},
                 expect_status=400, expect_db=_lines({"order_id": 22}, 4)),
        ),
    ),
    # R17: an admin's order is hidden from buyers
    Scenario(
        "h3 ann asks for ada's order 4",
        steps=(
            Step("GET", "/orders/4", user="ann", expect_status=404),
            Step("GET", "/orders/4", user=None, expect_status=401),
            Step("GET", "/orders/4", user="ada", expect_status=200),
        ),
    ),
    # R18: only the buyer cancels a buyer's order
    Scenario(
        "h3 ben and anonymous try to cancel ann's order 40",
        given={"orders": [_order(40, 1)]},
        steps=(
            Step("POST", "/orders/40/cancel", user="ben", expect_status=404,
                 expect_db=_status(40, "pending")),
            Step("POST", "/orders/40/cancel", user=None, expect_status=401,
                 expect_db=_status(40, "pending")),
            Step("POST", "/orders/40/cancel", user="ann", expect_status=200,
                 expect_db=_status(40, "cancelled")),
        ),
    ),
    # R19: no admin access to a buyer's order
    Scenario(
        "h3 ada reads and cancels ben's order 3",
        steps=(
            Step("GET", "/orders/3", user="ada", expect_status=404),
            Step("POST", "/orders/3/cancel", user="ada", expect_status=404,
                 expect_db=_status(3, "pending")),
            Step("GET", "/orders/3", user=None, expect_status=401),
            Step("GET", "/orders/3", user="ben", expect_status=200),
            Step("POST", "/orders/3/cancel", user="ben", expect_status=200),
        ),
    ),
    # R20: a paid order is private
    Scenario(
        "h3 ben asks for ann's paid order 2",
        steps=(
            Step("GET", "/orders/2", user="ben", expect_status=404),
            Step("GET", "/orders/2", user=None, expect_status=401),
            Step("GET", "/orders/2", user="ann", expect_status=200),
        ),
    ),
    # R21: buyers cannot cancel an admin's order
    Scenario(
        "h3 ben cancels ada's order 4",
        steps=(
            Step("POST", "/orders/4/cancel", user="ben", expect_status=404,
                 expect_db=_status(4, "pending")),
            Step("POST", "/orders/4/cancel", user=None, expect_status=401,
                 expect_db=_status(4, "pending")),
            Step("POST", "/orders/4/cancel", user="ada", expect_status=200),
        ),
    ),
    # R22: a shipped order is private
    Scenario(
        "h3 ann asks for ben's shipped order",
        given={"orders": [_order(44, 2, "shipped")]},
        steps=(
            Step("GET", "/orders/44", user="ann", expect_status=404),
            Step("GET", "/orders/44", user=None, expect_status=401),
            Step("GET", "/orders/44", user="ben", expect_status=200),
        ),
    ),
    # R23: ada's cancels follow the machine
    Scenario(
        "h3 ada cancels her orders in each state",
        given={
            "orders": [
                _order(54, 3),
                _order(64, 3, "paid"),
                _order(65, 3, "shipped"),
                _order(66, 3, "cancelled"),
            ]
        },
        steps=(
            Step("POST", "/orders/64/cancel", user="ada", expect_status=409,
                 expect_db=_status(64, "paid")),
            Step("POST", "/orders/65/cancel", user="ada", expect_status=409,
                 expect_db=_status(65, "shipped")),
            Step("POST", "/orders/66/cancel", user="ada", expect_status=409,
                 expect_db=_status(66, "cancelled")),
            Step("POST", "/orders/54/cancel", user="ada", expect_status=200,
                 expect_db=_status(54, "cancelled")),
        ),
    ),
    # R24: ben's lines only onto pending orders
    Scenario(
        "h3 ben adds ink to his orders in each state",
        given={
            "orders": [
                _order(55, 2),
                _order(67, 2, "paid"),
                _order(68, 2, "cancelled"),
                _order(76, 2, "shipped"),
            ]
        },
        steps=(
            Step("POST", "/orders/67/items", user="ben", json={"product_id": 2, "quantity": 1},
                 expect_status=409, expect_db=_lines({"order_id": 67}, 0)),
            Step("POST", "/orders/76/items", user="ben", json={"product_id": 2, "quantity": 1},
                 expect_status=409, expect_db=_lines({"order_id": 76}, 0)),
            Step("POST", "/orders/68/items", user="ben", json={"product_id": 2, "quantity": 1},
                 expect_status=409, expect_db=_lines({"order_id": 68}, 0)),
            Step("POST", "/orders/55/items", user="ben", json={"product_id": 2, "quantity": 1},
                 expect_status=201),
        ),
    ),
    # R25: an owner reads an order in every state
    Scenario(
        "h3 ann reads her orders in each state",
        given={
            "orders": [
                _order(56, 1),
                _order(69, 1, "paid"),
                _order(70, 1, "shipped"),
                _order(71, 1, "cancelled"),
            ]
        },
        steps=tuple(
            Step("GET", f"/orders/{oid}", user="ann", expect_status=200) for oid in (56, 69, 70, 71)
        ),
    ),
    # R26: ben's cancels follow the machine
    Scenario(
        "h3 ben cancels his orders in each state",
        given={"orders": [_order(57, 2), _order(72, 2, "paid"), _order(73, 2, "shipped")]},
        steps=(
            Step("POST", "/orders/72/cancel", user="ben", expect_status=409,
                 expect_db=_status(72, "paid")),
            Step("POST", "/orders/73/cancel", user="ben", expect_status=409,
                 expect_db=_status(73, "shipped")),
            Step("POST", "/orders/57/cancel", user="ben", expect_status=200,
                 expect_db=_status(57, "cancelled")),
            Step("POST", "/orders/57/cancel", user="ben", expect_status=409,
                 expect_db=_status(57, "cancelled")),
        ),
    ),
    # R27: ada's lines only onto pending orders
    Scenario(
        "h3 ada adds pens to her orders in each state",
        given={"orders": [_order(58, 3), _order(74, 3, "paid"), _order(75, 3, "cancelled")]},
        steps=(
            Step("POST", "/orders/74/items", user="ada", json={"product_id": 1, "quantity": 3},
                 expect_status=409, expect_db=_lines({"order_id": 74}, 0)),
            Step("POST", "/orders/75/items", user="ada", json={"product_id": 1, "quantity": 3},
                 expect_status=409, expect_db=_lines({"order_id": 75}, 0)),
            Step("POST", "/orders/58/items", user="ada", json={"product_id": 1, "quantity": 3},
                 expect_status=201),
        ),
    ),
)

UNCHECKED = (
    *minishop.spec().unchecked,
    Unchecked("a line's price is the product's price when it is added", concerns="OrderItem.price"),
    Unchecked("the stored quantity is the requested one and stock drops by it", concerns="OrderItem"),
    Unchecked("unpaid orders are cancelled after 7 days", concerns="Order.status"),
    Unchecked("at most 20 lines per buyer per minute", concerns="OrderItem"),
    Unchecked("a buyer's pending totals stay at or below 500.0", concerns="Order.total"),
    Unchecked("a line's price never exceeds its product's price", concerns="OrderItem.price"),
    Unchecked("the order list is sorted by id, at most 100", concerns="Order"),
    Unchecked("only an admin marks an order shipped", concerns="Order.status"),
    Unchecked("a line is refused over 100 units or without enough stock", concerns="OrderItem"),
    Unchecked("a cancel keeps the order's total", concerns="Order.total"),
    Unchecked("adding a line grows the total by quantity times price", concerns="Order.total"),
)


def spec() -> Spec:
    base = minishop.spec()
    return Spec(
        profile=base.profile,
        programs=dict(base.programs),
        machines=base.machines,
        invariants=INVARIANTS,
        scenarios=SCENARIOS,
        unchecked=UNCHECKED,
        users=dict(base.users),
    )


SPEC = spec()
