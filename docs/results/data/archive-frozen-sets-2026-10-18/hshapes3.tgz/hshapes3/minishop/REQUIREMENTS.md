# Mini shop

## Orders

- A buyer can cancel their own pending order, and cancelling it again is refused with 409.
- A buyer can add a line to a pending order and the stored line has the requested quantity.
- An order's total is the sum of its lines.
- Stock is never negative.
- An order moves from pending to paid or cancelled, and from paid to shipped.

## Order numbers and line values

- Order numbers in a read path are 32-bit: Ann reads her order 2147483647 (200), and a read naming any order number from 2147483648 up to 9223372036854775807 finds no order and is answered 404.
- A line can only be added to an order numbered 1 or more: Ann adding one ink (product 2) to her order 1 is answered 201, and the same request for order 0 or a negative order number is answered 404 with no line stored.
- Cancels go through 32-bit order numbers only: Ben cancels his pending order 2147483647 (200), and a cancel naming any order number from 2147483648 up to 9223372036854775807 is answered 404 and changes nothing.
- A line's product_id must be 1 or more: Ben adding two pens (product 1) to his order 3 is answered 201, and a product_id of 0 or less is rejected as invalid input (422) with no line stored.
- An order's total is never negative.
- One line orders at most 100 units: with enough stock, a line of 100 units is answered 201, and a line of 101 units or more is rejected as invalid input (422) with no line stored.
- A line's stored price is never negative.

## Line limits

- An order holds at most two ink lines (product 2): a first and a second ink line are answered 201 when no other rule refuses them, and a third ink line is refused with 409 and not stored.
- One order holds at most three lines of the same product: while fewer than three exist, a further line of that product is answered 201 when no other rule refuses it, and a fourth line of that product in that order is refused with 409 and not stored.
- One order holds at most one ten-unit line of each product: a first line of exactly 10 units is answered 201 when no other rule refuses it, and a second 10-unit line of the same product in that order is refused with 409 and not stored.
- An order holds at most four lines in all: while fewer than four exist, a further line is answered 201 when no other rule refuses it, and a fifth line is refused with 400 and not stored.

## Who sees and changes an order

- A buyer cannot see an admin's order: Ada reads her order 4 (200), Ann asking for order 4 gets 404, and a request without a token gets 401.
- Only its buyer can cancel a buyer's order: Ann cancels her pending order (200, it becomes cancelled); Ben trying the same cancel gets 404 and the order stays as it was; without a token the answer is 401 and nothing changes.
- An admin has no extra access to a buyer's order: Ada reading or cancelling Ben's order 3 gets 404 and the order is unchanged, while Ben himself can read it and cancel it; without a token the answer is 401.
- A paid order is private to its buyer: Ann reads her paid order 2 (200), Ben gets 404, and a request without a token gets 401.
- A buyer cannot cancel an admin's order: Ben cancelling Ada's order 4 gets 404 and it stays pending, Ada herself can cancel it (200), and without a token the answer is 401 with nothing changed.
- A shipped order stays private: Ben reads his shipped order (200), Ann asking for it gets 404, and a request without a token gets 401.

## Order states

- An admin cancels her own orders like any buyer: Ada's pending order becomes cancelled (200); cancelling her paid, shipped or already cancelled order is refused with 409 and the order keeps its state.
- Lines go only onto pending orders: Ben adding ink to his pending order is answered 201; adding to his paid, shipped or cancelled order is refused with 409 and no line is stored.
- A buyer can read their own order in every state: Ann's pending, paid, shipped and cancelled orders are each answered 200.
- A buyer's cancel moves only a pending order: Ben's pending order becomes cancelled (200); his paid, shipped or already cancelled order answers 409 and keeps its state.
- An admin's own orders take lines only while pending: Ada adding three pens to her pending order is answered 201; adding to her paid, shipped or cancelled order is refused with 409 and no line is stored.

## Rules no form states

- A line's price is the product's price at the moment the line is added.
- The stored line has the quantity that was asked for, and the product's stock drops by exactly that quantity.
- A pending order that is not paid within 7 days is cancelled.
- A buyer adds at most 20 lines per minute.
- A buyer's pending orders total at most 500.0 together.
- A line's price is never above the current price of its product.
- The order list is sorted by order number and shows at most 100 orders.
- Only an admin may mark an order shipped.
- A line is refused when its quantity is over 100 or when the product's stock is too low for it.
- Cancelling an order keeps its total as it was.
- After a line is added, the order's total has grown by the line's quantity times its price.
