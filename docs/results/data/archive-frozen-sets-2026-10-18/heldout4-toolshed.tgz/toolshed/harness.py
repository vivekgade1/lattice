"""Harness for the Toolshed gRPC server.

build_db(path) applies the schema the server ships with
(internal/storage/schema/*.sql, also embedded in the Go binary) and seeds
fixture rows. make_app(db_path) compiles cmd/toolshedd into a temporary
directory and describes how to start it.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import sqlite3
import subprocess
import tempfile
from pathlib import Path

from lattice.importer.transport import AuthDriver
from lattice.spec.process import ProcessApp, process_runtime

APP_ROOT = Path(__file__).resolve().parent
PROTO_ROOT = APP_ROOT / "proto"
SCHEMA_DIR = APP_ROOT / "internal" / "storage" / "schema"

PROTOS = [
    str(PROTO_ROOT / "toolshed" / "options" / "v1" / "access.proto"),
    str(PROTO_ROOT / "toolshed" / "auth" / "v1" / "session.proto"),
    str(PROTO_ROOT / "toolshed" / "catalog" / "v1" / "equipment.proto"),
    str(PROTO_ROOT / "toolshed" / "booking" / "v1" / "reservation.proto"),
    str(PROTO_ROOT / "toolshed" / "members" / "v1" / "member.proto"),
    str(PROTO_ROOT / "toolshed" / "billing" / "v1" / "invoice.proto"),
]
PROTO_PATHS = [str(PROTO_ROOT)]

# handle -> (login name, password)
USERS: dict[str, tuple[str, str]] = {
    "alice": ("alice", "anvil-alice-77"),
    "carol": ("carol", "chisel-carol-42"),
    "bob": ("bob", "bandsaw-bob-19"),
    "dave": ("dave", "dowel-dave-08"),
    "erin": ("erin", "epoxy-erin-31"),
    "frank": ("frank", "file-frank-56"),
}

ROLES = {
    "alice": "admin",
    "carol": "staff",
    "bob": "member",
    "dave": "member",
    "erin": "member",
    "frank": "member",
}

DISPLAY_NAMES = {
    "alice": "Alice Admin",
    "carol": "Carol Counter",
    "bob": "Bob Builder",
    "dave": "Dave Dovetail",
    "erin": "Erin Edge",
    "frank": "Frank Fret",
}

RPC_LOGIN = ("toolshed.auth.v1.SessionService", "Login")

AUTH = AuthDriver.rpc(
    "toolshed.auth.v1.SessionService",
    "Login",
    USERS,
    username_field="username",
    password_field="password",
    token_field="token",
)

RUNTIME = process_runtime(framework="go", auth=AUTH)

# (asset_tag, name, category, status, location)
TOOLS = [
    ("DRL-001", "Cordless drill", "power", "AVAILABLE", "Bay A"),
    ("SAW-002", "Circular saw", "power", "AVAILABLE", "Bay A"),
    ("LTH-003", "Wood lathe", "machine", "AVAILABLE", "Bay C"),
    ("GRD-004", "Angle grinder", "power", "AVAILABLE", "Bay B"),
    ("SND-005", "Orbital sander", "power", "AVAILABLE", "Bay B"),
    ("PLN-006", "Thickness planer", "machine", "AVAILABLE", "Bay C"),
    ("CLP-007", "Bar clamp set", "hand", "AVAILABLE", "Wall 1"),
    ("WLD-008", "MIG welder", "machine", "RETIRED", "Store room"),
    ("JIG-009", "Jigsaw", "power", "AVAILABLE", "Bay A"),
    ("MTR-010", "Miter saw", "machine", "AVAILABLE", "Bay C"),
]

PBKDF2_ITERATIONS = 20000


def _hash_password(username: str, password: str) -> str:
    # Deterministic salt keeps fixture databases byte-stable between builds.
    salt = hashlib.sha256(b"toolshed-fixture:" + username.encode()).digest()[:16]
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS, 32)
    return f"pbkdf2-sha256${PBKDF2_ITERATIONS}${salt.hex()}${key.hex()}"


def build_db(path) -> None:
    """Create and seed the SQLite database at path."""
    path = str(path)
    if os.path.exists(path):
        os.remove(path)
    conn = sqlite3.connect(path)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        for schema_file in sorted(SCHEMA_DIR.glob("*.sql")):
            conn.executescript(schema_file.read_text())
        for handle, (username, password) in USERS.items():
            conn.execute(
                "INSERT INTO members (username, display_name, role, password_hash) VALUES (?, ?, ?, ?)",
                (username, DISPLAY_NAMES[handle], ROLES[handle], _hash_password(username, password)),
            )
        conn.executemany(
            "INSERT INTO tools (asset_tag, name, category, status, location) VALUES (?, ?, ?, ?, ?)",
            TOOLS,
        )
        # One standing booking: bob holds the clamp set next spring.
        conn.execute(
            """INSERT INTO reservations (tool_id, member_id, booked_by, starts_at, ends_at, status, note)
               SELECT t.id, m.id, m.id, '2031-04-01T09:00:00Z', '2031-04-01T17:00:00Z', 'RESERVED', 'glue-up'
                 FROM tools t, members m WHERE t.asset_tag = 'CLP-007' AND m.username = 'bob'"""
        )
        conn.execute(
            """INSERT INTO reservation_events (reservation_id, kind, actor_id)
               SELECT r.id, 'created', r.member_id FROM reservations r"""
        )
        conn.commit()
    finally:
        conn.close()


def _go() -> str:
    found = shutil.which("go")
    if found:
        return found
    return "/usr/local/go/bin/go"


def make_app(db_path):
    """Compile the server outside the app tree and describe how to run it."""
    out_dir = tempfile.mkdtemp(prefix="toolshedd-")
    binary = os.path.join(out_dir, "toolshedd")
    env = dict(os.environ)
    env.setdefault("CGO_ENABLED", "0")
    subprocess.run(
        [_go(), "build", "-o", binary, "./cmd/toolshedd"],
        cwd=str(APP_ROOT),
        env=env,
        check=True,
    )
    return ProcessApp(
        argv=[binary],
        db_path=str(db_path),
        env={"TOOLSHED_WATCH_POLL_MS": "100"},
        port_env="PORT",
        db_env="DB_PATH",
        ready="grpc",
        protos=list(PROTOS),
        proto_paths=list(PROTO_PATHS),
        proto_root=str(PROTO_ROOT),
    )
