// Command toolshedd serves the Toolshed gRPC API.
package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"

	"toolshed/internal/app"
	"toolshed/internal/config"
)

func main() {
	cfg, err := config.FromEnv()
	if err != nil {
		log.Fatal(err)
	}
	a, err := app.Build(context.Background(), cfg)
	if err != nil {
		log.Fatal(err)
	}
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sig
		a.Stop()
	}()
	log.Printf("toolshedd listening on :%d (db %s)", cfg.Port, cfg.DBPath)
	if err := a.Serve(); err != nil {
		log.Fatal(err)
	}
}
