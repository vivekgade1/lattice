// Command replay runs every flow in truth.json against a Toolshed server and
// exits 0 only if all of them pass.
//
//	replay -truth truth.json -addr localhost:50051
//	    runs all flows, in order, against one running server.
//	replay -truth truth.json -server ./toolshedd -db-template seeded.db
//	    starts a fresh server on a copy of the seeded database for each flow.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"time"

	"google.golang.org/grpc/codes"
)

func main() {
	truthPath := flag.String("truth", "truth.json", "path to truth.json")
	addr := flag.String("addr", "", "address of a running server (shared by all flows)")
	serverBin := flag.String("server", "", "server binary to start per flow")
	dbTemplate := flag.String("db-template", "", "seeded database copied for each flow (with -server)")
	only := flag.String("flow", "", "run only the flow with this name")
	flag.Parse()

	truth, err := loadTruth(*truthPath)
	if err != nil {
		fatal(err)
	}
	if *addr == "" && (*serverBin == "" || *dbTemplate == "") {
		fatal(fmt.Errorf("give -addr, or -server with -db-template"))
	}

	var shared *client
	if *addr != "" {
		if shared, err = dial(*addr); err != nil {
			fatal(err)
		}
		defer shared.close()
		if err := shared.waitHealthy(10 * time.Second); err != nil {
			fatal(err)
		}
	}

	failed, ran := 0, 0
	for _, f := range truth.Flows {
		if *only != "" && f.Name != *only {
			continue
		}
		ran++
		var ferr error
		if shared != nil {
			ferr = runFlow(shared, f)
		} else {
			ferr = withFreshServer(*serverBin, *dbTemplate, func(c *client) error { return runFlow(c, f) })
		}
		if ferr != nil {
			failed++
			fmt.Printf("FAIL %s: %v\n", f.Name, ferr)
		} else {
			fmt.Printf("ok   %s (%d steps)\n", f.Name, len(f.Steps))
		}
	}
	fmt.Printf("%d/%d flows passed\n", ran-failed, ran)
	if failed > 0 || ran == 0 {
		os.Exit(1)
	}
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "replay:", err)
	os.Exit(2)
}

func runFlow(c *client, f flow) error {
	responses := make([]any, len(f.Steps))
	for i, st := range f.Steps {
		req := map[string]any{}
		for k, v := range st.Request {
			req[k] = v
		}
		for _, l := range f.Links {
			if l.ToStep != i {
				continue
			}
			if l.FromStep >= i || responses[l.FromStep] == nil {
				return fmt.Errorf("step %d: link from step %d has no response", i, l.FromStep)
			}
			v, ok := lookup(responses[l.FromStep], l.FromField)
			if !ok {
				return fmt.Errorf("step %d: step %d response has no %s", i, l.FromStep, l.FromField)
			}
			assign(req, l.ToField, v)
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		token := ""
		if st.As != nil {
			t, err := c.tokenFor(ctx, *st.As)
			if err != nil {
				cancel()
				return fmt.Errorf("step %d: %w", i, err)
			}
			token = t
		}
		code, doc, err := c.call(ctx, st.RPC, req, token)
		cancel()
		if err != nil {
			return fmt.Errorf("step %d (%s): %w", i, st.RPC, err)
		}
		if err := check(st.Expect, code, doc); err != nil {
			return fmt.Errorf("step %d (%s): %w", i, st.RPC, err)
		}
		responses[i] = doc
	}
	return nil
}

func check(expect map[string]json.RawMessage, code codes.Code, doc any) error {
	var want string
	if raw, ok := expect["code"]; ok {
		if err := json.Unmarshal(raw, &want); err != nil {
			return fmt.Errorf("expect.code: %w", err)
		}
	}
	if want == "" {
		want = "OK"
	}
	if code.String() != want {
		return fmt.Errorf("code %s, want %s", code, want)
	}
	for path, raw := range expect {
		if path == "code" {
			continue
		}
		var wantVal any
		if err := json.Unmarshal(raw, &wantVal); err != nil {
			return fmt.Errorf("expect.%s: %w", path, err)
		}
		got, ok := lookup(doc, path)
		if !ok {
			return fmt.Errorf("response has no %s", path)
		}
		if !sameValue(wantVal, got) {
			return fmt.Errorf("%s = %v, want %v", path, got, wantVal)
		}
	}
	return nil
}

// withFreshServer copies the template database, starts the server on a free
// port, runs fn against it and stops the server.
func withFreshServer(bin, template string, fn func(*client) error) error {
	dir, err := os.MkdirTemp("", "replay-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dir)
	db := filepath.Join(dir, "toolshed.db")
	if err := copyFile(template, db); err != nil {
		return err
	}
	port, err := freePort()
	if err != nil {
		return err
	}
	cmd := exec.Command(bin)
	cmd.Env = append(os.Environ(), "PORT="+strconv.Itoa(port), "DB_PATH="+db, "TOOLSHED_WATCH_POLL_MS=50")
	cmd.Stdout, cmd.Stderr = io.Discard, os.Stderr
	if err := cmd.Start(); err != nil {
		return err
	}
	defer func() {
		cmd.Process.Signal(os.Interrupt)
		done := make(chan struct{})
		go func() { cmd.Wait(); close(done) }()
		select {
		case <-done:
		case <-time.After(3 * time.Second):
			cmd.Process.Kill()
			<-done
		}
	}()
	c, err := dial(fmt.Sprintf("127.0.0.1:%d", port))
	if err != nil {
		return err
	}
	defer c.close()
	if err := c.waitHealthy(10 * time.Second); err != nil {
		return err
	}
	return fn(c)
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

func freePort() (int, error) {
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0, err
	}
	defer l.Close()
	return l.Addr().(*net.TCPAddr).Port, nil
}
