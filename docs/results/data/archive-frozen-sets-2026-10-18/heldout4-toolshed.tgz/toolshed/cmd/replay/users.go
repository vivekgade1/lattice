package main

const loginRPC = "toolshed.auth.v1.SessionService/Login"

// credentials mirrors USERS in harness.py: handle -> (username, password).
var credentials = map[string][2]string{
	"alice": {"alice", "anvil-alice-77"},
	"carol": {"carol", "chisel-carol-42"},
	"bob":   {"bob", "bandsaw-bob-19"},
	"dave":  {"dave", "dowel-dave-08"},
	"erin":  {"erin", "epoxy-erin-31"},
	"frank": {"frank", "file-frank-56"},
}
