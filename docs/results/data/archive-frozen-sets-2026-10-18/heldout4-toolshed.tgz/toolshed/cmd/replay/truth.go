package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// The parts of truth.json the replay consumes.
type truthFile struct {
	Schema string `json:"schema"`
	Flows  []flow `json:"flows"`
}

type flow struct {
	Name  string `json:"name"`
	Steps []step `json:"steps"`
	Links []link `json:"links"`
}

type step struct {
	RPC     string                     `json:"rpc"`
	Request map[string]any             `json:"request"`
	Expect  map[string]json.RawMessage `json:"expect"`
	As      *string                    `json:"as"`
}

type link struct {
	FromStep  int    `json:"from_step"`
	FromField string `json:"from_field"`
	ToStep    int    `json:"to_step"`
	ToField   string `json:"to_field"`
}

func loadTruth(path string) (*truthFile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var t truthFile
	if err := json.Unmarshal(raw, &t); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	return &t, nil
}

// lookup walks a dotted path ("reservation.id", "tools.0.asset_tag") through
// decoded JSON. A final "#" segment yields the length of a list.
func lookup(doc any, path string) (any, bool) {
	cur := doc
	for _, seg := range strings.Split(path, ".") {
		switch v := cur.(type) {
		case map[string]any:
			next, ok := v[seg]
			if !ok {
				return nil, false
			}
			cur = next
		case []any:
			if seg == "#" {
				return float64(len(v)), true
			}
			i, err := strconv.Atoi(seg)
			if err != nil || i < 0 || i >= len(v) {
				return nil, false
			}
			cur = v[i]
		default:
			return nil, false
		}
	}
	return cur, true
}

// assign sets a dotted path in a request document, creating maps on the way.
func assign(doc map[string]any, path string, value any) {
	segs := strings.Split(path, ".")
	cur := doc
	for _, seg := range segs[:len(segs)-1] {
		next, ok := cur[seg].(map[string]any)
		if !ok {
			next = map[string]any{}
			cur[seg] = next
		}
		cur = next
	}
	cur[segs[len(segs)-1]] = value
}

// sameValue compares JSON scalars loosely: protojson renders int64 as a
// string, so 7 and "7" are equal.
func sameValue(want, got any) bool {
	return fmt.Sprint(want) == fmt.Sprint(got)
}
