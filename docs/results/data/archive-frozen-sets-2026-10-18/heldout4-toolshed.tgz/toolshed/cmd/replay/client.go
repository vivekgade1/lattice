package main

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	healthgrpc "google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/reflect/protoreflect"
	"google.golang.org/protobuf/reflect/protoregistry"
	"google.golang.org/protobuf/types/dynamicpb"

	// Generated packages register their descriptors for the lookups below.
	_ "toolshed/gen/go/toolshed/auth/v1"
	_ "toolshed/gen/go/toolshed/billing/v1"
	_ "toolshed/gen/go/toolshed/booking/v1"
	_ "toolshed/gen/go/toolshed/catalog/v1"
	_ "toolshed/gen/go/toolshed/members/v1"
)

// client is a schema-driven unary caller: it resolves an rpc key
// ("pkg.Service/Method") against the compiled-in descriptors.
type client struct {
	conn   *grpc.ClientConn
	tokens map[string]string
}

func dial(addr string) (*client, error) {
	conn, err := grpc.NewClient(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}
	return &client{conn: conn, tokens: map[string]string{}}, nil
}

func (c *client) close() { c.conn.Close() }

func (c *client) waitHealthy(timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	hc := healthgrpc.NewHealthClient(c.conn)
	for {
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		resp, err := hc.Check(ctx, &healthgrpc.HealthCheckRequest{})
		cancel()
		if err == nil && resp.GetStatus() == healthgrpc.HealthCheckResponse_SERVING {
			return nil
		}
		if time.Now().After(deadline) {
			return fmt.Errorf("server not healthy after %s: %v", timeout, err)
		}
		time.Sleep(100 * time.Millisecond)
	}
}

func method(rpc string) (protoreflect.MethodDescriptor, error) {
	name := strings.Replace(rpc, "/", ".", 1)
	d, err := protoregistry.GlobalFiles.FindDescriptorByName(protoreflect.FullName(name))
	if err != nil {
		return nil, fmt.Errorf("unknown rpc %s: %w", rpc, err)
	}
	md, ok := d.(protoreflect.MethodDescriptor)
	if !ok {
		return nil, fmt.Errorf("%s is not a method", rpc)
	}
	if md.IsStreamingClient() || md.IsStreamingServer() {
		return nil, fmt.Errorf("%s is streaming; flows replay unary rpcs only", rpc)
	}
	return md, nil
}

// call sends request (JSON-shaped) to rpc and returns the code and the
// response decoded to generic JSON.
func (c *client) call(ctx context.Context, rpc string, request map[string]any, token string) (codes.Code, any, error) {
	md, err := method(rpc)
	if err != nil {
		return codes.Unknown, nil, err
	}
	in := dynamicpb.NewMessage(md.Input())
	raw, err := json.Marshal(request)
	if err != nil {
		return codes.Unknown, nil, err
	}
	if err := protojson.Unmarshal(raw, in); err != nil {
		return codes.Unknown, nil, fmt.Errorf("request for %s: %w", rpc, err)
	}
	out := dynamicpb.NewMessage(md.Output())
	if token != "" {
		ctx = metadata.AppendToOutgoingContext(ctx, "authorization", "Bearer "+token)
	}
	callErr := c.conn.Invoke(ctx, "/"+rpc, in, out)
	if callErr != nil {
		return status.Code(callErr), nil, nil
	}
	js, err := protojson.MarshalOptions{UseProtoNames: true, EmitUnpopulated: true}.Marshal(out)
	if err != nil {
		return codes.OK, nil, err
	}
	var doc any
	if err := json.Unmarshal(js, &doc); err != nil {
		return codes.OK, nil, err
	}
	return codes.OK, doc, nil
}

// tokenFor logs handle in once per connection and caches the token.
func (c *client) tokenFor(ctx context.Context, handle string) (string, error) {
	if t, ok := c.tokens[handle]; ok {
		return t, nil
	}
	cred, ok := credentials[handle]
	if !ok {
		return "", fmt.Errorf("no credentials for handle %q", handle)
	}
	code, doc, err := c.call(ctx, loginRPC, map[string]any{"username": cred[0], "password": cred[1]}, "")
	if err != nil {
		return "", err
	}
	if code != codes.OK {
		return "", fmt.Errorf("login as %s: %s", handle, code)
	}
	tok, _ := lookup(doc, "token")
	s, _ := tok.(string)
	c.tokens[handle] = s
	return s, nil
}
