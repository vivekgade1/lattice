# Idioms

## Service wiring
- toolshed.auth.v1.SessionService: self-registration from `init()` into the `modreg` installer registry (internal/auth/register.go), activated by a blank import and `modreg.InstallAll` in internal/app/wire.go; the installer calls `RegisterService` with the generated descriptor.
- toolshed.catalog.v1.EquipmentService: a decorated copy of the generated `ServiceDesc` (every method handler wrapped) built by `catalog.ServiceDesc()` (internal/catalog/descriptor.go) and passed to `gs.RegisterService` in internal/app/wire.go.
- toolshed.booking.v1.ReservationService: a constructed module object, `booking.NewModule(...).Mount(gs)` (internal/booking/module.go), whose method calls the generated `RegisterReservationServiceServer`.
- toolshed.members.v1.MemberService: a functional option, `grpcserver.WithService(desc, impl)`, collected by the server builder `grpcserver.New` (internal/platform/grpcserver/builder.go), which registers it as it constructs the server.
- toolshed.billing.v1.InvoiceService: declared in proto/toolshed/billing/v1/invoice.proto and generated, never registered.
- grpc.health.v1.Health (standard): direct call to the generated `healthgrpc.RegisterHealthServer` in internal/app/wire.go.

## Error idioms
- SessionService: inline `status.Error(codes.X, msg)` returned straight from each handler (internal/auth/sessions.go).
- EquipmentService: handlers return plain sentinel errors (internal/catalog/errors.go); the decorated descriptor's `translate()` maps them to codes via the `codeFor` table (internal/catalog/descriptor.go).
- ReservationService: a package error type `*refusal` with a `GRPCStatus() *status.Status` method that grpc-go reads off the returned error (internal/booking/errors.go).
- MemberService: rich status, `status.New(code, msg).WithDetails(&errdetails.ErrorInfo{Reason: ...}).Err()` through `deny()` (internal/members/deny.go).
- Auth gate: `status.Error(codes.Unauthenticated, ...)` from the interceptor (internal/platform/authn/gate.go).

## Auth mechanism
- Audience declared per method in the .proto files with the custom method option `(toolshed.options.v1.audience)` (proto/toolshed/options/v1/access.proto); the `authn.Gate` unary and stream interceptors read that option from the protobuf descriptor registry at call time; methods without it are member-only, methods outside the `toolshed.` namespace are admitted.
- Bearer tokens: `Login` mints a random token, stores its sha256 in `sessions`; the gate looks the hash up and attaches a `Principal` to the context.
- Roles (member < staff < admin) are checked in handlers with `Principal.AtLeast`; owner checks compare `reservations.member_id` with the caller (booking `load`), and `sessions.member_id` in the Logout delete.

## Schema
- internal/storage/schema/0001_init.sql, embedded with `go:embed` into the storage package and applied by `storage.Migrate` at server start; harness.py `build_db` runs the same file before seeding.
