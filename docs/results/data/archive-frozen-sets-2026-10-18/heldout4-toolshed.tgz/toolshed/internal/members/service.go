// Package members serves toolshed.members.v1.MemberService.
package members

import (
	"context"
	"errors"

	"google.golang.org/grpc/codes"

	membersv1 "toolshed/gen/go/toolshed/members/v1"
	"toolshed/internal/platform/authn"
	"toolshed/internal/storage"
)

// Directory is the slice of storage the member service needs.
type Directory interface {
	MemberByUsername(ctx context.Context, username string) (storage.Member, error)
	ListMembers(ctx context.Context, role string) ([]storage.Member, error)
	UpdateMember(ctx context.Context, id int64, patch storage.MemberPatch) (storage.Member, error)
	DeleteMember(ctx context.Context, id int64) error
}

// Service implements membersv1.MemberServiceServer.
type Service struct {
	membersv1.UnimplementedMemberServiceServer
	dir Directory
}

// New returns a Service over dir.
func New(dir Directory) *Service { return &Service{dir: dir} }

func toProto(m storage.Member) *membersv1.Member {
	return &membersv1.Member{Id: m.ID, Username: m.Username, DisplayName: m.DisplayName, Role: m.Role}
}

func (s *Service) find(ctx context.Context, username string) (storage.Member, error) {
	m, err := s.dir.MemberByUsername(ctx, username)
	if errors.Is(err, storage.ErrNotFound) {
		return m, deny(codes.NotFound, reasonUnknownMember, "no member named "+username)
	} else if err != nil {
		return m, deny(codes.Internal, reasonStorage, "member lookup failed")
	}
	return m, nil
}

func (s *Service) GetMember(ctx context.Context, req *membersv1.GetMemberRequest) (*membersv1.GetMemberResponse, error) {
	caller, _ := authn.FromContext(ctx)
	name := req.GetUsername()
	if name == "" {
		name = caller.Username
	}
	m, err := s.find(ctx, name)
	if err != nil {
		return nil, err
	}
	return &membersv1.GetMemberResponse{Member: toProto(m)}, nil
}

func (s *Service) ListMembers(ctx context.Context, req *membersv1.ListMembersRequest) (*membersv1.ListMembersResponse, error) {
	caller, _ := authn.FromContext(ctx)
	if !caller.AtLeast(authn.RoleStaff) {
		return nil, deny(codes.PermissionDenied, reasonStaffOnly, "listing members is a staff function")
	}
	rows, err := s.dir.ListMembers(ctx, req.GetRole())
	if err != nil {
		return nil, deny(codes.Internal, reasonStorage, "member list failed")
	}
	resp := &membersv1.ListMembersResponse{}
	for _, m := range rows {
		resp.Members = append(resp.Members, toProto(m))
	}
	return resp, nil
}

var assignable = map[string]bool{authn.RoleMember: true, authn.RoleStaff: true, authn.RoleAdmin: true}

func (s *Service) UpdateMember(ctx context.Context, req *membersv1.UpdateMemberRequest) (*membersv1.UpdateMemberResponse, error) {
	caller, _ := authn.FromContext(ctx)
	name := req.GetUsername()
	if name == "" {
		name = caller.Username
	}
	if name != caller.Username && !caller.AtLeast(authn.RoleAdmin) {
		return nil, deny(codes.PermissionDenied, reasonAdminOnly, "only admins may edit other members")
	}
	if req.GetRole() != "" {
		if !caller.AtLeast(authn.RoleAdmin) {
			return nil, deny(codes.PermissionDenied, reasonRoleField, "only admins may set role")
		}
		if !assignable[req.GetRole()] {
			return nil, deny(codes.InvalidArgument, reasonBadRole, "role must be member, staff or admin")
		}
	}
	if req.GetDisplayName() == "" && req.GetRole() == "" {
		return nil, deny(codes.InvalidArgument, reasonEmptyPatch, "nothing to update")
	}
	target, err := s.find(ctx, name)
	if err != nil {
		return nil, err
	}
	m, err := s.dir.UpdateMember(ctx, target.ID, storage.MemberPatch{
		DisplayName: req.GetDisplayName(), Role: req.GetRole(),
	})
	if err != nil {
		return nil, deny(codes.Internal, reasonStorage, "member update failed")
	}
	return &membersv1.UpdateMemberResponse{Member: toProto(m)}, nil
}

func (s *Service) DeleteAccount(ctx context.Context, req *membersv1.DeleteAccountRequest) (*membersv1.DeleteAccountResponse, error) {
	caller, _ := authn.FromContext(ctx)
	if req.GetConfirmUsername() != caller.Username {
		return nil, deny(codes.InvalidArgument, reasonConfirm, "confirm_username must equal your username")
	}
	if caller.Role == authn.RoleAdmin {
		admins, err := s.dir.ListMembers(ctx, authn.RoleAdmin)
		if err != nil {
			return nil, deny(codes.Internal, reasonStorage, "member list failed")
		}
		if len(admins) <= 1 {
			return nil, deny(codes.FailedPrecondition, reasonLastAdmin, "the last admin cannot delete their account")
		}
	}
	if err := s.dir.DeleteMember(ctx, caller.MemberID); err != nil {
		return nil, deny(codes.Internal, reasonStorage, "account deletion failed")
	}
	return &membersv1.DeleteAccountResponse{Deleted: true}, nil
}
