package members

import (
	"google.golang.org/genproto/googleapis/rpc/errdetails"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

const errorDomain = "members.toolshed"

// Machine-readable reasons carried in the ErrorInfo detail.
const (
	reasonUnknownMember = "UNKNOWN_MEMBER"
	reasonStaffOnly     = "STAFF_ONLY"
	reasonAdminOnly     = "ADMIN_ONLY"
	reasonRoleField     = "ROLE_FIELD_ADMIN_ONLY"
	reasonBadRole       = "INVALID_ROLE"
	reasonEmptyPatch    = "EMPTY_PATCH"
	reasonConfirm       = "CONFIRMATION_MISMATCH"
	reasonLastAdmin     = "LAST_ADMIN"
	reasonStorage       = "STORAGE"
)

// deny builds a rich status: the code, a human message, and an ErrorInfo
// detail that clients switch on instead of parsing the message.
func deny(code codes.Code, reason, msg string) error {
	st := status.New(code, msg)
	if withInfo, err := st.WithDetails(&errdetails.ErrorInfo{Reason: reason, Domain: errorDomain}); err == nil {
		st = withInfo
	}
	return st.Err()
}
