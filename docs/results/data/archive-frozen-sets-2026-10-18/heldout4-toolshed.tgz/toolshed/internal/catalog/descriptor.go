package catalog

import (
	"context"
	"errors"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	catalogv1 "toolshed/gen/go/toolshed/catalog/v1"
)

// codeFor maps domain errors to transport codes. First match wins.
var codeFor = []struct {
	err  error
	code codes.Code
}{
	{ErrAssetTagRequired, codes.InvalidArgument},
	{ErrNameRequired, codes.InvalidArgument},
	{ErrLocationRequired, codes.InvalidArgument},
	{ErrToolNotFound, codes.NotFound},
	{ErrDuplicateTag, codes.AlreadyExists},
	{ErrStaffOnly, codes.PermissionDenied},
	{ErrAdminOnly, codes.PermissionDenied},
	{ErrToolInUse, codes.FailedPrecondition},
	{ErrAlreadyRetired, codes.FailedPrecondition},
}

// translate turns a handler error into a status error. Errors that already
// carry a status (from interceptors or request decoding) pass through.
func translate(err error) error {
	if err == nil {
		return nil
	}
	if _, ok := status.FromError(err); ok {
		return err
	}
	for _, m := range codeFor {
		if errors.Is(err, m.err) {
			return status.Error(m.code, m.err.Error())
		}
	}
	return status.Error(codes.Internal, "catalog: internal error")
}

// ServiceDesc returns a copy of the generated EquipmentService descriptor in
// which every method handler translates domain errors on the way out.
func ServiceDesc() *grpc.ServiceDesc {
	src := catalogv1.EquipmentService_ServiceDesc
	out := src
	out.Methods = make([]grpc.MethodDesc, len(src.Methods))
	for i, m := range src.Methods {
		inner := m.Handler
		out.Methods[i] = grpc.MethodDesc{
			MethodName: m.MethodName,
			Handler: func(srv any, ctx context.Context, dec func(any) error, ic grpc.UnaryServerInterceptor) (any, error) {
				resp, err := inner(srv, ctx, dec, ic)
				return resp, translate(err)
			},
		}
	}
	return &out
}
