package catalog

import "errors"

// Domain errors returned by the catalog handlers. They carry no transport
// code; the service descriptor built in descriptor.go maps them.
var (
	ErrAssetTagRequired = errors.New("asset_tag is required")
	ErrNameRequired     = errors.New("name is required")
	ErrLocationRequired = errors.New("location is required")
	ErrToolNotFound     = errors.New("no tool with that asset tag")
	ErrDuplicateTag     = errors.New("asset tag already registered")
	ErrStaffOnly        = errors.New("staff role required")
	ErrAdminOnly        = errors.New("admin role required")
	ErrToolInUse        = errors.New("tool is checked out")
	ErrAlreadyRetired   = errors.New("tool is already retired")
)
