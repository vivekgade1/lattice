// Package catalog serves toolshed.catalog.v1.EquipmentService.
package catalog

import (
	"context"
	"errors"

	catalogv1 "toolshed/gen/go/toolshed/catalog/v1"
	"toolshed/internal/platform/authn"
	"toolshed/internal/storage"
)

// Inventory is the slice of storage the catalog needs.
type Inventory interface {
	ToolByAssetTag(ctx context.Context, tag string) (storage.Tool, error)
	ListTools(ctx context.Context, category string, includeRetired bool) ([]storage.Tool, error)
	InsertTool(ctx context.Context, t storage.Tool) (storage.Tool, error)
	SetToolLocation(ctx context.Context, tag, location string) (storage.Tool, error)
	SetToolStatus(ctx context.Context, tag, status string) (storage.Tool, error)
	AppendAudit(ctx context.Context, actorID int64, method, outcome string) error
}

// Handler implements catalogv1.EquipmentServiceServer.
type Handler struct {
	catalogv1.UnimplementedEquipmentServiceServer
	inv Inventory
}

// NewHandler returns a Handler over inv.
func NewHandler(inv Inventory) *Handler { return &Handler{inv: inv} }

func toProto(t storage.Tool) *catalogv1.Tool {
	return &catalogv1.Tool{
		Id: t.ID, AssetTag: t.AssetTag, Name: t.Name, Category: t.Category,
		Status: t.Status, Location: t.Location,
	}
}

func (h *Handler) lookup(ctx context.Context, tag string) (storage.Tool, error) {
	if tag == "" {
		return storage.Tool{}, ErrAssetTagRequired
	}
	t, err := h.inv.ToolByAssetTag(ctx, tag)
	if errors.Is(err, storage.ErrNotFound) {
		return storage.Tool{}, ErrToolNotFound
	}
	return t, err
}

func (h *Handler) ListTools(ctx context.Context, req *catalogv1.ListToolsRequest) (*catalogv1.ListToolsResponse, error) {
	tools, err := h.inv.ListTools(ctx, req.GetCategory(), req.GetIncludeRetired())
	if err != nil {
		return nil, err
	}
	resp := &catalogv1.ListToolsResponse{}
	for _, t := range tools {
		resp.Tools = append(resp.Tools, toProto(t))
	}
	return resp, nil
}

func (h *Handler) GetTool(ctx context.Context, req *catalogv1.GetToolRequest) (*catalogv1.GetToolResponse, error) {
	t, err := h.lookup(ctx, req.GetAssetTag())
	if err != nil {
		return nil, err
	}
	return &catalogv1.GetToolResponse{Tool: toProto(t)}, nil
}

func (h *Handler) CreateTool(ctx context.Context, req *catalogv1.CreateToolRequest) (*catalogv1.CreateToolResponse, error) {
	p, _ := authn.FromContext(ctx)
	if !p.AtLeast(authn.RoleAdmin) {
		return nil, ErrAdminOnly
	}
	if req.GetAssetTag() == "" {
		return nil, ErrAssetTagRequired
	}
	if req.GetName() == "" {
		return nil, ErrNameRequired
	}
	cat := req.GetCategory()
	if cat == "" {
		cat = "general"
	}
	t, err := h.inv.InsertTool(ctx, storage.Tool{
		AssetTag: req.GetAssetTag(), Name: req.GetName(), Category: cat, Location: req.GetLocation(),
	})
	if errors.Is(err, storage.ErrConflict) {
		return nil, ErrDuplicateTag
	}
	if err != nil {
		return nil, err
	}
	if err := h.inv.AppendAudit(ctx, p.MemberID, "CreateTool", t.AssetTag); err != nil {
		return nil, err
	}
	return &catalogv1.CreateToolResponse{Tool: toProto(t)}, nil
}

func (h *Handler) RelocateTool(ctx context.Context, req *catalogv1.RelocateToolRequest) (*catalogv1.RelocateToolResponse, error) {
	p, _ := authn.FromContext(ctx)
	if !p.AtLeast(authn.RoleStaff) {
		return nil, ErrStaffOnly
	}
	if req.GetLocation() == "" {
		return nil, ErrLocationRequired
	}
	if _, err := h.lookup(ctx, req.GetAssetTag()); err != nil {
		return nil, err
	}
	t, err := h.inv.SetToolLocation(ctx, req.GetAssetTag(), req.GetLocation())
	if err != nil {
		return nil, err
	}
	if err := h.inv.AppendAudit(ctx, p.MemberID, "RelocateTool", t.AssetTag); err != nil {
		return nil, err
	}
	return &catalogv1.RelocateToolResponse{Tool: toProto(t)}, nil
}

func (h *Handler) RetireTool(ctx context.Context, req *catalogv1.RetireToolRequest) (*catalogv1.RetireToolResponse, error) {
	p, _ := authn.FromContext(ctx)
	if !p.AtLeast(authn.RoleAdmin) {
		return nil, ErrAdminOnly
	}
	cur, err := h.lookup(ctx, req.GetAssetTag())
	if err != nil {
		return nil, err
	}
	switch cur.Status {
	case storage.ToolCheckedOut:
		return nil, ErrToolInUse
	case storage.ToolRetired:
		return nil, ErrAlreadyRetired
	}
	t, err := h.inv.SetToolStatus(ctx, cur.AssetTag, storage.ToolRetired)
	if err != nil {
		return nil, err
	}
	if err := h.inv.AppendAudit(ctx, p.MemberID, "RetireTool", t.AssetTag); err != nil {
		return nil, err
	}
	return &catalogv1.RetireToolResponse{Tool: toProto(t)}, nil
}
