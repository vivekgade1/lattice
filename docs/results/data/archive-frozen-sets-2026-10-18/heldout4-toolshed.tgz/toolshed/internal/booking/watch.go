package booking

import (
	"time"

	bookingv1 "toolshed/gen/go/toolshed/booking/v1"
	"toolshed/internal/platform/authn"
	"toolshed/internal/storage"
)

func final(status string) bool {
	return status == storage.ResReturned || status == storage.ResCancelled
}

// WatchReservation sends a snapshot, then one message per recorded event,
// and ends once the reservation is returned or cancelled.
func (s *server) WatchReservation(req *bookingv1.WatchReservationRequest, stream bookingv1.ReservationService_WatchReservationServer) error {
	ctx := stream.Context()
	r, _, err := s.load(ctx, req.GetReservationId(), authn.RoleStaff)
	if err != nil {
		return err
	}
	if err := stream.Send(&bookingv1.ReservationEvent{Kind: "snapshot", Reservation: toProto(r)}); err != nil {
		return errStreamInterrupt
	}
	var last int64
	if evs, err := s.ledger.EventsAfter(ctx, r.ID, 0); err == nil && len(evs) > 0 {
		last = evs[len(evs)-1].ID
	}
	tick := time.NewTicker(s.poll)
	defer tick.Stop()
	for !final(r.Status) {
		select {
		case <-ctx.Done():
			return nil
		case <-tick.C:
		}
		evs, err := s.ledger.EventsAfter(ctx, r.ID, last)
		if err != nil {
			return errStorageFailure
		}
		for _, ev := range evs {
			if r, err = s.ledger.ReservationByID(ctx, ev.ReservationID); err != nil {
				return errStorageFailure
			}
			if err := stream.Send(&bookingv1.ReservationEvent{EventId: ev.ID, Kind: ev.Kind, Reservation: toProto(r)}); err != nil {
				return errStreamInterrupt
			}
			last = ev.ID
		}
	}
	return nil
}
