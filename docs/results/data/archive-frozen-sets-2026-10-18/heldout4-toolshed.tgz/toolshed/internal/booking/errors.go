package booking

import (
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// refusal is the booking package's error type. grpc-go asks any returned
// error for GRPCStatus(), so handlers return these as plain errors and the
// transport picks the code up from the method below.
type refusal struct {
	code   codes.Code
	reason string
}

func (r *refusal) Error() string { return r.reason }

// GRPCStatus implements the interface grpc-go's status package looks for.
func (r *refusal) GRPCStatus() *status.Status { return status.New(r.code, r.reason) }

func refusef(code codes.Code, format string, args ...any) *refusal {
	return &refusal{code: code, reason: fmt.Sprintf(format, args...)}
}

var (
	errNeedTag         = &refusal{codes.InvalidArgument, "asset_tag is required"}
	errBadWindow       = &refusal{codes.InvalidArgument, "starts_at and ends_at must be RFC 3339 times with ends_at after starts_at"}
	errNoSuchTool      = &refusal{codes.NotFound, "no tool with that asset tag"}
	errNoSuchHolder    = &refusal{codes.NotFound, "on_behalf_of names no member"}
	errNoSuchBooking   = &refusal{codes.NotFound, "reservation not found"}
	errProxyBooking    = &refusal{codes.PermissionDenied, "only staff may book on behalf of another member"}
	errNotYours        = &refusal{codes.PermissionDenied, "reservation belongs to another member"}
	errDeskOnly        = &refusal{codes.PermissionDenied, "hand-over is done by staff at the desk"}
	errToolRetired     = &refusal{codes.FailedPrecondition, "tool is retired"}
	errWrongState      = &refusal{codes.FailedPrecondition, "reservation is not in a state that allows this"}
	errWindowTaken     = &refusal{codes.AlreadyExists, "tool is already booked for part of that window"}
	errStorageFailure  = &refusal{codes.Internal, "booking storage failure"}
	errStreamInterrupt = &refusal{codes.Unavailable, "watch interrupted"}
)
