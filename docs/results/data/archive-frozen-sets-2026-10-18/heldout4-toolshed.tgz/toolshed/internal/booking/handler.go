// Package booking serves toolshed.booking.v1.ReservationService.
package booking

import (
	"context"
	"errors"
	"time"

	"google.golang.org/grpc/codes"

	bookingv1 "toolshed/gen/go/toolshed/booking/v1"
	"toolshed/internal/platform/authn"
	"toolshed/internal/storage"
)

const wireTime = "2006-01-02T15:04:05Z"

// Ledger is the slice of storage booking needs.
type Ledger interface {
	ToolByAssetTag(ctx context.Context, tag string) (storage.Tool, error)
	MemberByUsername(ctx context.Context, username string) (storage.Member, error)
	InsertReservation(ctx context.Context, n storage.NewReservation) (storage.Reservation, error)
	ReservationByID(ctx context.Context, id int64) (storage.Reservation, error)
	ReservationsForMember(ctx context.Context, memberID int64, status string) ([]storage.Reservation, error)
	TransitionReservation(ctx context.Context, id int64, t storage.Transition) (storage.Reservation, error)
	EventsAfter(ctx context.Context, reservationID, after int64) ([]storage.Event, error)
}

type server struct {
	bookingv1.UnimplementedReservationServiceServer
	ledger Ledger
	poll   time.Duration
}

func toProto(r storage.Reservation) *bookingv1.Reservation {
	return &bookingv1.Reservation{
		Id: r.ID, AssetTag: r.AssetTag, Holder: r.Holder, BookedBy: r.BookedBy,
		StartsAt: r.StartsAt, EndsAt: r.EndsAt, Status: r.Status, Note: r.Note,
	}
}

func parseWindow(start, end string) (string, string, error) {
	s, err1 := time.Parse(time.RFC3339, start)
	e, err2 := time.Parse(time.RFC3339, end)
	if err1 != nil || err2 != nil || !e.After(s) {
		return "", "", errBadWindow
	}
	return s.UTC().Format(wireTime), e.UTC().Format(wireTime), nil
}

func (s *server) CreateReservation(ctx context.Context, req *bookingv1.CreateReservationRequest) (*bookingv1.CreateReservationResponse, error) {
	caller, _ := authn.FromContext(ctx)
	if req.GetAssetTag() == "" {
		return nil, errNeedTag
	}
	start, end, err := parseWindow(req.GetStartsAt(), req.GetEndsAt())
	if err != nil {
		return nil, err
	}
	holderID := caller.MemberID
	if who := req.GetOnBehalfOf(); who != "" {
		if !caller.AtLeast(authn.RoleStaff) {
			return nil, errProxyBooking
		}
		m, err := s.ledger.MemberByUsername(ctx, who)
		if errors.Is(err, storage.ErrNotFound) {
			return nil, errNoSuchHolder
		} else if err != nil {
			return nil, errStorageFailure
		}
		holderID = m.ID
	}
	tool, err := s.ledger.ToolByAssetTag(ctx, req.GetAssetTag())
	if errors.Is(err, storage.ErrNotFound) {
		return nil, errNoSuchTool
	} else if err != nil {
		return nil, errStorageFailure
	}
	if tool.Status == storage.ToolRetired {
		return nil, errToolRetired
	}
	r, err := s.ledger.InsertReservation(ctx, storage.NewReservation{
		ToolID: tool.ID, MemberID: holderID, BookedBy: caller.MemberID,
		StartsAt: start, EndsAt: end, Note: req.GetNote(),
	})
	if errors.Is(err, storage.ErrOverlap) {
		return nil, errWindowTaken
	} else if err != nil {
		return nil, errStorageFailure
	}
	return &bookingv1.CreateReservationResponse{Reservation: toProto(r)}, nil
}

// load fetches a reservation and applies the owner check: the holder may see
// it, and so may anyone at or above bypass.
func (s *server) load(ctx context.Context, id int64, bypass string) (storage.Reservation, authn.Principal, error) {
	caller, _ := authn.FromContext(ctx)
	r, err := s.ledger.ReservationByID(ctx, id)
	if errors.Is(err, storage.ErrNotFound) {
		return r, caller, errNoSuchBooking
	} else if err != nil {
		return r, caller, errStorageFailure
	}
	if r.MemberID != caller.MemberID && !caller.AtLeast(bypass) {
		return r, caller, errNotYours
	}
	return r, caller, nil
}

func (s *server) GetReservation(ctx context.Context, req *bookingv1.GetReservationRequest) (*bookingv1.GetReservationResponse, error) {
	r, _, err := s.load(ctx, req.GetReservationId(), authn.RoleStaff)
	if err != nil {
		return nil, err
	}
	return &bookingv1.GetReservationResponse{Reservation: toProto(r)}, nil
}

var knownStatuses = map[string]bool{
	"": true, storage.ResReserved: true, storage.ResCheckedOut: true,
	storage.ResReturned: true, storage.ResCancelled: true,
}

func (s *server) ListReservations(ctx context.Context, req *bookingv1.ListReservationsRequest) (*bookingv1.ListReservationsResponse, error) {
	caller, _ := authn.FromContext(ctx)
	if !knownStatuses[req.GetStatus()] {
		return nil, refusef(codes.InvalidArgument, "unknown status %q", req.GetStatus())
	}
	rows, err := s.ledger.ReservationsForMember(ctx, caller.MemberID, req.GetStatus())
	if err != nil {
		return nil, errStorageFailure
	}
	resp := &bookingv1.ListReservationsResponse{}
	for _, r := range rows {
		resp.Reservations = append(resp.Reservations, toProto(r))
	}
	return resp, nil
}

func (s *server) move(ctx context.Context, id int64, t storage.Transition) (*bookingv1.Reservation, error) {
	r, err := s.ledger.TransitionReservation(ctx, id, t)
	switch {
	case errors.Is(err, storage.ErrNotFound):
		return nil, errNoSuchBooking
	case errors.Is(err, storage.ErrBadState):
		return nil, errWrongState
	case err != nil:
		return nil, errStorageFailure
	}
	return toProto(r), nil
}

func (s *server) CancelReservation(ctx context.Context, req *bookingv1.CancelReservationRequest) (*bookingv1.CancelReservationResponse, error) {
	_, caller, err := s.load(ctx, req.GetReservationId(), authn.RoleAdmin)
	if err != nil {
		return nil, err
	}
	r, err := s.move(ctx, req.GetReservationId(), storage.Transition{
		From: []string{storage.ResReserved}, To: storage.ResCancelled,
		Kind: "cancelled", ActorID: caller.MemberID, Note: req.GetReason(),
	})
	if err != nil {
		return nil, err
	}
	return &bookingv1.CancelReservationResponse{Reservation: r}, nil
}

func (s *server) CheckOut(ctx context.Context, req *bookingv1.CheckOutRequest) (*bookingv1.CheckOutResponse, error) {
	caller, _ := authn.FromContext(ctx)
	if !caller.AtLeast(authn.RoleStaff) {
		return nil, errDeskOnly
	}
	r, err := s.move(ctx, req.GetReservationId(), storage.Transition{
		From: []string{storage.ResReserved}, To: storage.ResCheckedOut,
		Kind: "checked_out", ActorID: caller.MemberID, ToolStatus: storage.ToolCheckedOut,
	})
	if err != nil {
		return nil, err
	}
	return &bookingv1.CheckOutResponse{Reservation: r}, nil
}

func (s *server) ReturnTool(ctx context.Context, req *bookingv1.ReturnToolRequest) (*bookingv1.ReturnToolResponse, error) {
	caller, _ := authn.FromContext(ctx)
	if !caller.AtLeast(authn.RoleStaff) {
		return nil, errDeskOnly
	}
	r, err := s.move(ctx, req.GetReservationId(), storage.Transition{
		From: []string{storage.ResCheckedOut}, To: storage.ResReturned,
		Kind: "returned", ActorID: caller.MemberID, Note: req.GetConditionNote(),
		ToolStatus: storage.ToolAvailable,
	})
	if err != nil {
		return nil, err
	}
	return &bookingv1.ReturnToolResponse{Reservation: r}, nil
}
