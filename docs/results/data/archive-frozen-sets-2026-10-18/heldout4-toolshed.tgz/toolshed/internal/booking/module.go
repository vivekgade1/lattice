package booking

import (
	"time"

	"google.golang.org/grpc"

	bookingv1 "toolshed/gen/go/toolshed/booking/v1"
)

// Module is the booking area as the composition root sees it: built once
// with its dependencies, then mounted onto a server.
type Module struct {
	srv *server
}

// ModuleConfig tunes the module.
type ModuleConfig struct {
	// WatchPoll is how often WatchReservation looks for new events.
	WatchPoll time.Duration
}

// NewModule builds the module over ledger.
func NewModule(ledger Ledger, cfg ModuleConfig) *Module {
	if cfg.WatchPoll <= 0 {
		cfg.WatchPoll = 150 * time.Millisecond
	}
	return &Module{srv: &server{ledger: ledger, poll: cfg.WatchPoll}}
}

// Mount registers the reservation service on gs.
func (m *Module) Mount(gs grpc.ServiceRegistrar) {
	bookingv1.RegisterReservationServiceServer(gs, m.srv)
}
