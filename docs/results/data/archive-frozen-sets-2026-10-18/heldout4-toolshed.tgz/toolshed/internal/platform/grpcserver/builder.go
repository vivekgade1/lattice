// Package grpcserver assembles the *grpc.Server from functional options.
package grpcserver

import (
	"google.golang.org/grpc"
)

type serviceEntry struct {
	desc *grpc.ServiceDesc
	impl any
}

type settings struct {
	unary    []grpc.UnaryServerInterceptor
	stream   []grpc.StreamServerInterceptor
	services []serviceEntry
	extra    []grpc.ServerOption
}

// Option configures New.
type Option func(*settings)

// WithInterceptors appends a unary/stream interceptor pair to the chain.
func WithInterceptors(u grpc.UnaryServerInterceptor, s grpc.StreamServerInterceptor) Option {
	return func(st *settings) {
		if u != nil {
			st.unary = append(st.unary, u)
		}
		if s != nil {
			st.stream = append(st.stream, s)
		}
	}
}

// WithService asks New to register impl under desc once the server exists.
func WithService(desc *grpc.ServiceDesc, impl any) Option {
	return func(st *settings) { st.services = append(st.services, serviceEntry{desc, impl}) }
}

// WithServerOption passes a raw grpc.ServerOption through.
func WithServerOption(o grpc.ServerOption) Option {
	return func(st *settings) { st.extra = append(st.extra, o) }
}

// New builds the server and registers the services given by WithService.
func New(opts ...Option) *grpc.Server {
	var st settings
	for _, o := range opts {
		o(&st)
	}
	sopts := append([]grpc.ServerOption{
		grpc.ChainUnaryInterceptor(st.unary...),
		grpc.ChainStreamInterceptor(st.stream...),
	}, st.extra...)
	gs := grpc.NewServer(sopts...)
	for _, e := range st.services {
		gs.RegisterService(e.desc, e.impl)
	}
	return gs
}
