package authn

import (
	"context"
	"strings"
	"sync"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/reflect/protoreflect"
	"google.golang.org/protobuf/reflect/protoregistry"

	optionsv1 "toolshed/gen/go/toolshed/options/v1"
	"toolshed/internal/platform/passwd"
	"toolshed/internal/storage"
)

// ownNamespace is the proto package prefix whose methods the gate governs.
// Infrastructure services (health, reflection) live outside it.
const ownNamespace = "toolshed."

// SessionSource resolves a stored token hash to its member.
type SessionSource interface {
	MemberForSession(ctx context.Context, tokenHash string) (storage.Member, error)
}

// Gate attaches a Principal to every call that presents a live session and
// refuses calls to member-audience methods that do not.
type Gate struct {
	sessions SessionSource
	cache    sync.Map // full method -> optionsv1.Audience
}

// NewGate builds a Gate over sessions.
func NewGate(sessions SessionSource) *Gate { return &Gate{sessions: sessions} }

// audience reads the method option for fullMethod ("/pkg.Service/Method").
func (g *Gate) audience(fullMethod string) optionsv1.Audience {
	if v, ok := g.cache.Load(fullMethod); ok {
		return v.(optionsv1.Audience)
	}
	name := strings.TrimPrefix(fullMethod, "/")
	aud := optionsv1.Audience_AUDIENCE_MEMBER
	if !strings.HasPrefix(name, ownNamespace) {
		aud = optionsv1.Audience_AUDIENCE_ANONYMOUS
	} else if d, err := protoregistry.GlobalFiles.FindDescriptorByName(
		protoreflect.FullName(strings.Replace(name, "/", ".", 1))); err == nil {
		if md, ok := d.(protoreflect.MethodDescriptor); ok && md.Options() != nil {
			if v, ok := proto.GetExtension(md.Options(), optionsv1.E_Audience).(optionsv1.Audience); ok &&
				v != optionsv1.Audience_AUDIENCE_UNSPECIFIED {
				aud = v
			}
		}
	}
	g.cache.Store(fullMethod, aud)
	return aud
}

// admit decides one call: it returns the context handlers will see.
func (g *Gate) admit(ctx context.Context, fullMethod string) (context.Context, error) {
	token := bearer(ctx)
	if token != "" {
		hash := passwd.HashToken(token)
		m, err := g.sessions.MemberForSession(ctx, hash)
		if err == nil {
			return WithPrincipal(ctx, Principal{
				MemberID: m.ID, Username: m.Username, DisplayName: m.DisplayName,
				Role: m.Role, TokenHash: hash,
			}), nil
		}
	}
	if g.audience(fullMethod) == optionsv1.Audience_AUDIENCE_ANONYMOUS {
		return ctx, nil
	}
	if token == "" {
		return nil, status.Error(codes.Unauthenticated, "missing bearer token")
	}
	return nil, status.Error(codes.Unauthenticated, "session is not valid")
}

func bearer(ctx context.Context) string {
	md, _ := metadata.FromIncomingContext(ctx)
	for _, v := range md.Get("authorization") {
		if len(v) > 7 && strings.EqualFold(v[:7], "bearer ") {
			return strings.TrimSpace(v[7:])
		}
	}
	return ""
}

// Unary is the unary half of the gate.
func (g *Gate) Unary() grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req any, info *grpc.UnaryServerInfo, next grpc.UnaryHandler) (any, error) {
		ctx, err := g.admit(ctx, info.FullMethod)
		if err != nil {
			return nil, err
		}
		return next(ctx, req)
	}
}

// Stream is the streaming half of the gate.
func (g *Gate) Stream() grpc.StreamServerInterceptor {
	return func(srv any, ss grpc.ServerStream, info *grpc.StreamServerInfo, next grpc.StreamHandler) error {
		ctx, err := g.admit(ss.Context(), info.FullMethod)
		if err != nil {
			return err
		}
		return next(srv, &admittedStream{ServerStream: ss, ctx: ctx})
	}
}

type admittedStream struct {
	grpc.ServerStream
	ctx context.Context
}

func (s *admittedStream) Context() context.Context { return s.ctx }
