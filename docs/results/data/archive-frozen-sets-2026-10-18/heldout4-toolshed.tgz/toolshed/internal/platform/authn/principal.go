// Package authn resolves the caller of every rpc. Which methods need a session
// is declared in the .proto files with the toolshed.options.v1.audience method
// option; the gate reads that option from the descriptor registry at call time.
package authn

import "context"

// Roles, lowest privilege first.
const (
	RoleMember = "member"
	RoleStaff  = "staff"
	RoleAdmin  = "admin"
)

// Principal is the authenticated caller.
type Principal struct {
	MemberID    int64
	Username    string
	DisplayName string
	Role        string
	TokenHash   string
}

// AtLeast reports whether p's role is role or above.
func (p Principal) AtLeast(role string) bool { return rank(p.Role) >= rank(role) }

func rank(role string) int {
	switch role {
	case RoleAdmin:
		return 3
	case RoleStaff:
		return 2
	case RoleMember:
		return 1
	}
	return 0
}

type principalKey struct{}

// WithPrincipal returns ctx carrying p.
func WithPrincipal(ctx context.Context, p Principal) context.Context {
	return context.WithValue(ctx, principalKey{}, p)
}

// FromContext returns the caller, if the gate attached one.
func FromContext(ctx context.Context) (Principal, bool) {
	p, ok := ctx.Value(principalKey{}).(Principal)
	return p, ok
}
