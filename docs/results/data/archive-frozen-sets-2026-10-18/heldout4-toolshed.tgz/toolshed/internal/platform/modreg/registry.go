// Package modreg is the process-wide registry that self-registering service
// packages add themselves to from init(). The composition root blank-imports
// such packages and calls InstallAll once the server exists.
package modreg

import (
	"sort"
	"sync"

	"google.golang.org/grpc"

	"toolshed/internal/storage"
)

// Deps is what an installer may draw on.
type Deps struct {
	Store *storage.Store
}

// Installer mounts one service onto r.
type Installer func(r grpc.ServiceRegistrar, d Deps)

var (
	mu         sync.Mutex
	installers = map[string]Installer{}
)

// Register records an installer under name. It panics on duplicates so a
// copy-pasted init() fails loudly at start-up.
func Register(name string, in Installer) {
	mu.Lock()
	defer mu.Unlock()
	if _, dup := installers[name]; dup {
		panic("modreg: duplicate installer " + name)
	}
	installers[name] = in
}

// InstallAll runs every registered installer in name order.
func InstallAll(r grpc.ServiceRegistrar, d Deps) {
	mu.Lock()
	defer mu.Unlock()
	names := make([]string, 0, len(installers))
	for n := range installers {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		installers[n](r, d)
	}
}
