// Package auth serves toolshed.auth.v1.SessionService.
package auth

import (
	"context"
	"errors"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	authv1 "toolshed/gen/go/toolshed/auth/v1"
	"toolshed/internal/platform/authn"
	"toolshed/internal/platform/passwd"
	"toolshed/internal/storage"
)

type sessionStore interface {
	MemberByUsername(ctx context.Context, username string) (storage.Member, error)
	CreateSession(ctx context.Context, tokenHash string, memberID int64) error
	DeleteSession(ctx context.Context, tokenHash string, memberID int64) error
}

type sessionServer struct {
	authv1.UnimplementedSessionServiceServer
	store sessionStore
}

func (s *sessionServer) Login(ctx context.Context, req *authv1.LoginRequest) (*authv1.LoginResponse, error) {
	if req.GetUsername() == "" || req.GetPassword() == "" {
		return nil, status.Error(codes.InvalidArgument, "username and password are required")
	}
	m, err := s.store.MemberByUsername(ctx, req.GetUsername())
	if errors.Is(err, storage.ErrNotFound) || (err == nil && !passwd.Verify(m.PasswordHash, req.GetPassword())) {
		return nil, status.Error(codes.Unauthenticated, "unknown username or wrong password")
	}
	if err != nil {
		return nil, status.Error(codes.Internal, "member lookup failed")
	}
	token, hash, err := passwd.NewToken()
	if err != nil {
		return nil, status.Error(codes.Internal, "could not mint token")
	}
	if err := s.store.CreateSession(ctx, hash, m.ID); err != nil {
		return nil, status.Error(codes.Internal, "could not store session")
	}
	return &authv1.LoginResponse{Token: token, Username: m.Username, Role: m.Role}, nil
}

func (s *sessionServer) Logout(ctx context.Context, req *authv1.LogoutRequest) (*authv1.LogoutResponse, error) {
	p, _ := authn.FromContext(ctx)
	hash := p.TokenHash
	if t := req.GetSessionToken(); t != "" {
		hash = passwd.HashToken(t)
	}
	err := s.store.DeleteSession(ctx, hash, p.MemberID)
	if errors.Is(err, storage.ErrNotFound) {
		return nil, status.Error(codes.NotFound, "no such session for this member")
	}
	if err != nil {
		return nil, status.Error(codes.Internal, "could not revoke session")
	}
	return &authv1.LogoutResponse{Revoked: true}, nil
}

func (s *sessionServer) WhoAmI(ctx context.Context, _ *authv1.WhoAmIRequest) (*authv1.WhoAmIResponse, error) {
	p, _ := authn.FromContext(ctx)
	return &authv1.WhoAmIResponse{
		MemberId: p.MemberID, Username: p.Username, DisplayName: p.DisplayName, Role: p.Role,
	}, nil
}
