package auth

import (
	"google.golang.org/grpc"

	authv1 "toolshed/gen/go/toolshed/auth/v1"
	"toolshed/internal/platform/modreg"
)

// The session service installs itself; importing this package is enough.
func init() {
	modreg.Register("auth.sessions", func(r grpc.ServiceRegistrar, d modreg.Deps) {
		r.RegisterService(&authv1.SessionService_ServiceDesc, &sessionServer{store: d.Store})
	})
}
