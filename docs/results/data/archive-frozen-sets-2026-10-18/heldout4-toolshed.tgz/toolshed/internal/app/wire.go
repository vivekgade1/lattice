// Package app is the composition root: it opens storage, builds every
// service area and mounts it on one gRPC server.
package app

import (
	"context"
	"fmt"
	"net"

	"google.golang.org/grpc"
	"google.golang.org/grpc/health"
	healthgrpc "google.golang.org/grpc/health/grpc_health_v1"

	membersv1 "toolshed/gen/go/toolshed/members/v1"
	_ "toolshed/internal/auth" // self-registers SessionService with modreg
	"toolshed/internal/booking"
	"toolshed/internal/catalog"
	"toolshed/internal/config"
	"toolshed/internal/members"
	"toolshed/internal/platform/authn"
	"toolshed/internal/platform/grpcserver"
	"toolshed/internal/platform/modreg"
	"toolshed/internal/storage"
)

// App is a built, not yet serving, process.
type App struct {
	cfg    config.Config
	store  *storage.Store
	server *grpc.Server
	health *health.Server
}

// Build wires the process from cfg.
func Build(ctx context.Context, cfg config.Config) (*App, error) {
	store, err := storage.Open(ctx, cfg.DBPath)
	if err != nil {
		return nil, err
	}
	if err := store.Migrate(ctx); err != nil {
		store.Close()
		return nil, err
	}

	gate := authn.NewGate(store)
	gs := grpcserver.New(
		grpcserver.WithInterceptors(gate.Unary(), gate.Stream()),
		grpcserver.WithService(&membersv1.MemberService_ServiceDesc, members.New(store)),
	)

	modreg.InstallAll(gs, modreg.Deps{Store: store})

	gs.RegisterService(catalog.ServiceDesc(), catalog.NewHandler(store))

	booking.NewModule(store, booking.ModuleConfig{WatchPoll: cfg.WatchPoll}).Mount(gs)

	hs := health.NewServer()
	healthgrpc.RegisterHealthServer(gs, hs)

	return &App{cfg: cfg, store: store, server: gs, health: hs}, nil
}

// Serve listens on the configured port until Stop is called.
func (a *App) Serve() error {
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", a.cfg.Port))
	if err != nil {
		return err
	}
	a.health.SetServingStatus("", healthgrpc.HealthCheckResponse_SERVING)
	return a.server.Serve(lis)
}

// Stop drains the server and closes storage.
func (a *App) Stop() {
	a.health.Shutdown()
	a.server.GracefulStop()
	a.store.Close()
}
