package storage

import (
	"context"
	"strings"
)

// Tool statuses.
const (
	ToolAvailable  = "AVAILABLE"
	ToolCheckedOut = "CHECKED_OUT"
	ToolRetired    = "RETIRED"
)

// Tool is a row of the tools table.
type Tool struct {
	ID       int64
	AssetTag string
	Name     string
	Category string
	Status   string
	Location string
}

const toolCols = `id, asset_tag, name, category, status, location`

func scanTool(row interface{ Scan(...any) error }) (Tool, error) {
	var t Tool
	err := row.Scan(&t.ID, &t.AssetTag, &t.Name, &t.Category, &t.Status, &t.Location)
	return t, notFound(err)
}

// ToolByAssetTag looks a tool up by its printed asset tag.
func (s *Store) ToolByAssetTag(ctx context.Context, tag string) (Tool, error) {
	return scanTool(s.db.QueryRowContext(ctx,
		`SELECT `+toolCols+` FROM tools WHERE asset_tag = ?`, tag))
}

// ListTools returns tools ordered by asset tag.
func (s *Store) ListTools(ctx context.Context, category string, includeRetired bool) ([]Tool, error) {
	var where []string
	var args []any
	if category != "" {
		where = append(where, "category = ?")
		args = append(args, category)
	}
	if !includeRetired {
		where = append(where, "status <> 'RETIRED'")
	}
	q := `SELECT ` + toolCols + ` FROM tools`
	if len(where) > 0 {
		q += ` WHERE ` + strings.Join(where, " AND ")
	}
	rows, err := s.db.QueryContext(ctx, q+` ORDER BY asset_tag`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Tool
	for rows.Next() {
		t, err := scanTool(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// InsertTool adds a tool; a duplicate asset tag yields ErrConflict.
func (s *Store) InsertTool(ctx context.Context, t Tool) (Tool, error) {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO tools (asset_tag, name, category, location) VALUES (?, ?, ?, ?)`,
		t.AssetTag, t.Name, t.Category, t.Location)
	if err != nil {
		if strings.Contains(err.Error(), "UNIQUE") {
			return Tool{}, ErrConflict
		}
		return Tool{}, err
	}
	return s.ToolByAssetTag(ctx, t.AssetTag)
}

// SetToolLocation moves a tool.
func (s *Store) SetToolLocation(ctx context.Context, tag, location string) (Tool, error) {
	if _, err := s.db.ExecContext(ctx,
		`UPDATE tools SET location = ? WHERE asset_tag = ?`, location, tag); err != nil {
		return Tool{}, err
	}
	return s.ToolByAssetTag(ctx, tag)
}

// SetToolStatus changes a tool's status.
func (s *Store) SetToolStatus(ctx context.Context, tag, status string) (Tool, error) {
	if _, err := s.db.ExecContext(ctx,
		`UPDATE tools SET status = ? WHERE asset_tag = ?`, status, tag); err != nil {
		return Tool{}, err
	}
	return s.ToolByAssetTag(ctx, tag)
}

// AppendAudit records a privileged call and its outcome.
func (s *Store) AppendAudit(ctx context.Context, actorID int64, method, outcome string) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO audit_log (actor_id, method, outcome) VALUES (?, ?, ?)`, actorID, method, outcome)
	return err
}
