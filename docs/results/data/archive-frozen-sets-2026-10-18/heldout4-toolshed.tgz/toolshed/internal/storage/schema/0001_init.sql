-- Toolshed schema, revision 1.
-- Applied by storage.Migrate at server start and by the fixture builder.
-- Every statement must be idempotent.

CREATE TABLE IF NOT EXISTS members (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE,
    display_name  TEXT    NOT NULL DEFAULT '',
    role          TEXT    NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'staff', 'admin')),
    password_hash TEXT    NOT NULL,
    created_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT    PRIMARY KEY,
    member_id  INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    created_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS tools (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_tag TEXT    NOT NULL UNIQUE,
    name      TEXT    NOT NULL,
    category  TEXT    NOT NULL DEFAULT 'general',
    status    TEXT    NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'CHECKED_OUT', 'RETIRED')),
    location  TEXT    NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS reservations (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_id    INTEGER NOT NULL REFERENCES tools(id),
    member_id  INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    booked_by  INTEGER REFERENCES members(id) ON DELETE SET NULL,
    starts_at  TEXT    NOT NULL,
    ends_at    TEXT    NOT NULL,
    status     TEXT    NOT NULL DEFAULT 'RESERVED' CHECK (status IN ('RESERVED', 'CHECKED_OUT', 'RETURNED', 'CANCELLED')),
    note       TEXT    NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS reservations_tool_window ON reservations (tool_id, starts_at, ends_at);

CREATE TABLE IF NOT EXISTS reservation_events (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
    kind           TEXT    NOT NULL,
    actor_id       INTEGER REFERENCES members(id) ON DELETE SET NULL,
    note           TEXT    NOT NULL DEFAULT '',
    at             TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id  INTEGER,
    method    TEXT    NOT NULL,
    outcome   TEXT    NOT NULL,
    at        TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
