package storage

import (
	"context"
	"database/sql"
	"strings"
)

// Member is a row of the members table.
type Member struct {
	ID           int64
	Username     string
	DisplayName  string
	Role         string
	PasswordHash string
}

const memberCols = `id, username, display_name, role, password_hash`

func scanMember(row interface{ Scan(...any) error }) (Member, error) {
	var m Member
	err := row.Scan(&m.ID, &m.Username, &m.DisplayName, &m.Role, &m.PasswordHash)
	return m, notFound(err)
}

// MemberByUsername looks a member up by login name.
func (s *Store) MemberByUsername(ctx context.Context, username string) (Member, error) {
	return scanMember(s.db.QueryRowContext(ctx,
		`SELECT `+memberCols+` FROM members WHERE username = ?`, username))
}

// MemberByID looks a member up by primary key.
func (s *Store) MemberByID(ctx context.Context, id int64) (Member, error) {
	return scanMember(s.db.QueryRowContext(ctx,
		`SELECT `+memberCols+` FROM members WHERE id = ?`, id))
}

// ListMembers returns members ordered by username, optionally by role.
func (s *Store) ListMembers(ctx context.Context, role string) ([]Member, error) {
	q := `SELECT ` + memberCols + ` FROM members`
	var args []any
	if role != "" {
		q += ` WHERE role = ?`
		args = append(args, role)
	}
	rows, err := s.db.QueryContext(ctx, q+` ORDER BY username`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Member
	for rows.Next() {
		m, err := scanMember(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, m)
	}
	return out, rows.Err()
}

// MemberPatch carries the optional fields of an update; empty means unchanged.
type MemberPatch struct {
	DisplayName string
	Role        string
}

// UpdateMember applies patch to the member with id and returns the new row.
func (s *Store) UpdateMember(ctx context.Context, id int64, patch MemberPatch) (Member, error) {
	var sets []string
	var args []any
	if patch.DisplayName != "" {
		sets = append(sets, "display_name = ?")
		args = append(args, patch.DisplayName)
	}
	if patch.Role != "" {
		sets = append(sets, "role = ?")
		args = append(args, patch.Role)
	}
	if len(sets) > 0 {
		args = append(args, id)
		res, err := s.db.ExecContext(ctx, `UPDATE members SET `+strings.Join(sets, ", ")+` WHERE id = ?`, args...)
		if err != nil {
			return Member{}, err
		}
		if n, _ := res.RowsAffected(); n == 0 {
			return Member{}, ErrNotFound
		}
	}
	return s.MemberByID(ctx, id)
}

// DeleteMember removes a member; sessions and reservations cascade.
func (s *Store) DeleteMember(ctx context.Context, id int64) error {
	return s.withTx(ctx, func(tx *sql.Tx) error {
		res, err := tx.ExecContext(ctx, `DELETE FROM members WHERE id = ?`, id)
		if err != nil {
			return err
		}
		if n, _ := res.RowsAffected(); n == 0 {
			return ErrNotFound
		}
		return nil
	})
}

// CreateSession stores the hash of a freshly issued token.
func (s *Store) CreateSession(ctx context.Context, tokenHash string, memberID int64) error {
	_, err := s.db.ExecContext(ctx,
		`INSERT INTO sessions (token_hash, member_id) VALUES (?, ?)`, tokenHash, memberID)
	return err
}

// MemberForSession resolves a token hash to the member that owns it.
func (s *Store) MemberForSession(ctx context.Context, tokenHash string) (Member, error) {
	return scanMember(s.db.QueryRowContext(ctx,
		`SELECT m.id, m.username, m.display_name, m.role, m.password_hash
		   FROM sessions s JOIN members m ON m.id = s.member_id
		  WHERE s.token_hash = ?`, tokenHash))
}

// DeleteSession removes the session with tokenHash if memberID owns it.
func (s *Store) DeleteSession(ctx context.Context, tokenHash string, memberID int64) error {
	res, err := s.db.ExecContext(ctx,
		`DELETE FROM sessions WHERE token_hash = ? AND member_id = ?`, tokenHash, memberID)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return ErrNotFound
	}
	return nil
}
