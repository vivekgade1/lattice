package storage

import (
	"context"
	"database/sql"
	"errors"
	"slices"
)

// Reservation statuses.
const (
	ResReserved   = "RESERVED"
	ResCheckedOut = "CHECKED_OUT"
	ResReturned   = "RETURNED"
	ResCancelled  = "CANCELLED"
)

// ErrOverlap is returned when a booking window collides with a live booking.
var ErrOverlap = errors.New("storage: reservation window overlaps")

// ErrBadState is returned when a transition is not allowed from the current status.
var ErrBadState = errors.New("storage: reservation not in a state that allows this")

// Reservation is a reservations row joined with the names clients see.
type Reservation struct {
	ID       int64
	ToolID   int64
	AssetTag string
	MemberID int64
	Holder   string
	BookedBy string
	StartsAt string
	EndsAt   string
	Status   string
	Note     string
}

// Event is a reservation_events row.
type Event struct {
	ID            int64
	ReservationID int64
	Kind          string
}

const reservationSelect = `
SELECT r.id, r.tool_id, t.asset_tag, r.member_id, m.username, COALESCE(b.username, ''),
       r.starts_at, r.ends_at, r.status, r.note
  FROM reservations r
  JOIN tools t   ON t.id = r.tool_id
  JOIN members m ON m.id = r.member_id
  LEFT JOIN members b ON b.id = r.booked_by`

func scanReservation(row interface{ Scan(...any) error }) (Reservation, error) {
	var r Reservation
	err := row.Scan(&r.ID, &r.ToolID, &r.AssetTag, &r.MemberID, &r.Holder, &r.BookedBy,
		&r.StartsAt, &r.EndsAt, &r.Status, &r.Note)
	return r, notFound(err)
}

// NewReservation is the input to InsertReservation.
type NewReservation struct {
	ToolID   int64
	MemberID int64
	BookedBy int64
	StartsAt string
	EndsAt   string
	Note     string
}

// InsertReservation books a window, refusing overlaps with live bookings.
// Times are RFC 3339 UTC strings, which order lexically.
func (s *Store) InsertReservation(ctx context.Context, n NewReservation) (Reservation, error) {
	var id int64
	err := s.withTx(ctx, func(tx *sql.Tx) error {
		var clash int
		if err := tx.QueryRowContext(ctx, `
			SELECT COUNT(*) FROM reservations
			 WHERE tool_id = ? AND status IN ('RESERVED', 'CHECKED_OUT')
			   AND starts_at < ? AND ends_at > ?`, n.ToolID, n.EndsAt, n.StartsAt).Scan(&clash); err != nil {
			return err
		}
		if clash > 0 {
			return ErrOverlap
		}
		res, err := tx.ExecContext(ctx, `
			INSERT INTO reservations (tool_id, member_id, booked_by, starts_at, ends_at, note)
			VALUES (?, ?, ?, ?, ?, ?)`, n.ToolID, n.MemberID, n.BookedBy, n.StartsAt, n.EndsAt, n.Note)
		if err != nil {
			return err
		}
		if id, err = res.LastInsertId(); err != nil {
			return err
		}
		_, err = tx.ExecContext(ctx, `
			INSERT INTO reservation_events (reservation_id, kind, actor_id) VALUES (?, 'created', ?)`, id, n.BookedBy)
		return err
	})
	if err != nil {
		return Reservation{}, err
	}
	return s.ReservationByID(ctx, id)
}

// ReservationByID loads one reservation.
func (s *Store) ReservationByID(ctx context.Context, id int64) (Reservation, error) {
	return scanReservation(s.db.QueryRowContext(ctx, reservationSelect+` WHERE r.id = ?`, id))
}

// ReservationsForMember lists a member's reservations, newest first.
func (s *Store) ReservationsForMember(ctx context.Context, memberID int64, status string) ([]Reservation, error) {
	q := reservationSelect + ` WHERE r.member_id = ?`
	args := []any{memberID}
	if status != "" {
		q += ` AND r.status = ?`
		args = append(args, status)
	}
	rows, err := s.db.QueryContext(ctx, q+` ORDER BY r.id DESC`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Reservation
	for rows.Next() {
		r, err := scanReservation(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, rows.Err()
}

// Transition describes a status change of a reservation.
type Transition struct {
	From       []string
	To         string
	Kind       string
	ActorID    int64
	Note       string
	ToolStatus string // when set, the tool moves to this status too
}

// TransitionReservation applies t atomically and records an event.
func (s *Store) TransitionReservation(ctx context.Context, id int64, t Transition) (Reservation, error) {
	err := s.withTx(ctx, func(tx *sql.Tx) error {
		var cur string
		var toolID int64
		if err := tx.QueryRowContext(ctx,
			`SELECT status, tool_id FROM reservations WHERE id = ?`, id).Scan(&cur, &toolID); err != nil {
			return notFound(err)
		}
		if !slices.Contains(t.From, cur) {
			return ErrBadState
		}
		if _, err := tx.ExecContext(ctx, `UPDATE reservations SET status = ? WHERE id = ?`, t.To, id); err != nil {
			return err
		}
		if t.ToolStatus != "" {
			if _, err := tx.ExecContext(ctx, `UPDATE tools SET status = ? WHERE id = ?`, t.ToolStatus, toolID); err != nil {
				return err
			}
		}
		_, err := tx.ExecContext(ctx, `
			INSERT INTO reservation_events (reservation_id, kind, actor_id, note) VALUES (?, ?, ?, ?)`,
			id, t.Kind, t.ActorID, t.Note)
		return err
	})
	if err != nil {
		return Reservation{}, err
	}
	return s.ReservationByID(ctx, id)
}

// EventsAfter returns the events of a reservation with id greater than after.
func (s *Store) EventsAfter(ctx context.Context, reservationID, after int64) ([]Event, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, reservation_id, kind FROM reservation_events
		 WHERE reservation_id = ? AND id > ? ORDER BY id`, reservationID, after)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Event
	for rows.Next() {
		var e Event
		if err := rows.Scan(&e.ID, &e.ReservationID, &e.Kind); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}
