// Package config reads process configuration from the environment.
package config

import (
	"fmt"
	"os"
	"strconv"
	"time"
)

// Config is the server's runtime configuration.
type Config struct {
	Port      int
	DBPath    string
	WatchPoll time.Duration
}

// FromEnv reads PORT, DB_PATH and the optional TOOLSHED_WATCH_POLL_MS.
func FromEnv() (Config, error) {
	c := Config{Port: 50051, DBPath: "toolshed.db", WatchPoll: 150 * time.Millisecond}
	if v := os.Getenv("PORT"); v != "" {
		p, err := strconv.Atoi(v)
		if err != nil || p <= 0 || p > 65535 {
			return c, fmt.Errorf("PORT %q is not a valid port", v)
		}
		c.Port = p
	}
	if v := os.Getenv("DB_PATH"); v != "" {
		c.DBPath = v
	}
	if v := os.Getenv("TOOLSHED_WATCH_POLL_MS"); v != "" {
		ms, err := strconv.Atoi(v)
		if err != nil || ms <= 0 {
			return c, fmt.Errorf("TOOLSHED_WATCH_POLL_MS %q is not a positive integer", v)
		}
		c.WatchPoll = time.Duration(ms) * time.Millisecond
	}
	return c, nil
}
