# Truth of the fixture `gotickets` (write the app from this text)

| element | truth |
|---|---|
| main | `r := gin.New(); r.Use(gin.LoggerWithWriter(io.Discard), gin.Recovery())`. GORM `AutoMigrate`. Env `PORT`, `DB_PATH`, `TICKETS_SECRET` (constant default) |
| routes (11) | `GET /health` Public; `POST /login` Public; `GET /queues` Public; `GET /me`; `POST /queues/:qid/tickets`; `GET /tickets`; `GET /tickets/:tid`; `POST /tickets/:tid/close`; `POST /tickets/:tid/reopen`; `POST /tickets/:tid/handoffs`; `GET /handoffs`. The last 8 are behind `RequireUser` (extractor role: `Customer`) |
| tables (4) | `users` (id uint pk, name size 64 unique, password_hash size 128 `json:"-"`); `queues` (id, name); `tickets` (id, queue_id uint index, reporter_id uint index, title size 80, status size 16 `default:open`); `handoffs` (id, ticket_id, from_user_id, to_user_id, all uint index). No GORM association tags |
| auth | login: body `{username, password}` (`binding:"required"`), `bcrypt.CompareHashAndPassword` or an equal plain value (the Seeder's convention, as S2). The answer is `{"access_token": "<id>.<hex hmac-sha256(id)>", "token_type": "bearer"}`, with no user struct and no stored token. `RequireUser`: bearer, split, verify the HMAC, `db.First(&u, id)`, else 401 `Not authenticated`; `c.Set("uid", u.ID)`. Handlers read `c.GetUint("uid")` |
| `GET /me` | 200, the caller's `models.User` struct |
| create ticket | `strconv.Atoi(c.Param("qid"))` err -> 400 `bad id`; missing queue -> 404 `Not found`; body `title binding:"required,max=80"` err -> 422 `invalid body`; `Where("queue_id = ? AND reporter_id = ? AND status = ?", qid, uid, "open").Count` > 0 -> 409 `already open`; `Create(&Ticket{QueueID, ReporterID: uid, Title, Status: "open"})` -> 201 |
| list tickets | query `page_size` `form:"page_size" binding:"omitempty,min=1,max=100"`; `status` `binding:"omitempty,oneof=open closed"`. A bind error -> 422 `invalid query`. Rows from `Where("reporter_id = ?", uid)` plus the status filter -> 200 |
| get / close / reopen | `strconv.Atoi(c.Param("tid"))` err -> 400 `bad id`; `Where("id = ? AND reporter_id = ?", tid, uid).First` err -> 404 `Not found`. Close: status != `open` -> 409 `not open`, else `Update("status", "closed")` -> 200. Reopen: status != `closed` -> 409 `not closed`, else `Update("status", "open")` -> 200 |
| handoff | 400 `bad id`; ticket scoped `Where("id = ? AND reporter_id = ?")` -> 404 `Not found`; body `to_user_id uint binding:"required,min=1"` err -> 422 `invalid body`; missing target user -> 404 `No such user`; `Create(&Handoff{TicketID, FromUserID: uid, ToUserID})` -> 201 |
| list handoffs | `Where("from_user_id = ? OR to_user_id = ?", uid, uid)` -> 200 |
| owners | `tickets.reporter_id`: 1 assign (create) and 6 compares (create's open check, list, get, close, reopen, handoff) = 7 evidence lines. `handoffs`: **unclear**, with candidates `from_user_id` (assign + compare) and `to_user_id` (compare). `queues` shared; `users` not owned |
| private | `User: [password_hash]` |
| machine | `tickets.status`: created `open`; `open -> closed`; `closed -> open` |
| bind status | every bind refusal is 422 |

