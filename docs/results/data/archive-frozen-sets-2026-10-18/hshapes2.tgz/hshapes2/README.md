# H2: the round-2 frozen rule-shape set (minishop)

Written by the H2 shapes agent on 2026-10-17 from `tests/spec/minishop.py`,
`tests/spec/fixtures/impact/base/` and the D1' / D4' / D6 text. No model was called and no API key was
used. Nothing here was produced by `lattice/spec/forms*.py`; that library is not on this author's branch.

## Files

| file | content |
|---|---|
| `minishop/REQUIREMENTS.md` | 25 rules: R1-R5 base, R6-R13 bounds, R14-R17 line limits, R18-R21 ownership, R22-R25 order states |
| `minishop/handwritten.py` | `SPEC` (minishop profile, program, machine, users, contracts; base invariants and scenarios plus this author's own) and `TRACE`; `LINKS` maps every rule to its hand-written elements. Import it from the repository root |
| `minishop/handwritten.trace.json` | `TRACE` as JSON (`lattice.spec.rules.Trace`) |
| `minishop/forms.json` | `lattice.forms/1`, 21 approved forms F1-F21 (R4, R6-R25); `approved_sha` = sha256 of `json.dumps({kind, form}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)`; `anchor` = `lattice.spec.rationale.anchor_of(rule text)` |
| `minishop/mutants.json` | `{name: {kind, aims, why, edit: [file, old, new]}}`; `edit` is `minishop.sources(edit=tuple(edit))` / `write_app(root, name, tuple(edit))`; each `old` occurs exactly once |
| `minishop/truth.json` | `{rules, formed, apps, cells: {app: {rule: {violates, reason}}}}`; apps = `ok`, the 4 `BROKEN`, the 6 `SEC_BROKEN` (prefixed `sec_`, built with `write_sec_app`), the 21 mutants: 32 apps x 25 rules |
| `minishop/h_verdicts.json` | the hand-written checks run (`check(SPEC, ..., layers="CD")`) on every app: per (app, rule) `h` pass/fail and the failed elements; a C finding counts against the rule linked to its invariant, a D finding against the rule linked to its scenario; `h_incomplete` where H differs from truth |
| `pairs.json` | 29 pairs `{id, class, expect, forms: [form, form or "scenario:<name>"], witness, why}`; each form is `{id, rule, kind, form}` |
| `invalid.json` | 29 forms `{id, rule, kind, form, expect, why}` that `check` must refuse, 18 distinct codes |
| `not_expressible.json` | 21 rules `{id, rule, category, why, attempt, expect_any_of}`; 12 carry an attempted form (`{kind, form}`) that must be refused with F001 or F017 |
| `MANIFEST.sha256` | `sha256sum` of every other file, sorted by path |

## Notes from this author

- Rules minishop's `ok` app violates by design (truth `violates: true` on `ok`): R14-R17 (it has no line
  limits), R21 (it answers 404, not 403), R25 (it refuses lines on paid orders). The hand-written checks fail on
  `ok` exactly there and nowhere else. R21 contradicts R18 and R25 contradicts R23 on purpose (two stakeholders);
  `forms contradictions` on `forms.json` alone should report those two pairs (classes c and d).
- Column-only bounds (K6): F1 (R4), F7 (R11), F9 (R13).
- `h_incomplete`: R5 on `sec_state` and `m_cancel_paid` (the machine is not checked by layers CD; R5 is not
  formed).
- Before freezing, this author ran its own literal reading of D3 (plain scenarios built from each form, not the
  library) on all 32 apps: it agreed with truth on every formed cell except two. (1) `sec_bounds` x R11: a
  column-only bound (K6); no reached state has a negative total. (2) `m_lim4` x R17: if all the counted lines of
  the per-product limit are put on one order (the form's only given order), the mutant's per-order limit of 4
  refuses the `at_limit` request and hides the missing per-product limit. Truth stays as judged from the rule and
  the edit (violated).
- The class-e hand-written anchors are `scenario:ben cannot read order 1`,
  `scenario:ann adds one pen to order 1` and `scenario:another buyer's order is forbidden` (step 1); all of them
  have no `given` and the matched step has no earlier step.
