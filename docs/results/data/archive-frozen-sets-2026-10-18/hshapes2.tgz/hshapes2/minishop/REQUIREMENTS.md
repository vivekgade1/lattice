# Mini shop

## Orders

- A buyer can cancel their own pending order, and cancelling it again is refused with 409.
- A buyer can add a line to a pending order and the stored line has the requested quantity.
- An order's total is the sum of its lines.
- Stock is never negative.
- An order moves from pending to paid or cancelled, and from paid to shipped.

## Value bounds

- A new line's quantity must be at least 1: a quantity of 0 or below is refused with 422 and no line is stored.
- A new line's quantity is at most 100: a quantity of 101 or more is refused with 422 and no line is stored.
- A new line's product id must be at least 1: a product id of 0 or below is refused with 422 and no line is stored.
- Reading an order whose id is below 1 answers 404.
- Cancelling an order whose id is below 1 answers 404 and changes nothing.
- An order's total is never negative.
- A stored order line never has a quantity above 100: adding a line of quantity 101 is refused with 422 and stores nothing.
- Every user's role is either Buyer or Admin.

## Line limits

- An order holds at most 5 lines: adding a 6th line is refused with 409 and stores nothing.
- The same product can appear on at most 2 lines of one order: adding a 3rd line of that product to the order is refused with 409 and stores nothing.
- Ink (product 2) is rationed: an order holds at most 1 ink line, and adding a 2nd ink line is refused with 409 and stores nothing.
- A product can be on at most 4 order lines across all orders: adding a 5th line of that product is refused with 409 and stores nothing.

## Ownership

- Only the owner can read an order: another buyer gets 404 and an anonymous caller gets 401.
- Only the owner can cancel an order: another buyer gets 404 and the order is unchanged; an anonymous caller gets 401 and the order is unchanged.
- An admin has no special access to a buyer's order: an admin who reads or cancels another user's order gets 404 and the order is unchanged, and an anonymous caller gets 401.
- A buyer who reads someone else's order gets 403 Forbidden, and an anonymous reader gets 401.

## Order states

- Only a pending order can be cancelled: cancelling it makes it cancelled (200); cancelling a paid, shipped or cancelled order is refused with 409 and leaves it unchanged.
- Lines can be added only to a pending order (201): adding a line to a paid, shipped or cancelled order is refused with 409 and stores nothing.
- An order can be read by its owner in every state (200).
- A paid order can still be topped up: adding a line to a pending or paid order is accepted with 201, and adding one to a shipped or cancelled order is refused with 409 and stores nothing.
