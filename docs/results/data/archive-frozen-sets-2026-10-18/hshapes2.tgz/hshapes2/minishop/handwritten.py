"""H2 hand-written spec for the minishop rules of REQUIREMENTS.md (this directory).

The minishop profile, programs, machine, users and contracts (tests/spec/minishop.py), the
base invariants and scenarios (R1-R5), plus this author's own hand-written scenarios and
invariants for R6-R25, as a spec author would write them without forms. ``SPEC`` is the
spec, ``TRACE`` its trace (lattice.spec.rules.Trace JSON form, rules extracted from
REQUIREMENTS.md). Run from the repository root (imports ``tests.spec.minishop``).

Seed (minishop.SEED): users ann 1, ben 2, ada 3 (Admin), eve 4 (inactive); products 1 pen
(2.5, stock 10), 2 ink (4.0, stock 5); orders 1 ann pending 5.0, 2 ann paid 4.0, 3 ben
pending 0.0, 4 ada pending 2.5; lines 1 (order 1, pen x2), 2 (order 2, ink x1), 3 (order
4, pen x1). Every given row below uses keys above the seed's.
"""

from __future__ import annotations

from pathlib import Path

from lattice.spec import Invariant, Machine, Scenario, Spec, Step, Unchecked
from lattice.spec.rules import Trace, extract_rules
from tests.spec import minishop

ITEMS = "/orders/{}/items"


def _order(oid: int, uid: int, status: str = "pending") -> dict:
    return {"id": oid, "user_id": uid, "status": status, "total": 0.0}


def _product(pid: int, name: str, price: float, stock: int) -> dict:
    return {"id": pid, "name": name, "price": price, "stock": stock}


def _add(oid: int, user: str | None, pid: int, qty: int, status: int, **kw) -> Step:
    return Step(
        "POST", ITEMS.format(oid), user=user, json={"product_id": pid, "quantity": qty},
        expect_status=status, **kw,
    )


def _no_line(oid: int, n: int = 0) -> dict:
    return {"order_items": {"where": {"order_id": oid}, "count": n}}


def _status(oid: int, status: str) -> dict:
    return {"orders": {"where": {"id": oid}, "equals": {"status": status}}}


INVARIANTS = (
    *minishop.INVARIANTS,  # order_total (R3), stock_non_negative (R4)
    Invariant("order_total_non_negative", "An order's total is never negative", "Order.total >= 0"),
    Invariant(
        "line_quantity_at_most_100",
        "A stored order line never has a quantity above 100",
        "OrderItem.quantity <= 100",
    ),
    Invariant(
        "user_role_known", "Every user's role is Buyer or Admin", "User.role in ('Buyer', 'Admin')"
    ),
)

S = Scenario
SCENARIOS = (
    *minishop.SCENARIOS,  # "ann cancels her pending order" (R1), "ann adds a line to a new order" (R2)
    # R2 (also the class-e anchor of pairs.json): one exact step, no given
    S("ann adds one pen to order 1", steps=(_add(1, "ann", 1, 1, 201),)),
    # R3: a stock refusal and a client-sent price leave the total equal to the lines
    S(
        "a stock refusal stores no line",
        steps=(_add(3, "ben", 2, 50, 409, expect_db=_no_line(3)),),
    ),
    S(
        "a client-sent line price is not used",
        steps=(
            Step(
                "POST", ITEMS.format(3), user="ben",
                json={"product_id": 1, "quantity": 1, "price": 0.01}, expect_status=201,
            ),
        ),
    ),
    # R6
    S(
        "a quantity below 1 is refused",
        steps=(
            _add(3, "ben", 1, -1, 422, expect_db=_no_line(3)),
            _add(3, "ben", 1, 0, 422, expect_db=_no_line(3)),
            _add(3, "ben", 1, 1, 201),
        ),
    ),
    # R7
    S(
        "a quantity above 100 is refused",
        given={"orders": [_order(40, 1)], "products": [_product(9, "crate", 1.0, 1000)]},
        steps=(
            _add(40, "ann", 9, 101, 422, expect_db=_no_line(40)),
            _add(40, "ann", 9, 100, 201),
        ),
    ),
    # R8
    S(
        "a product id below 1 is refused",
        steps=(
            _add(3, "ben", 0, 1, 422, expect_db=_no_line(3)),
            _add(3, "ben", -1, 1, 422, expect_db=_no_line(3)),
            _add(3, "ben", 1, 2, 201),
        ),
    ),
    # R9
    S(
        "reading order 0 is not found",
        steps=(
            Step("GET", "/orders/0", user="ann", expect_status=404),
            Step("GET", "/orders/1", user="ann", expect_status=200),
        ),
    ),
    # R10
    S(
        "cancelling order 0 is not found",
        steps=(
            Step("POST", "/orders/0/cancel", user="ann", expect_status=404,
                 expect_db=_status(1, "pending")),
        ),
    ),
    # R12 (with the invariant line_quantity_at_most_100)
    S(
        "a stored line never exceeds 100",
        given={"orders": [_order(41, 1)], "products": [_product(8, "bulk", 0.5, 500)]},
        steps=(
            _add(41, "ann", 8, 101, 422, expect_db=_no_line(41)),
            _add(41, "ann", 8, 100, 201),
        ),
    ),
    # R14
    S(
        "an order takes at most 5 lines",
        given={
            "orders": [_order(42, 1)],
            "products": [_product(p, f"part{p}", 1.0, 50) for p in range(11, 17)],
        },
        steps=(
            *(_add(42, "ann", p, 1, 201) for p in range(11, 16)),
            _add(42, "ann", 16, 1, 409, expect_db=_no_line(42, 5)),
        ),
    ),
    # R15
    S(
        "a product is on at most 2 lines of an order",
        given={"orders": [_order(44, 1)]},
        steps=(
            _add(44, "ann", 1, 1, 201),
            _add(44, "ann", 1, 1, 201),
            _add(44, "ann", 1, 1, 409, expect_db=_no_line(44, 2)),
        ),
    ),
    # R16
    S(
        "an order holds one ink line",
        given={"orders": [_order(45, 1)]},
        steps=(
            _add(45, "ann", 2, 1, 201),
            _add(45, "ann", 2, 1, 409, expect_db=_no_line(45, 1)),
        ),
    ),
    # R17
    S(
        "a product is on at most 4 lines in all",
        given={
            "orders": [_order(46, 1), _order(47, 1), _order(48, 1)],
            "products": [_product(7, "print", 3.0, 50)],
        },
        steps=(
            _add(46, "ann", 7, 1, 201),
            _add(46, "ann", 7, 1, 201),
            _add(47, "ann", 7, 1, 201),
            _add(47, "ann", 7, 1, 201),
            _add(48, "ann", 7, 1, 409,
                 expect_db={"order_items": {"where": {"product_id": 7}, "count": 4}}),
        ),
    ),
    # R18 (and the class-e anchor "ben cannot read order 1")
    S("ben cannot read order 1", steps=(Step("GET", "/orders/1", user="ben", expect_status=404),)),
    S(
        "only the owner reads an order",
        steps=(
            Step("GET", "/orders/2", user="ann", expect_status=200),
            Step("GET", "/orders/2", user="ben", expect_status=404),
            Step("GET", "/orders/2", user=None, expect_status=401),
        ),
    ),
    # R19
    S(
        "only the owner cancels an order",
        steps=(
            Step("POST", "/orders/3/cancel", user="ann", expect_status=404,
                 expect_db=_status(3, "pending")),
            Step("POST", "/orders/3/cancel", user=None, expect_status=401,
                 expect_db=_status(3, "pending")),
            Step("POST", "/orders/3/cancel", user="ben", expect_status=200),
        ),
    ),
    # R20
    S(
        "an admin has no special access to an order",
        given={"orders": [_order(50, 2)]},
        steps=(
            Step("GET", "/orders/50", user="ada", expect_status=404),
            Step("POST", "/orders/50/cancel", user="ada", expect_status=404,
                 expect_db=_status(50, "pending")),
            Step("GET", "/orders/50", user=None, expect_status=401),
            Step("POST", "/orders/50/cancel", user=None, expect_status=401,
                 expect_db=_status(50, "pending")),
            Step("GET", "/orders/50", user="ben", expect_status=200),
        ),
    ),
    # R21 (fails on ok: minishop answers 404)
    S(
        "another buyer's order is forbidden",
        steps=(
            Step("GET", "/orders/3", user="ann", expect_status=403),
            Step("GET", "/orders/3", user=None, expect_status=401),
        ),
    ),
    # R22
    S(
        "only a pending order is cancelled",
        given={
            "orders": [_order(60, 1), _order(61, 1, "paid"), _order(62, 1, "shipped"),
                       _order(63, 1, "cancelled")],
        },
        steps=(
            Step("POST", "/orders/61/cancel", user="ann", expect_status=409,
                 expect_db=_status(61, "paid")),
            Step("POST", "/orders/62/cancel", user="ann", expect_status=409,
                 expect_db=_status(62, "shipped")),
            Step("POST", "/orders/63/cancel", user="ann", expect_status=409,
                 expect_db=_status(63, "cancelled")),
            Step("POST", "/orders/60/cancel", user="ann", expect_status=200,
                 expect_db=_status(60, "cancelled")),
        ),
    ),
    # R23
    S(
        "lines go only on a pending order",
        given={
            "orders": [_order(64, 1, "paid"), _order(65, 1, "shipped"),
                       _order(66, 1, "cancelled"), _order(67, 1)],
        },
        steps=(
            _add(64, "ann", 1, 1, 409, expect_db=_no_line(64)),
            _add(65, "ann", 1, 1, 409, expect_db=_no_line(65)),
            _add(66, "ann", 1, 1, 409, expect_db=_no_line(66)),
            _add(67, "ann", 1, 1, 201),
        ),
    ),
    # R24
    S(
        "an order is readable in every state",
        given={
            "orders": [_order(68, 3), _order(69, 3, "paid"), _order(70, 3, "shipped"),
                       _order(71, 3, "cancelled")],
        },
        steps=tuple(Step("GET", f"/orders/{o}", user="ada", expect_status=200)
                    for o in (68, 69, 70, 71)),
    ),
    # R25 (fails on ok: minishop refuses a paid order's line with 409)
    S(
        "a paid order can be topped up",
        given={
            "orders": [_order(72, 1, "paid"), _order(73, 1, "shipped"),
                       _order(74, 1, "cancelled"), _order(75, 1)],
        },
        steps=(
            _add(72, "ann", 1, 1, 201),
            _add(73, "ann", 1, 1, 409, expect_db=_no_line(73)),
            _add(74, "ann", 1, 1, 409, expect_db=_no_line(74)),
            _add(75, "ann", 1, 1, 201),
        ),
    ),
)


def spec() -> Spec:
    return Spec(
        profile=minishop.profile(),
        programs={"orders": minishop.ORDERS_PROGRAM},
        machines=(
            Machine(
                "Order",
                "status",
                {"pending": ("paid", "cancelled"), "paid": "shipped"},
                initial="pending",
            ),
        ),
        invariants=INVARIANTS,
        scenarios=SCENARIOS,
        unchecked=(Unchecked("a shipped order cannot be changed", concerns="Order"),),
        users={h: (h, pw) for h, (_, pw, _, _) in minishop.USERS.items()},
        contracts=minishop.CONTRACTS,
    )


SPEC = spec()

LINKS: dict[str, list[str]] = {
    "R1": ["scenario:ann cancels her pending order"],
    "R2": ["scenario:ann adds a line to a new order", "scenario:ann adds one pen to order 1"],
    "R3": [
        "invariant:order_total",
        "scenario:a stock refusal stores no line",
        "scenario:a client-sent line price is not used",
    ],
    "R4": ["invariant:stock_non_negative"],
    "R5": ["machine:Order.status"],
    "R6": ["scenario:a quantity below 1 is refused"],
    "R7": ["scenario:a quantity above 100 is refused"],
    "R8": ["scenario:a product id below 1 is refused"],
    "R9": ["scenario:reading order 0 is not found"],
    "R10": ["scenario:cancelling order 0 is not found"],
    "R11": ["invariant:order_total_non_negative"],
    "R12": ["invariant:line_quantity_at_most_100", "scenario:a stored line never exceeds 100"],
    "R13": ["invariant:user_role_known"],
    "R14": ["scenario:an order takes at most 5 lines"],
    "R15": ["scenario:a product is on at most 2 lines of an order"],
    "R16": ["scenario:an order holds one ink line"],
    "R17": ["scenario:a product is on at most 4 lines in all"],
    "R18": ["scenario:ben cannot read order 1", "scenario:only the owner reads an order"],
    "R19": ["scenario:only the owner cancels an order"],
    "R20": ["scenario:an admin has no special access to an order"],
    "R21": ["scenario:another buyer's order is forbidden"],
    "R22": ["scenario:only a pending order is cancelled"],
    "R23": ["scenario:lines go only on a pending order"],
    "R24": ["scenario:an order is readable in every state"],
    "R25": ["scenario:a paid order can be topped up"],
}


def trace() -> Trace:
    text = (Path(__file__).with_name("REQUIREMENTS.md")).read_text()
    return Trace(source="REQUIREMENTS.md", rules=extract_rules(text), links=dict(LINKS))


TRACE = trace()
