"""Harness of the harborline marina service (grpc-go over pure-Go SQLite).

Contract:

* ``make_app(db_path)`` answers a ``lattice.spec.process.ProcessApp`` (not started) that runs
  ``harbord`` with ``PORT`` (gRPC, 127.0.0.1) and ``DB_PATH`` set, ``ready="grpc"`` (the
  standard ``grpc.health.v1.Health/Check`` answers SERVING), and ``protos`` / ``proto_paths`` /
  ``proto_root`` filled.
* ``build_db(path)`` writes the schema and the seed rows (stdlib ``sqlite3`` only).
* ``RUNTIME``: a process runtime logging callers in by the rpc ``harbor.v1.Accounts/Login``
  (request ``username``/``password``, response ``token``); the token is sent as metadata
  ``authorization: Bearer <token>``.
* ``USERS``: handle -> (username, password). The first user is ``ann`` (a skipper).
* ``PROTOS``: ``.proto`` files relative to this directory; ``PROTO_PATHS``: import roots relative
  to this directory (imports are written ``harbor/v1/types.proto``).

The binary: ``$HARBORD_BIN`` if set, else built once with ``go build -trimpath -buildvcs=false
-mod=readonly`` into ``$HARBORLINE_BUILD_DIR`` (default: a directory under the system temp dir),
never under this directory.
"""

from __future__ import annotations

import hashlib
import os
import sqlite3
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

USERS = {
    "ann": ("ann", "pw-ann"),
    "hal": ("hal", "pw-hal"),
    "yuki": ("yuki", "pw-yuki"),
    "ben": ("ben", "pw-ben"),
}
ROLES = {"ann": "skipper", "hal": "harbormaster", "yuki": "yard", "ben": "skipper"}

PROTO_PATHS = ("proto",)
PROTOS = (
    "proto/harbor/v1/accounts.proto",
    "proto/harbor/v1/berths.proto",
    "proto/harbor/v1/bookings.proto",
    "proto/harbor/v1/fuel.proto",
    "proto/harbor/v1/tides.proto",
    "proto/harbor/v1/types.proto",
    "proto/harbor/v1/vessels.proto",
    "proto/harbor/v1/yard.proto",
)

RPC_LOGIN = {
    "service": "harbor.v1.Accounts",
    "method": "Login",
    "username_field": "username",
    "password_field": "password",
    "token_field": "token",
    "metadata": "authorization",
    "scheme": "Bearer",
}

DDL = """
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('skipper', 'harbormaster', 'yard'))
);
CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  revoked INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE berths (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  pier TEXT NOT NULL,
  length_m INTEGER NOT NULL,
  nightly_cents INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE vessels (
  id INTEGER PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hull TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  length_m INTEGER NOT NULL
);
CREATE TABLE bookings (
  id INTEGER PRIMARY KEY,
  berth_id INTEGER NOT NULL REFERENCES berths(id),
  vessel_id INTEGER NOT NULL REFERENCES vessels(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  nights INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('reserved', 'checked_in', 'cancelled')),
  total_cents INTEGER NOT NULL
);
CREATE TABLE work_orders (
  id INTEGER PRIMARY KEY,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  done INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE tide_readings (
  id INTEGER PRIMARY KEY,
  station TEXT NOT NULL,
  at TEXT NOT NULL,
  height_cm INTEGER NOT NULL
);
"""

SEED = [
    ("INSERT INTO users VALUES (?, ?, ?, ?, ?)", [
        (1, "ann", "pw-ann", "Ann Marsh", "skipper"),
        (2, "hal", "pw-hal", "Hal Quay", "harbormaster"),
        (3, "yuki", "pw-yuki", "Yuki Slip", "yard"),
        (4, "ben", "pw-ben", "Ben Keel", "skipper"),
    ]),
    ("INSERT INTO berths VALUES (?, ?, ?, ?, ?, ?)", [
        (1, "A-01", "A", 12, 4500, 1),
        (2, "A-02", "A", 15, 5200, 1),
        (3, "B-07", "B", 20, 8000, 1),
        (4, "C-03", "C", 9, 3000, 0),
    ]),
    ("INSERT INTO vessels VALUES (?, ?, ?, ?, ?)", [
        (1, 1, "HN-0001", "Petrel", 11),
        (2, 4, "HN-0002", "Kestrel", 14),
    ]),
    ("INSERT INTO bookings VALUES (?, ?, ?, ?, ?, ?, ?)", [
        (1, 3, 2, 4, 2, "reserved", 16000),
    ]),
    ("INSERT INTO tide_readings (station, at, height_cm) VALUES (?, ?, ?)", [
        ("harbor-mouth", "2026-10-18T03:10", 41),
        ("harbor-mouth", "2026-10-18T09:24", 312),
        ("harbor-mouth", "2026-10-18T15:37", 38),
    ]),
]


def build_db(path: Path) -> Path:
    """The schema plus seed rows at ``path``."""
    conn = sqlite3.connect(path)
    try:
        conn.executescript(DDL)
        for sql, rows in SEED:
            conn.executemany(sql, rows)
        conn.commit()
    finally:
        conn.close()
    return Path(path)


def _source_hash() -> str:
    h = hashlib.sha256()
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and (p.suffix in {".go", ".mod", ".sum"}):
            h.update(str(p.relative_to(ROOT)).encode())
            h.update(p.read_bytes())
    return h.hexdigest()[:16]


def binary() -> str:
    """The harbord binary (built once per source hash, outside this directory)."""
    env_bin = os.environ.get("HARBORD_BIN")
    if env_bin:
        return env_bin
    base = Path(os.environ.get("HARBORLINE_BUILD_DIR") or Path(tempfile.gettempdir()) / "harborline-build")
    out = base / _source_hash() / "harbord"
    if not out.exists():
        out.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["go", "build", "-trimpath", "-buildvcs=false", "-mod=readonly", "-o", str(out), "./cmd/harbord"],
            cwd=ROOT,
            check=True,
        )
    return str(out)


def make_app(db_path: Path):
    """harbord on ``db_path`` (not started)."""
    from lattice.spec.process import ProcessApp

    kwargs = {
        "db_path": db_path,
        "env": {},
        "port_env": "PORT",
        "db_env": "DB_PATH",
        "ready": "grpc",
        "protos": tuple(str(ROOT / p) for p in PROTOS),
        "proto_paths": tuple(str(ROOT / p) for p in PROTO_PATHS),
        "proto_root": str(ROOT),
    }
    fields = getattr(ProcessApp, "__dataclass_fields__", {})
    kwargs = {k: v for k, v in kwargs.items() if k in fields}
    return ProcessApp([binary()], **kwargs)


def _runtime():
    try:
        from lattice.importer.transport import AuthDriver
        from lattice.spec.process import process_runtime
    except ImportError:  # lattice not importable: build_db and USERS still work
        return None
    rpc = getattr(AuthDriver, "rpc", None)
    if rpc is None:
        return None
    auth = rpc(RPC_LOGIN["service"], RPC_LOGIN["method"], USERS, RPC_LOGIN["token_field"])
    return process_runtime(framework="go", auth=auth)


RUNTIME = _runtime()
