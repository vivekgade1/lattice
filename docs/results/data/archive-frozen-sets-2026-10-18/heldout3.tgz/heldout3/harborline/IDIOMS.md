# harborline: idioms (sealed until scoring)

Written after the code and truth were complete.

## How each service reaches the server

- harbor.v1.Accounts: direct `harborv1.RegisterAccountsServer(s, accounts.NewService(...))` inside `app.Build`, right after `grpc.NewServer`.
- harbor.v1.Berths: self-registration at package init. `internal/berths` calls `registry.Offer("berths", registry.InstallFunc(install))` from `init()`; the app only blank-imports the package, and `registry.InstallAll` later calls every offered `Installer` (an interface; `InstallFunc` is a func-type adapter) from a package-level map, sorted by name. `install` registers on a `grpc.ServiceRegistrar` parameter.
- harbor.v1.Bookings: the constructor `bookings.NewModule` returns an interface (`Module`); the app calls its `Mount(grpc.ServiceRegistrar)` method, whose concrete pointer-receiver body calls `r.RegisterService(&harborv1.Bookings_ServiceDesc, d)` with the generated descriptor.
- harbor.v1.Vessels: a generic helper `expose[T any](r grpc.ServiceRegistrar, desc *grpc.ServiceDesc, impl T)` calls `RegisterService`; the descriptor comes from a package variable `vessels.Descriptor` (`&harborv1.Vessels_ServiceDesc`), and the impl from `vessels.New(db, opts...)`, a functional-options constructor whose result type is the `harborv1.VesselsServer` interface (concrete value type `register` with value-receiver methods).
- harbor.v1.Yard: functional options. `yard.Installer(db)` returns a closure that calls `harborv1.RegisterYardServer`; it is wrapped by `app.WithService(...)` into an `Option`, the options are applied from a slice literal into a `config` struct field (`services []func(grpc.ServiceRegistrar)`), and `Build` ranges that field and calls each function.
- harbor.v1.Tides: a value-receiver method `extras.attach(*grpc.Server)` on a composite literal (`extras{station: ...}.attach(s)`) registers an adapter struct `tideDesk` that only embeds `*tides.Station`; the rpc methods are value-receiver methods of `tides.Station`, promoted through the embedded pointer, and `Station` itself embeds `UnimplementedTidesServer`.
- harbor.v1.Fuel (declared, not registered): `internal/fuel.Dock` implements part of it, but no code registers it.
- grpc.health.v1.Health: standard `healthpb.RegisterHealthServer` (not in PROTOS).

## Authentication

- One auth interceptor: method value `keeper.Unary` of `*gate.Keeper`, second in a `grpc.ChainUnaryInterceptor` that is assembled through the options above (`WithUnary(guard.Recover(logger), keeper.Unary, fault.Translate)`). The anonymous allowlist is a `*gate.Policy` built by a fluent builder: `gate.Anonymous(harborv1.Accounts_Login_FullMethodName)` (a generated method-name constant into a map set) `.AndService(harborv1.Tides_ServiceDesc.ServiceName)` and `.AndService(healthpb.Health_ServiceDesc.ServiceName)` (whole-service prefixes matched with `strings.HasPrefix`). Refusal is in a private `admit` method: package-level sentinel status errors (`errNoCredentials`, `errBadScheme`) for missing metadata / non-Bearer values, and a `switch` on `errors.Is(err, session.ErrUnknown)` from a `Resolver` interface (session table join) giving `status.Error(codes.Unauthenticated, ...)`; a store failure gives UNAVAILABLE. The same keeper's `Stream` method guards streams.
- Role checks are in handlers, not interceptors: `actor.Need(ctx, roles...)` returning PERMISSION_DENIED (CreateBerth, CompleteWorkOrder), and in Bookings a domain sentinel `fault.ErrForbidden` translated to PERMISSION_DENIED by the `fault.Translate` interceptor (ListBookings include_all, CheckIn).
- Other interceptors: `guard.Recover` (deferred recover to INTERNAL via a named result) and `fault.Translate` (maps domain errors to codes; passes status errors through; never UNAUTHENTICATED).

## Error idioms (per area)

- Accounts, Tides: literal `status.Error(codes.X, ...)`.
- Berths: a custom error type `*problem` implementing `GRPCStatus()`, built by small constructors (`badInput`, `noSuchBerth`, `duplicate`, `storeFailed`).
- Vessels: a local `fail(code, fmt, ...)` wrapper over `status.Errorf`.
- Bookings: `fmt.Errorf("...: %w", fault.ErrX)` domain sentinels, codes decided by a table in `fault.Wire` inside a unary interceptor; unknown errors become INTERNAL there.
- Yard: an enum `reason` with a `codeFor` map and a `because(detail)` method.

## Layout

`cmd/harbord` (env + listen), `internal/app` (assembly: options, extras), `internal/platform/{store,actor,session,gate,fault,guard,registry}`, one package per feature area, generated code in `gen/harbor/v1`, protos in `proto/harbor/v1` (one file per service plus shared `types.proto`), raw SQL over `database/sql` with `modernc.org/sqlite`; the schema lives in `harness.py`.
