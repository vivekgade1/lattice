// Command harbord serves the marina API over gRPC on 127.0.0.1:$PORT, backed by the
// SQLite file $DB_PATH.
package main

import (
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"

	"harborline/internal/app"
	"harborline/internal/platform/store"
)

func main() {
	logger := log.New(os.Stderr, "harbord ", log.LstdFlags)
	port := os.Getenv("PORT")
	if port == "" {
		port = "50051"
	}
	db, err := store.Open(os.Getenv("DB_PATH"))
	if err != nil {
		logger.Fatalf("database: %v", err)
	}
	defer db.Close()

	a := app.Build(db, logger)
	lis, err := net.Listen("tcp", net.JoinHostPort("127.0.0.1", port))
	if err != nil {
		logger.Fatalf("listen: %v", err)
	}
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGTERM, os.Interrupt)
	go func() {
		<-stop
		a.Health.Shutdown()
		a.Server.GracefulStop()
	}()
	logger.Printf("serving on %s (features: %v)", lis.Addr(), a.Features)
	if err := a.Server.Serve(lis); err != nil {
		logger.Fatalf("serve: %v", err)
	}
}
