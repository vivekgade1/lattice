package berths

import (
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// problem is a berth-catalogue error that knows its own wire code.
type problem struct {
	code codes.Code
	msg  string
}

func (p *problem) Error() string { return p.msg }

// GRPCStatus lets grpc-go send p with its code.
func (p *problem) GRPCStatus() *status.Status { return status.New(p.code, p.msg) }

func badInput(format string, args ...any) error {
	return &problem{code: codes.InvalidArgument, msg: fmt.Sprintf(format, args...)}
}

func noSuchBerth(code string) error {
	return &problem{code: codes.NotFound, msg: fmt.Sprintf("no berth %q", code)}
}

func duplicate(code string) error {
	return &problem{code: codes.AlreadyExists, msg: fmt.Sprintf("berth %q exists", code)}
}

func storeFailed(err error) error {
	return &problem{code: codes.Internal, msg: "berth store: " + err.Error()}
}
