package app

import (
	"google.golang.org/grpc"
)

// Option configures the server Build assembles.
type Option func(*config)

type config struct {
	unary    []grpc.UnaryServerInterceptor
	stream   []grpc.StreamServerInterceptor
	services []func(grpc.ServiceRegistrar)
}

// WithUnary appends unary interceptors (outermost first).
func WithUnary(in ...grpc.UnaryServerInterceptor) Option {
	return func(c *config) { c.unary = append(c.unary, in...) }
}

// WithStream appends stream interceptors.
func WithStream(in ...grpc.StreamServerInterceptor) Option {
	return func(c *config) { c.stream = append(c.stream, in...) }
}

// WithService adds a function that registers a service once the server exists.
func WithService(register func(grpc.ServiceRegistrar)) Option {
	return func(c *config) { c.services = append(c.services, register) }
}

func (c *config) serverOptions() []grpc.ServerOption {
	return []grpc.ServerOption{
		grpc.ChainUnaryInterceptor(c.unary...),
		grpc.ChainStreamInterceptor(c.stream...),
	}
}
