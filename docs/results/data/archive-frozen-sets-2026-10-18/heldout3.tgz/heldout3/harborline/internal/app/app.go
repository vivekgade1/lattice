// Package app assembles the marina's gRPC server from its feature packages.
package app

import (
	"database/sql"
	"log"

	"google.golang.org/grpc"
	"google.golang.org/grpc/health"
	healthpb "google.golang.org/grpc/health/grpc_health_v1"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/accounts"
	_ "harborline/internal/berths" // offers itself to the registry
	"harborline/internal/bookings"
	"harborline/internal/platform/fault"
	"harborline/internal/platform/gate"
	"harborline/internal/platform/guard"
	"harborline/internal/platform/registry"
	"harborline/internal/platform/session"
	"harborline/internal/tides"
	"harborline/internal/vessels"
	"harborline/internal/yard"
)

// App is a built server and what it serves.
type App struct {
	Server   *grpc.Server
	Health   *health.Server
	Features []string
}

// Build assembles the server over db.
func Build(db *sql.DB, logger *log.Logger) *App {
	sessions := session.NewStore(db)
	keeper := gate.NewKeeper(sessions,
		gate.Anonymous(harborv1.Accounts_Login_FullMethodName).
			AndService(harborv1.Tides_ServiceDesc.ServiceName).
			AndService(healthpb.Health_ServiceDesc.ServiceName))

	cfg := &config{}
	for _, opt := range []Option{
		WithUnary(guard.Recover(logger), keeper.Unary, fault.Translate),
		WithStream(keeper.Stream),
		WithService(yard.Installer(db)),
	} {
		opt(cfg)
	}
	s := grpc.NewServer(cfg.serverOptions()...)

	harborv1.RegisterAccountsServer(s, accounts.NewService(db, sessions))
	features := registry.InstallAll(s, registry.Deps{DB: db})
	bookings.NewModule(db).Mount(s)
	expose(s, vessels.Descriptor, vessels.New(db, vessels.WithMaxLength(40)))
	for _, register := range cfg.services {
		register(s)
	}
	extras{station: tides.NewStation(db)}.attach(s)

	hs := health.NewServer()
	healthpb.RegisterHealthServer(s, hs)
	hs.SetServingStatus("", healthpb.HealthCheckResponse_SERVING)
	return &App{Server: s, Health: hs, Features: features}
}
