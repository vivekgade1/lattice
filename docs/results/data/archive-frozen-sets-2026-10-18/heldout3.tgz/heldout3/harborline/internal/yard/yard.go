// Package yard serves harbor.v1.Yard: work orders raised against a booking.
package yard

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"google.golang.org/grpc"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/actor"
)

var kinds = map[string]bool{"pumpout": true, "shore_power": true, "haul_out": true}

type workshop struct {
	harborv1.UnimplementedYardServer
	db *sql.DB
}

// Installer answers the function that puts the yard service on a registrar.
func Installer(db *sql.DB) func(grpc.ServiceRegistrar) {
	w := &workshop{db: db}
	return func(r grpc.ServiceRegistrar) {
		harborv1.RegisterYardServer(r, w)
	}
}

// bookingOf answers (owner, status) of a booking, or noBooking.
func (w *workshop) bookingOf(ctx context.Context, id int64) (int64, string, error) {
	var owner int64
	var st string
	err := w.db.QueryRowContext(ctx, `SELECT user_id, status FROM bookings WHERE id = ?`, id).Scan(&owner, &st)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, "", noBooking.because(fmt.Sprintf("no booking %d", id))
	}
	if err != nil {
		return 0, "", storeDown.because(err.Error())
	}
	return owner, st, nil
}

func (w *workshop) OpenWorkOrder(ctx context.Context, req *harborv1.OpenWorkOrderRequest) (*harborv1.WorkOrder, error) {
	who, _ := actor.From(ctx)
	if !kinds[req.GetKind()] {
		return nil, unknownKind.because(fmt.Sprintf("kind %q is not offered", req.GetKind()))
	}
	owner, st, err := w.bookingOf(ctx, req.GetBookingId())
	if err != nil {
		return nil, err
	}
	if owner != who.ID {
		return nil, noBooking.because(fmt.Sprintf("no booking %d", req.GetBookingId()))
	}
	if st == "cancelled" {
		return nil, bookingClosed.because("the booking is cancelled")
	}
	res, err := w.db.ExecContext(ctx, `INSERT INTO work_orders (booking_id, kind, note, done) VALUES (?, ?, ?, 0)`,
		req.GetBookingId(), req.GetKind(), req.GetNote())
	if err != nil {
		return nil, storeDown.because(err.Error())
	}
	id, _ := res.LastInsertId()
	return &harborv1.WorkOrder{Id: id, BookingId: req.GetBookingId(), Kind: req.GetKind(), Note: req.GetNote()}, nil
}

func (w *workshop) ListWorkOrders(ctx context.Context, req *harborv1.ListWorkOrdersRequest) (*harborv1.ListWorkOrdersResponse, error) {
	who, _ := actor.From(ctx)
	owner, _, err := w.bookingOf(ctx, req.GetBookingId())
	if err != nil {
		return nil, err
	}
	if owner != who.ID && !who.Is(actor.Yard, actor.Harbormaster) {
		return nil, noBooking.because(fmt.Sprintf("no booking %d", req.GetBookingId()))
	}
	rows, err := w.db.QueryContext(ctx, `SELECT id, booking_id, kind, note, done FROM work_orders WHERE booking_id = ? ORDER BY id`, req.GetBookingId())
	if err != nil {
		return nil, storeDown.because(err.Error())
	}
	defer rows.Close()
	out := &harborv1.ListWorkOrdersResponse{}
	for rows.Next() {
		var o harborv1.WorkOrder
		var done int
		if err := rows.Scan(&o.Id, &o.BookingId, &o.Kind, &o.Note, &done); err != nil {
			return nil, storeDown.because(err.Error())
		}
		o.Done = done != 0
		out.WorkOrders = append(out.WorkOrders, &o)
	}
	return out, nil
}

func (w *workshop) CompleteWorkOrder(ctx context.Context, req *harborv1.CompleteWorkOrderRequest) (*harborv1.WorkOrder, error) {
	if _, err := actor.Need(ctx, actor.Yard, actor.Harbormaster); err != nil {
		return nil, err
	}
	var o harborv1.WorkOrder
	var done int
	err := w.db.QueryRowContext(ctx, `SELECT id, booking_id, kind, note, done FROM work_orders WHERE id = ?`, req.GetId()).
		Scan(&o.Id, &o.BookingId, &o.Kind, &o.Note, &done)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, noOrder.because(fmt.Sprintf("no work order %d", req.GetId()))
	}
	if err != nil {
		return nil, storeDown.because(err.Error())
	}
	if done != 0 {
		return nil, alreadyDone.because("the work order is done")
	}
	if _, err := w.db.ExecContext(ctx, `UPDATE work_orders SET done = 1 WHERE id = ?`, o.Id); err != nil {
		return nil, storeDown.because(err.Error())
	}
	o.Done = true
	return &o, nil
}
