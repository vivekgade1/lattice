// Package fuel will serve harbor.v1.Fuel once the fuel dock opens. It is not on the
// server yet.
package fuel

import (
	"context"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	harborv1 "harborline/gen/harbor/v1"
)

var centsPerLitre = map[string]int64{"diesel": 189, "petrol": 205}

// Dock prices fuel.
type Dock struct {
	harborv1.UnimplementedFuelServer
}

func (Dock) QuoteFuel(_ context.Context, req *harborv1.QuoteFuelRequest) (*harborv1.FuelQuote, error) {
	c, ok := centsPerLitre[req.GetGrade()]
	if !ok || req.GetLitres() <= 0 {
		return nil, status.Error(codes.InvalidArgument, "unknown grade or litres")
	}
	return &harborv1.FuelQuote{Grade: req.GetGrade(), Litres: req.GetLitres(), TotalCents: c * int64(req.GetLitres())}, nil
}
