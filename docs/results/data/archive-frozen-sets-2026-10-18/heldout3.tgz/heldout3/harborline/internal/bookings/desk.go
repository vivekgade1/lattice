package bookings

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/actor"
	"harborline/internal/platform/fault"
)

// desk implements harborv1.BookingsServer. Its errors are domain errors from
// package fault; the server's translating interceptor gives them their codes.
type desk struct {
	harborv1.UnimplementedBookingsServer
	repo repo
}

const maxNights = 30

func (d *desk) BookBerth(ctx context.Context, req *harborv1.BookBerthRequest) (*harborv1.Booking, error) {
	who, _ := actor.From(ctx)
	if req.GetNights() < 1 || req.GetNights() > maxNights {
		return nil, fmt.Errorf("nights must be 1..%d: %w", maxNights, fault.ErrInvalid)
	}
	code, hull := strings.TrimSpace(req.GetBerthCode()), strings.ToUpper(strings.TrimSpace(req.GetVesselHull()))
	if code == "" || hull == "" {
		return nil, fmt.Errorf("berth_code and vessel_hull are required: %w", fault.ErrInvalid)
	}
	var (
		berthID, nightly int64
		berthLen         int32
		active           int
	)
	err := d.repo.db.QueryRowContext(ctx, `SELECT id, length_m, nightly_cents, active FROM berths WHERE code = ?`, code).
		Scan(&berthID, &berthLen, &nightly, &active)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, fmt.Errorf("berth %s: %w", code, fault.ErrNotFound)
	} else if err != nil {
		return nil, fmt.Errorf("berth %s: %v", code, err)
	}
	if active == 0 {
		return nil, fmt.Errorf("berth %s is closed: %w", code, fault.ErrWrongStep)
	}
	var (
		vesselID int64
		vLen     int32
	)
	err = d.repo.db.QueryRowContext(ctx, `SELECT id, length_m FROM vessels WHERE hull = ? AND owner_id = ?`, hull, who.ID).
		Scan(&vesselID, &vLen)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, fmt.Errorf("vessel %s: %w", hull, fault.ErrNotFound)
	} else if err != nil {
		return nil, fmt.Errorf("vessel %s: %v", hull, err)
	}
	if vLen > berthLen {
		return nil, fmt.Errorf("vessel %s (%dm) does not fit berth %s (%dm): %w", hull, vLen, code, berthLen, fault.ErrWrongStep)
	}
	var busy int
	if err := d.repo.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM bookings WHERE berth_id = ? AND status IN ('reserved', 'checked_in')`, berthID).Scan(&busy); err != nil {
		return nil, fmt.Errorf("occupancy: %v", err)
	}
	if busy > 0 {
		return nil, fmt.Errorf("berth %s: %w", code, fault.ErrOccupied)
	}
	total := nightly * int64(req.GetNights())
	res, err := d.repo.db.ExecContext(ctx, `INSERT INTO bookings (berth_id, vessel_id, user_id, nights, status, total_cents) VALUES (?, ?, ?, ?, 'reserved', ?)`,
		berthID, vesselID, who.ID, req.GetNights(), total)
	if err != nil {
		return nil, fmt.Errorf("insert booking: %v", err)
	}
	id, _ := res.LastInsertId()
	return &harborv1.Booking{Id: id, BerthCode: code, VesselId: vesselID, Nights: req.GetNights(),
		Status: harborv1.BookingStatus_BOOKING_STATUS_RESERVED, TotalCents: total}, nil
}

// visible loads a booking the caller may see: its owner's, or any for a harbormaster.
func (d *desk) visible(ctx context.Context, id int64) (bookingRow, error) {
	who, _ := actor.From(ctx)
	row, err := d.repo.byID(ctx, id)
	if err != nil {
		return bookingRow{}, err
	}
	if row.userID != who.ID && !who.Is(actor.Harbormaster) {
		return bookingRow{}, fmt.Errorf("booking %d: %w", id, fault.ErrNotFound)
	}
	return row, nil
}

func (d *desk) GetBooking(ctx context.Context, req *harborv1.GetBookingRequest) (*harborv1.Booking, error) {
	row, err := d.visible(ctx, req.GetId())
	if err != nil {
		return nil, err
	}
	return row.booking, nil
}

func (d *desk) ListBookings(ctx context.Context, req *harborv1.ListBookingsRequest) (*harborv1.ListBookingsResponse, error) {
	who, _ := actor.From(ctx)
	if req.GetIncludeAll() && !who.Is(actor.Harbormaster) {
		return nil, fmt.Errorf("include_all: %w", fault.ErrForbidden)
	}
	list, err := d.repo.list(ctx, who.ID, req.GetIncludeAll())
	if err != nil {
		return nil, err
	}
	return &harborv1.ListBookingsResponse{Bookings: list}, nil
}

func (d *desk) CancelBooking(ctx context.Context, req *harborv1.CancelBookingRequest) (*harborv1.Booking, error) {
	row, err := d.visible(ctx, req.GetId())
	if err != nil {
		return nil, err
	}
	if row.booking.Status != harborv1.BookingStatus_BOOKING_STATUS_RESERVED {
		return nil, fmt.Errorf("booking %d is %s: %w", row.booking.Id, row.booking.Status, fault.ErrWrongStep)
	}
	if err := d.repo.setStatus(ctx, row.booking.Id, "cancelled"); err != nil {
		return nil, err
	}
	row.booking.Status = harborv1.BookingStatus_BOOKING_STATUS_CANCELLED
	return row.booking, nil
}

func (d *desk) CheckIn(ctx context.Context, req *harborv1.CheckInRequest) (*harborv1.Booking, error) {
	who, _ := actor.From(ctx)
	if !who.Is(actor.Harbormaster) {
		return nil, fmt.Errorf("check-in is done by the harbormaster: %w", fault.ErrForbidden)
	}
	row, err := d.repo.byID(ctx, req.GetBookingId())
	if err != nil {
		return nil, err
	}
	if row.booking.Status != harborv1.BookingStatus_BOOKING_STATUS_RESERVED {
		return nil, fmt.Errorf("booking %d is %s: %w", row.booking.Id, row.booking.Status, fault.ErrWrongStep)
	}
	if err := d.repo.setStatus(ctx, row.booking.Id, "checked_in"); err != nil {
		return nil, err
	}
	row.booking.Status = harborv1.BookingStatus_BOOKING_STATUS_CHECKED_IN
	return row.booking, nil
}
