// Package bookings serves harbor.v1.Bookings: reserving berths for vessels.
package bookings

import (
	"database/sql"

	"google.golang.org/grpc"

	harborv1 "harborline/gen/harbor/v1"
)

// Module is the bookings feature as the server sees it.
type Module interface {
	Mount(r grpc.ServiceRegistrar)
}

// NewModule builds the bookings feature over db.
func NewModule(db *sql.DB) Module {
	return &desk{repo: repo{db: db}}
}

// Mount puts the bookings service on r.
func (d *desk) Mount(r grpc.ServiceRegistrar) {
	r.RegisterService(&harborv1.Bookings_ServiceDesc, d)
}
