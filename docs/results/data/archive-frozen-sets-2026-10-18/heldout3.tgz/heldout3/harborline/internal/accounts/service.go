// Package accounts serves harbor.v1.Accounts: sign-in and the caller's own account.
package accounts

import (
	"context"
	"database/sql"
	"errors"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/actor"
	"harborline/internal/platform/session"
)

// Service implements harborv1.AccountsServer.
type Service struct {
	harborv1.UnimplementedAccountsServer
	db       *sql.DB
	sessions *session.Store
}

// NewService builds the accounts service.
func NewService(db *sql.DB, sessions *session.Store) *Service {
	return &Service{db: db, sessions: sessions}
}

// Login checks a username and password and opens a session.
func (s *Service) Login(ctx context.Context, req *harborv1.LoginRequest) (*harborv1.LoginResponse, error) {
	if req.GetUsername() == "" || req.GetPassword() == "" {
		return nil, status.Error(codes.InvalidArgument, "username and password are required")
	}
	var (
		id       int64
		password string
		role     string
	)
	err := s.db.QueryRowContext(ctx, `SELECT id, password, role FROM users WHERE username = ?`, req.GetUsername()).
		Scan(&id, &password, &role)
	if errors.Is(err, sql.ErrNoRows) || (err == nil && password != req.GetPassword()) {
		return nil, status.Error(codes.Unauthenticated, "wrong username or password")
	}
	if err != nil {
		return nil, status.Error(codes.Internal, "user lookup failed")
	}
	tok, err := s.sessions.Issue(ctx, id)
	if err != nil {
		return nil, status.Error(codes.Internal, "could not open a session")
	}
	return &harborv1.LoginResponse{Token: tok, UserId: id, Role: roleOf(role)}, nil
}

// WhoAmI answers the caller's profile.
func (s *Service) WhoAmI(ctx context.Context, _ *harborv1.WhoAmIRequest) (*harborv1.Profile, error) {
	p, _ := actor.From(ctx)
	return profileOf(p), nil
}

// Logout revokes the session the call was made with.
func (s *Service) Logout(ctx context.Context, _ *harborv1.LogoutRequest) (*harborv1.LogoutResponse, error) {
	p, _ := actor.From(ctx)
	if err := s.sessions.Revoke(ctx, p.Token); err != nil {
		return nil, status.Error(codes.Internal, "could not revoke the session")
	}
	return &harborv1.LogoutResponse{Revoked: true}, nil
}

// StepDown drops an elevated role: the caller becomes a skipper.
func (s *Service) StepDown(ctx context.Context, _ *harborv1.StepDownRequest) (*harborv1.Profile, error) {
	p, _ := actor.From(ctx)
	if p.Role == actor.Skipper {
		return nil, status.Error(codes.FailedPrecondition, "already a skipper")
	}
	if _, err := s.db.ExecContext(ctx, `UPDATE users SET role = ? WHERE id = ?`, actor.Skipper, p.ID); err != nil {
		return nil, status.Error(codes.Internal, "could not change the role")
	}
	p.Role = actor.Skipper
	return profileOf(p), nil
}

// CloseAccount deletes the caller's account (and its sessions) once confirmed.
func (s *Service) CloseAccount(ctx context.Context, req *harborv1.CloseAccountRequest) (*harborv1.CloseAccountResponse, error) {
	p, _ := actor.From(ctx)
	if req.GetConfirm() != p.Username {
		return nil, status.Error(codes.InvalidArgument, "confirm must repeat your username")
	}
	var live int
	if err := s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM bookings WHERE user_id = ? AND status IN ('reserved', 'checked_in')`, p.ID).Scan(&live); err != nil {
		return nil, status.Error(codes.Internal, "booking lookup failed")
	}
	if live > 0 {
		return nil, status.Error(codes.FailedPrecondition, "cancel or finish your bookings first")
	}
	if err := s.sessions.RevokeAll(ctx, p.ID); err != nil {
		return nil, status.Error(codes.Internal, "could not end sessions")
	}
	if _, err := s.db.ExecContext(ctx, `DELETE FROM users WHERE id = ?`, p.ID); err != nil {
		return nil, status.Error(codes.Internal, "could not delete the account")
	}
	return &harborv1.CloseAccountResponse{ClosedId: p.ID}, nil
}

func profileOf(p actor.Principal) *harborv1.Profile {
	return &harborv1.Profile{Id: p.ID, Username: p.Username, DisplayName: p.DisplayName, Role: roleOf(p.Role)}
}

func roleOf(r string) harborv1.Role {
	switch r {
	case actor.Skipper:
		return harborv1.Role_ROLE_SKIPPER
	case actor.Harbormaster:
		return harborv1.Role_ROLE_HARBORMASTER
	case actor.Yard:
		return harborv1.Role_ROLE_YARD
	}
	return harborv1.Role_ROLE_UNSPECIFIED
}
