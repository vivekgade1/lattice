package bookings

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/fault"
)

type repo struct{ db *sql.DB }

type bookingRow struct {
	booking *harborv1.Booking
	userID  int64
}

var statusNames = map[string]harborv1.BookingStatus{
	"reserved":   harborv1.BookingStatus_BOOKING_STATUS_RESERVED,
	"checked_in": harborv1.BookingStatus_BOOKING_STATUS_CHECKED_IN,
	"cancelled":  harborv1.BookingStatus_BOOKING_STATUS_CANCELLED,
}

const bookingSelect = `SELECT b.id, br.code, b.vessel_id, b.nights, b.status, b.total_cents, b.user_id
	FROM bookings b JOIN berths br ON br.id = b.berth_id`

func scanBooking(row interface{ Scan(...any) error }) (bookingRow, error) {
	var (
		b  harborv1.Booking
		st string
		u  int64
	)
	if err := row.Scan(&b.Id, &b.BerthCode, &b.VesselId, &b.Nights, &st, &b.TotalCents, &u); err != nil {
		return bookingRow{}, err
	}
	b.Status = statusNames[st]
	return bookingRow{booking: &b, userID: u}, nil
}

func (r repo) byID(ctx context.Context, id int64) (bookingRow, error) {
	row, err := scanBooking(r.db.QueryRowContext(ctx, bookingSelect+` WHERE b.id = ?`, id))
	if errors.Is(err, sql.ErrNoRows) {
		return bookingRow{}, fmt.Errorf("booking %d: %w", id, fault.ErrNotFound)
	}
	if err != nil {
		return bookingRow{}, fmt.Errorf("booking %d: %v", id, err)
	}
	return row, nil
}

func (r repo) list(ctx context.Context, userID int64, all bool) ([]*harborv1.Booking, error) {
	q, args := bookingSelect+` WHERE b.user_id = ? ORDER BY b.id`, []any{userID}
	if all {
		q, args = bookingSelect+` ORDER BY b.id`, nil
	}
	rows, err := r.db.QueryContext(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("bookings: %v", err)
	}
	defer rows.Close()
	var out []*harborv1.Booking
	for rows.Next() {
		row, err := scanBooking(rows)
		if err != nil {
			return nil, fmt.Errorf("bookings: %v", err)
		}
		out = append(out, row.booking)
	}
	return out, nil
}

func (r repo) setStatus(ctx context.Context, id int64, st string) error {
	if _, err := r.db.ExecContext(ctx, `UPDATE bookings SET status = ? WHERE id = ?`, st, id); err != nil {
		return fmt.Errorf("booking %d: %v", id, err)
	}
	return nil
}
