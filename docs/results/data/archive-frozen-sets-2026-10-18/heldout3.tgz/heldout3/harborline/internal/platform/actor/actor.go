// Package actor carries the authenticated caller through a request context.
package actor

import (
	"context"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Roles as stored in users.role.
const (
	Skipper      = "skipper"
	Harbormaster = "harbormaster"
	Yard         = "yard"
)

// Principal is the caller a session resolved to.
type Principal struct {
	ID          int64
	Username    string
	DisplayName string
	Role        string
	Token       string
}

// Is reports whether the principal holds one of roles.
func (p Principal) Is(roles ...string) bool {
	for _, r := range roles {
		if p.Role == r {
			return true
		}
	}
	return false
}

type ctxKey struct{}

// With returns ctx carrying p.
func With(ctx context.Context, p Principal) context.Context {
	return context.WithValue(ctx, ctxKey{}, p)
}

// From returns the principal of ctx, if any.
func From(ctx context.Context) (Principal, bool) {
	p, ok := ctx.Value(ctxKey{}).(Principal)
	return p, ok
}

// Need answers the caller when it holds one of roles, else PERMISSION_DENIED.
func Need(ctx context.Context, roles ...string) (Principal, error) {
	p, ok := From(ctx)
	if !ok {
		return Principal{}, status.Error(codes.PermissionDenied, "no caller")
	}
	if !p.Is(roles...) {
		return Principal{}, status.Errorf(codes.PermissionDenied, "role %s may not do this", p.Role)
	}
	return p, nil
}
