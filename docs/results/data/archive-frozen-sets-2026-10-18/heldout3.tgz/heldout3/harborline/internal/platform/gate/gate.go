package gate

import (
	"context"
	"errors"
	"strings"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"

	"harborline/internal/platform/actor"
	"harborline/internal/platform/session"
)

// Resolver turns a bearer token into a caller.
type Resolver interface {
	Resolve(ctx context.Context, token string) (actor.Principal, error)
}

var (
	errNoCredentials = status.Error(codes.Unauthenticated, "missing bearer token")
	errBadScheme     = status.Error(codes.Unauthenticated, "authorization must be a bearer token")
)

// Keeper authenticates callers against a Resolver under a Policy.
type Keeper struct {
	sessions Resolver
	policy   *Policy
}

// NewKeeper builds a keeper.
func NewKeeper(r Resolver, p *Policy) *Keeper { return &Keeper{sessions: r, policy: p} }

// admit answers the caller of ctx or a refusal.
func (k *Keeper) admit(ctx context.Context) (actor.Principal, error) {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return actor.Principal{}, errNoCredentials
	}
	vals := md.Get("authorization")
	if len(vals) == 0 {
		return actor.Principal{}, errNoCredentials
	}
	raw, found := strings.CutPrefix(vals[0], "Bearer ")
	if !found || raw == "" {
		return actor.Principal{}, errBadScheme
	}
	p, err := k.sessions.Resolve(ctx, raw)
	switch {
	case errors.Is(err, session.ErrUnknown):
		return actor.Principal{}, status.Error(codes.Unauthenticated, "session is not valid")
	case err != nil:
		return actor.Principal{}, status.Error(codes.Unavailable, "session store unavailable")
	}
	return p, nil
}

// Unary is the keeper as a unary interceptor.
func (k *Keeper) Unary(ctx context.Context, req any, info *grpc.UnaryServerInfo, next grpc.UnaryHandler) (any, error) {
	if k.policy.admitsAnonymous(info.FullMethod) {
		return next(ctx, req)
	}
	who, err := k.admit(ctx)
	if err != nil {
		return nil, err
	}
	return next(actor.With(ctx, who), req)
}

type authedStream struct {
	grpc.ServerStream
	ctx context.Context
}

func (s authedStream) Context() context.Context { return s.ctx }

// Stream is the keeper as a stream interceptor.
func (k *Keeper) Stream(srv any, ss grpc.ServerStream, info *grpc.StreamServerInfo, next grpc.StreamHandler) error {
	if k.policy.admitsAnonymous(info.FullMethod) {
		return next(srv, ss)
	}
	who, err := k.admit(ss.Context())
	if err != nil {
		return err
	}
	return next(srv, authedStream{ServerStream: ss, ctx: actor.With(ss.Context(), who)})
}
