// Package session issues, resolves and revokes bearer tokens (table sessions).
package session

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"errors"

	"harborline/internal/platform/actor"
)

// ErrUnknown: the token names no live session.
var ErrUnknown = errors.New("session: unknown or revoked token")

// Store is the sessions table.
type Store struct{ db *sql.DB }

// NewStore wraps db.
func NewStore(db *sql.DB) *Store { return &Store{db: db} }

// Issue creates a session for userID and answers its token.
func (s *Store) Issue(ctx context.Context, userID int64) (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	tok := hex.EncodeToString(b)
	_, err := s.db.ExecContext(ctx, `INSERT INTO sessions (token, user_id, revoked) VALUES (?, ?, 0)`, tok, userID)
	return tok, err
}

// Resolve answers the principal of a live token, or ErrUnknown.
func (s *Store) Resolve(ctx context.Context, token string) (actor.Principal, error) {
	var p actor.Principal
	err := s.db.QueryRowContext(ctx, `SELECT u.id, u.username, u.display_name, u.role
		FROM sessions s JOIN users u ON u.id = s.user_id
		WHERE s.token = ? AND s.revoked = 0`, token).Scan(&p.ID, &p.Username, &p.DisplayName, &p.Role)
	if errors.Is(err, sql.ErrNoRows) {
		return actor.Principal{}, ErrUnknown
	}
	if err != nil {
		return actor.Principal{}, err
	}
	p.Token = token
	return p, nil
}

// Revoke ends one session.
func (s *Store) Revoke(ctx context.Context, token string) error {
	_, err := s.db.ExecContext(ctx, `UPDATE sessions SET revoked = 1 WHERE token = ?`, token)
	return err
}

// RevokeAll ends every session of userID.
func (s *Store) RevokeAll(ctx context.Context, userID int64) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM sessions WHERE user_id = ?`, userID)
	return err
}
