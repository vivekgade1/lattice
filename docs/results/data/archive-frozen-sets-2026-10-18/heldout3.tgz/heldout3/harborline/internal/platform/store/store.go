// Package store opens the marina database.
package store

import (
	"database/sql"
	"fmt"

	_ "modernc.org/sqlite" // pure-Go driver, registered as "sqlite"
)

// Open opens the SQLite file at path. The schema is created by the operator's tooling.
func Open(path string) (*sql.DB, error) {
	if path == "" {
		return nil, fmt.Errorf("store: empty database path")
	}
	db, err := sql.Open("sqlite", "file:"+path+"?_pragma=busy_timeout(5000)&_pragma=foreign_keys(1)")
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1)
	if err := db.Ping(); err != nil {
		db.Close()
		return nil, err
	}
	return db, nil
}
