// Package registry lets feature packages offer themselves to the server at init time.
package registry

import (
	"database/sql"
	"fmt"
	"sort"
	"sync"

	"google.golang.org/grpc"
)

// Deps are what a feature may use when it is installed.
type Deps struct {
	DB *sql.DB
}

// Installer puts a feature's services on r.
type Installer interface {
	Install(r grpc.ServiceRegistrar, d Deps)
}

// InstallFunc adapts a function to Installer.
type InstallFunc func(r grpc.ServiceRegistrar, d Deps)

// Install calls f.
func (f InstallFunc) Install(r grpc.ServiceRegistrar, d Deps) { f(r, d) }

var (
	mu       sync.Mutex
	features = map[string]Installer{}
)

// Offer records a feature under name; a duplicate name panics.
func Offer(name string, in Installer) {
	mu.Lock()
	defer mu.Unlock()
	if _, dup := features[name]; dup {
		panic(fmt.Sprintf("registry: feature %q offered twice", name))
	}
	features[name] = in
}

// InstallAll installs every offered feature, by name order.
func InstallAll(r grpc.ServiceRegistrar, d Deps) []string {
	mu.Lock()
	defer mu.Unlock()
	names := make([]string, 0, len(features))
	for n := range features {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		features[n].Install(r, d)
	}
	return names
}
