// Package berths serves harbor.v1.Berths, the berth catalogue.
package berths

import (
	"context"
	"database/sql"
	"errors"
	"strings"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/actor"
)

// catalog implements harborv1.BerthsServer. RetireBerth is not built yet.
type catalog struct {
	harborv1.UnimplementedBerthsServer
	db *sql.DB
}

const berthCols = `id, code, pier, length_m, nightly_cents, active`

func scanBerth(row interface{ Scan(...any) error }) (*harborv1.Berth, error) {
	var b harborv1.Berth
	var active int
	if err := row.Scan(&b.Id, &b.Code, &b.Pier, &b.LengthM, &b.NightlyCents, &active); err != nil {
		return nil, err
	}
	b.Active = active != 0
	return &b, nil
}

func (c *catalog) ListBerths(ctx context.Context, req *harborv1.ListBerthsRequest) (*harborv1.ListBerthsResponse, error) {
	q := `SELECT ` + berthCols + ` FROM berths WHERE 1 = 1`
	var args []any
	if req.GetPier() != "" {
		q += ` AND pier = ?`
		args = append(args, req.GetPier())
	}
	if req.GetOnlyActive() {
		q += ` AND active = 1`
	}
	rows, err := c.db.QueryContext(ctx, q+` ORDER BY code`, args...)
	if err != nil {
		return nil, storeFailed(err)
	}
	defer rows.Close()
	out := &harborv1.ListBerthsResponse{}
	for rows.Next() {
		b, err := scanBerth(rows)
		if err != nil {
			return nil, storeFailed(err)
		}
		out.Berths = append(out.Berths, b)
	}
	return out, nil
}

func (c *catalog) GetBerth(ctx context.Context, req *harborv1.GetBerthRequest) (*harborv1.Berth, error) {
	code := strings.TrimSpace(req.GetCode())
	if code == "" {
		return nil, badInput("code is required")
	}
	b, err := scanBerth(c.db.QueryRowContext(ctx, `SELECT `+berthCols+` FROM berths WHERE code = ?`, code))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, noSuchBerth(code)
	}
	if err != nil {
		return nil, storeFailed(err)
	}
	return b, nil
}

func (c *catalog) CreateBerth(ctx context.Context, req *harborv1.CreateBerthRequest) (*harborv1.Berth, error) {
	if _, err := actor.Need(ctx, actor.Harbormaster); err != nil {
		return nil, err
	}
	code := strings.TrimSpace(req.GetCode())
	if code == "" || req.GetPier() == "" {
		return nil, badInput("code and pier are required")
	}
	if req.GetLengthM() <= 0 || req.GetNightlyCents() < 0 {
		return nil, badInput("length_m must be positive and nightly_cents not negative")
	}
	var n int
	if err := c.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM berths WHERE code = ?`, code).Scan(&n); err != nil {
		return nil, storeFailed(err)
	}
	if n > 0 {
		return nil, duplicate(code)
	}
	res, err := c.db.ExecContext(ctx, `INSERT INTO berths (code, pier, length_m, nightly_cents, active) VALUES (?, ?, ?, ?, 1)`,
		code, req.GetPier(), req.GetLengthM(), req.GetNightlyCents())
	if err != nil {
		return nil, storeFailed(err)
	}
	id, _ := res.LastInsertId()
	return &harborv1.Berth{Id: id, Code: code, Pier: req.GetPier(), LengthM: req.GetLengthM(), NightlyCents: req.GetNightlyCents(), Active: true}, nil
}
