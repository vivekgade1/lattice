// Package vessels serves harbor.v1.Vessels: the boats skippers keep at the marina.
package vessels

import (
	"context"
	"database/sql"
	"errors"
	"strings"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/actor"
)

// Descriptor is the service this package implements.
var Descriptor = &harborv1.Vessels_ServiceDesc

// Option tunes the vessel register.
type Option func(*register)

// WithMaxLength caps the length of a vessel that may be registered.
func WithMaxLength(m int32) Option { return func(r *register) { r.maxLength = m } }

// New answers the vessels service over db.
func New(db *sql.DB, opts ...Option) harborv1.VesselsServer {
	r := register{db: db, maxLength: 60}
	for _, o := range opts {
		o(&r)
	}
	return r
}

type register struct {
	harborv1.UnimplementedVesselsServer
	db        *sql.DB
	maxLength int32
}

func fail(c codes.Code, msg string, args ...any) error { return status.Errorf(c, msg, args...) }

func (r register) RegisterVessel(ctx context.Context, req *harborv1.RegisterVesselRequest) (*harborv1.Vessel, error) {
	p, _ := actor.From(ctx)
	hull := strings.ToUpper(strings.TrimSpace(req.GetHull()))
	if hull == "" || strings.TrimSpace(req.GetName()) == "" {
		return nil, fail(codes.InvalidArgument, "hull and name are required")
	}
	if req.GetLengthM() <= 0 || req.GetLengthM() > r.maxLength {
		return nil, fail(codes.InvalidArgument, "length_m must be within 1..%d", r.maxLength)
	}
	var taken int
	if err := r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM vessels WHERE hull = ?`, hull).Scan(&taken); err != nil {
		return nil, fail(codes.Internal, "vessel lookup: %v", err)
	}
	if taken > 0 {
		return nil, fail(codes.AlreadyExists, "hull %s is registered", hull)
	}
	res, err := r.db.ExecContext(ctx, `INSERT INTO vessels (owner_id, hull, name, length_m) VALUES (?, ?, ?, ?)`,
		p.ID, hull, req.GetName(), req.GetLengthM())
	if err != nil {
		return nil, fail(codes.Internal, "vessel insert: %v", err)
	}
	id, _ := res.LastInsertId()
	return &harborv1.Vessel{Id: id, Hull: hull, Name: req.GetName(), LengthM: req.GetLengthM(), OwnerId: p.ID}, nil
}

// owned loads vessel id if the caller owns it (a harbormaster sees every vessel).
func (r register) owned(ctx context.Context, id int64) (*harborv1.Vessel, error) {
	p, _ := actor.From(ctx)
	var v harborv1.Vessel
	err := r.db.QueryRowContext(ctx, `SELECT id, hull, name, length_m, owner_id FROM vessels WHERE id = ?`, id).
		Scan(&v.Id, &v.Hull, &v.Name, &v.LengthM, &v.OwnerId)
	if errors.Is(err, sql.ErrNoRows) || (err == nil && v.OwnerId != p.ID && !p.Is(actor.Harbormaster)) {
		return nil, fail(codes.NotFound, "no vessel %d", id)
	}
	if err != nil {
		return nil, fail(codes.Internal, "vessel lookup: %v", err)
	}
	return &v, nil
}

func (r register) GetVessel(ctx context.Context, req *harborv1.GetVesselRequest) (*harborv1.Vessel, error) {
	return r.owned(ctx, req.GetId())
}

func (r register) RenameVessel(ctx context.Context, req *harborv1.RenameVesselRequest) (*harborv1.Vessel, error) {
	name := strings.TrimSpace(req.GetName())
	if name == "" {
		return nil, fail(codes.InvalidArgument, "name is required")
	}
	v, err := r.owned(ctx, req.GetId())
	if err != nil {
		return nil, err
	}
	if _, err := r.db.ExecContext(ctx, `UPDATE vessels SET name = ? WHERE id = ?`, name, v.Id); err != nil {
		return nil, fail(codes.Internal, "vessel update: %v", err)
	}
	v.Name = name
	return v, nil
}

func (r register) ListVessels(ctx context.Context, _ *harborv1.ListVesselsRequest) (*harborv1.ListVesselsResponse, error) {
	p, _ := actor.From(ctx)
	rows, err := r.db.QueryContext(ctx, `SELECT id, hull, name, length_m, owner_id FROM vessels WHERE owner_id = ? ORDER BY id`, p.ID)
	if err != nil {
		return nil, fail(codes.Internal, "vessel list: %v", err)
	}
	defer rows.Close()
	out := &harborv1.ListVesselsResponse{}
	for rows.Next() {
		var v harborv1.Vessel
		if err := rows.Scan(&v.Id, &v.Hull, &v.Name, &v.LengthM, &v.OwnerId); err != nil {
			return nil, fail(codes.Internal, "vessel scan: %v", err)
		}
		out.Vessels = append(out.Vessels, &v)
	}
	return out, nil
}
