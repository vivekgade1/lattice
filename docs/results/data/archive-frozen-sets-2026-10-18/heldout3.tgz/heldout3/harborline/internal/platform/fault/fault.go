// Package fault holds the domain errors handlers return and their wire translation.
package fault

import (
	"context"
	"errors"
	"fmt"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Domain errors. Handlers wrap them with fmt.Errorf("...: %w", ErrX).
var (
	ErrNotFound  = errors.New("not found")
	ErrInvalid   = errors.New("invalid request")
	ErrOccupied  = errors.New("berth occupied")
	ErrWrongStep = errors.New("not allowed in the current state")
	ErrForbidden = errors.New("forbidden for this role")
)

var table = []struct {
	err  error
	code codes.Code
}{
	{ErrNotFound, codes.NotFound},
	{ErrInvalid, codes.InvalidArgument},
	{ErrOccupied, codes.FailedPrecondition},
	{ErrWrongStep, codes.FailedPrecondition},
	{ErrForbidden, codes.PermissionDenied},
}

// Wire converts a handler error into a status error. Errors that already carry a
// status pass through; unknown errors become INTERNAL.
func Wire(err error) error {
	if err == nil {
		return nil
	}
	if _, ok := status.FromError(err); ok {
		return err
	}
	for _, row := range table {
		if errors.Is(err, row.err) {
			return status.Error(row.code, err.Error())
		}
	}
	return status.Error(codes.Internal, fmt.Sprintf("internal: %v", err))
}

// Translate is a unary interceptor applying Wire to every handler error.
func Translate(ctx context.Context, req any, _ *grpc.UnaryServerInfo, next grpc.UnaryHandler) (any, error) {
	resp, err := next(ctx, req)
	if err != nil {
		return nil, Wire(err)
	}
	return resp, nil
}
