// Package guard keeps a panicking handler from taking the process down.
package guard

import (
	"context"
	"log"
	"runtime/debug"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Recover turns a handler panic into INTERNAL.
func Recover(logger *log.Logger) grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req any, info *grpc.UnaryServerInfo, next grpc.UnaryHandler) (resp any, err error) {
		defer func() {
			if r := recover(); r != nil {
				logger.Printf("panic in %s: %v\n%s", info.FullMethod, r, debug.Stack())
				resp, err = nil, status.Error(codes.Internal, "internal error")
			}
		}()
		return next(ctx, req)
	}
}
