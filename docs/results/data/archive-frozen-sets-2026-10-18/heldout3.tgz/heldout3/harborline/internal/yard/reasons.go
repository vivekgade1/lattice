package yard

import (
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// reason is why the yard refused a request.
type reason int

const (
	unknownKind reason = iota + 1
	noBooking
	bookingClosed
	noOrder
	alreadyDone
	storeDown
)

var codeFor = map[reason]codes.Code{
	unknownKind:   codes.InvalidArgument,
	noBooking:     codes.NotFound,
	bookingClosed: codes.FailedPrecondition,
	noOrder:       codes.NotFound,
	alreadyDone:   codes.FailedPrecondition,
	storeDown:     codes.Internal,
}

func (r reason) because(detail string) error {
	return status.Error(codeFor[r], detail)
}
