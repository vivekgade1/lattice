package app

import (
	"google.golang.org/grpc"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/tides"
)

// tideDesk adapts a tide station to the server.
type tideDesk struct {
	*tides.Station
}

// extras are the public, read-only services that need no account.
type extras struct {
	station *tides.Station
}

func (x extras) attach(s *grpc.Server) {
	harborv1.RegisterTidesServer(s, tideDesk{Station: x.station})
}

// expose registers impl under desc.
func expose[T any](r grpc.ServiceRegistrar, desc *grpc.ServiceDesc, impl T) {
	r.RegisterService(desc, impl)
}
