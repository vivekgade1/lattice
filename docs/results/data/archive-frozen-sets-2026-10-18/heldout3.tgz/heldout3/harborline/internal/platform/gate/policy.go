// Package gate decides who may call what before a handler runs.
package gate

import "strings"

// Policy lists what anonymous callers may reach. Everything else needs a live session.
type Policy struct {
	methods  map[string]struct{}
	services []string
}

// Anonymous starts a policy that lets anonymous callers reach the given full method names.
func Anonymous(fullMethods ...string) *Policy {
	p := &Policy{methods: make(map[string]struct{}, len(fullMethods))}
	for _, m := range fullMethods {
		p.methods[m] = struct{}{}
	}
	return p
}

// AndService opens every method of the named service ("pkg.Service").
func (p *Policy) AndService(serviceName string) *Policy {
	p.services = append(p.services, "/"+serviceName+"/")
	return p
}

func (p *Policy) admitsAnonymous(fullMethod string) bool {
	if _, ok := p.methods[fullMethod]; ok {
		return true
	}
	for _, prefix := range p.services {
		if strings.HasPrefix(fullMethod, prefix) {
			return true
		}
	}
	return false
}
