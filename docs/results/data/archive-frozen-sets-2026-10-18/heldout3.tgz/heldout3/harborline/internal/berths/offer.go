package berths

import (
	"google.golang.org/grpc"

	harborv1 "harborline/gen/harbor/v1"
	"harborline/internal/platform/registry"
)

func init() {
	registry.Offer("berths", registry.InstallFunc(install))
}

func install(r grpc.ServiceRegistrar, d registry.Deps) {
	harborv1.RegisterBerthsServer(r, &catalog{db: d.DB})
}
