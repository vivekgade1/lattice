// Package tides serves harbor.v1.Tides: public tide readings.
package tides

import (
	"context"
	"database/sql"
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	harborv1 "harborline/gen/harbor/v1"
)

// Station reads the tide_readings table.
type Station struct {
	harborv1.UnimplementedTidesServer
	db *sql.DB
}

// NewStation builds a station over db.
func NewStation(db *sql.DB) *Station { return &Station{db: db} }

func (s Station) readings(ctx context.Context, station string) ([]*harborv1.TideReading, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT station, at, height_cm FROM tide_readings WHERE station = ? ORDER BY at`, station)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*harborv1.TideReading
	for rows.Next() {
		var r harborv1.TideReading
		if err := rows.Scan(&r.Station, &r.At, &r.HeightCm); err != nil {
			return nil, err
		}
		out = append(out, &r)
	}
	return out, rows.Err()
}

// GetTideTable answers every reading of one station.
func (s Station) GetTideTable(ctx context.Context, req *harborv1.GetTideTableRequest) (*harborv1.TideTable, error) {
	if req.GetStation() == "" {
		return nil, status.Error(codes.InvalidArgument, "station is required")
	}
	rs, err := s.readings(ctx, req.GetStation())
	if err != nil {
		return nil, status.Error(codes.Internal, "tide store unavailable")
	}
	if len(rs) == 0 {
		return nil, status.Error(codes.NotFound, fmt.Sprintf("no readings for %q", req.GetStation()))
	}
	return &harborv1.TideTable{Station: req.GetStation(), Readings: rs}, nil
}

// WatchTides streams the readings of one station.
func (s Station) WatchTides(req *harborv1.WatchTidesRequest, out harborv1.Tides_WatchTidesServer) error {
	rs, err := s.readings(out.Context(), req.GetStation())
	if err != nil {
		return status.Error(codes.Internal, "tide store unavailable")
	}
	for _, r := range rs {
		if err := out.Send(r); err != nil {
			return err
		}
	}
	return nil
}
