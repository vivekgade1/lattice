package kiln

import (
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// The ways a studio rpc says no.

var errNoTicket = status.Error(codes.Unauthenticated, "sign in first")

func refuse(c codes.Code, why string) error {
	return status.New(c, why).Err()
}

func missing(kind string, key any) error {
	return status.Errorf(codes.NotFound, "no %s %v", kind, key)
}

func malformed(format string, args ...any) error {
	return status.Error(codes.InvalidArgument, fmt.Sprintf(format, args...))
}

func ledgerFault(err error) error {
	return status.Errorf(codes.Internal, "ledger: %v", err)
}
