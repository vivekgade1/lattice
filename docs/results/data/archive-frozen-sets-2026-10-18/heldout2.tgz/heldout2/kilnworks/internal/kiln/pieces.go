package kiln

import (
	"context"
	"errors"
	"fmt"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/emptypb"
	"gorm.io/gorm"

	"kilnworks.example/kiln/internal/wire/kilnv1"
)

// pieceBench serves Pieces. It embeds the Unsafe marker, so every rpc is written here.
type pieceBench struct {
	kilnv1.UnsafePiecesServer
	db *gorm.DB
}

func newPieceBench(db *gorm.DB) *pieceBench { return &pieceBench{db: db} }

func pieceMsg(p pieceRow) *kilnv1.Piece {
	return &kilnv1.Piece{Id: p.ID, ProjectId: p.ProjectID, Form: kilnv1.Form(p.Form), State: p.State, Firings: p.Firings}
}

// mine loads a piece through its project's owner; another potter's piece is NOT_FOUND.
func (b *pieceBench) mine(tx *gorm.DB, pieceID, me int64) (pieceRow, error) {
	var p pieceRow
	err := tx.Joins("JOIN projects ON projects.id = pieces.project_id").
		Where("pieces.id = ? AND projects.owner_id = ?", pieceID, me).
		Take(&p).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return p, missing("piece", pieceID)
	}
	if err != nil {
		return p, ledgerFault(err)
	}
	return p, nil
}

func (b *pieceBench) AddPiece(ctx context.Context, in *kilnv1.AddPieceRequest) (*kilnv1.Piece, error) {
	if in.GetForm() == kilnv1.Form_FORM_UNSPECIFIED {
		return nil, malformed("form is required")
	}
	if _, known := kilnv1.Form_name[int32(in.GetForm())]; !known {
		return nil, malformed("unknown form %d", in.GetForm())
	}
	tx := b.db.WithContext(ctx)
	var proj projectRow
	err := tx.Where("id = ? AND owner_id = ?", in.GetProjectId(), callerOf(ctx).id).Take(&proj).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, missing("project", in.GetProjectId())
	} else if err != nil {
		return nil, ledgerFault(err)
	}
	if proj.State != "open" {
		return nil, refuse(codes.FailedPrecondition, "project is archived")
	}
	p := pieceRow{ProjectID: proj.ID, Form: int32(in.GetForm()), State: "greenware"}
	if err := tx.Create(&p).Error; err != nil {
		return nil, ledgerFault(err)
	}
	return pieceMsg(p), nil
}

func (b *pieceBench) GetPiece(ctx context.Context, in *kilnv1.PieceRef) (*kilnv1.Piece, error) {
	p, err := b.mine(b.db.WithContext(ctx), in.GetPieceId(), callerOf(ctx).id)
	if err != nil {
		return nil, err
	}
	return pieceMsg(p), nil
}

var nextFiring = map[string]string{"greenware": "bisque", "glazed": "finished"}

func (b *pieceBench) FirePiece(ctx context.Context, in *kilnv1.FirePieceRequest) (*kilnv1.Piece, error) {
	me := callerOf(ctx)
	tx := b.db.WithContext(ctx)
	p, err := b.mine(tx, in.GetPieceId(), me.id)
	if err != nil {
		return nil, err
	}
	if in.GetRush() && me.role != "lead" {
		return nil, status.Error(codes.PermissionDenied, "only a lead may rush a firing")
	}
	to, ok := nextFiring[p.State]
	if !ok {
		return nil, refuse(codes.FailedPrecondition, fmt.Sprintf("a %s piece cannot be fired", p.State))
	}
	p.State, p.Firings = to, p.Firings+1
	if err := tx.Model(&pieceRow{}).Where("id = ?", p.ID).
		Updates(map[string]any{"state": p.State, "firings": p.Firings}).Error; err != nil {
		return nil, ledgerFault(err)
	}
	return pieceMsg(p), nil
}

func (b *pieceBench) ApplyGlaze(ctx context.Context, in *kilnv1.ApplyGlazeRequest) (*kilnv1.Glazing, error) {
	if in.GetPieceId() <= 0 {
		return nil, malformed("piece_id is required")
	}
	if in.GetGlazeCode() == "" {
		return nil, malformed("glaze_code is required")
	}
	coats := in.GetCoats()
	if coats == 0 {
		coats = 1
	}
	if coats < 0 || coats > 3 {
		return nil, malformed("coats must be 1-3, got %d", coats)
	}
	tx := b.db.WithContext(ctx)
	var p pieceRow
	if err := tx.Take(&p, in.GetPieceId()).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, missing("piece", in.GetPieceId())
		}
		return nil, ledgerFault(err)
	}
	var proj projectRow
	if err := tx.Take(&proj, p.ProjectID).Error; err != nil {
		return nil, ledgerFault(err)
	}
	if proj.OwnerID != callerOf(ctx).id {
		return nil, refuse(codes.PermissionDenied, "that piece belongs to another potter")
	}
	g, err := glazeByCode(tx, in.GetGlazeCode())
	if err != nil {
		return nil, err
	}
	if p.State != "bisque" {
		return nil, status.Errorf(codes.FailedPrecondition, "glaze goes on bisque, not %s", p.State)
	}
	gl := glazingRow{PieceID: p.ID, GlazeID: g.ID, Coats: coats}
	err = tx.Transaction(func(t *gorm.DB) error {
		if err := t.Create(&gl).Error; err != nil {
			return err
		}
		return t.Model(&pieceRow{}).Where("id = ?", p.ID).Update("state", "glazed").Error
	})
	if err != nil {
		return nil, ledgerFault(err)
	}
	return &kilnv1.Glazing{Id: gl.ID, PieceId: p.ID, GlazeCode: g.Code, Coats: coats}, nil
}

func (b *pieceBench) RemovePiece(ctx context.Context, in *kilnv1.PieceRef) (*emptypb.Empty, error) {
	tx := b.db.WithContext(ctx)
	p, err := b.mine(tx, in.GetPieceId(), callerOf(ctx).id)
	if err != nil {
		return nil, err
	}
	if p.State == "finished" {
		return nil, refuse(codes.FailedPrecondition, "finished pieces stay on the record")
	}
	err = tx.Transaction(func(t *gorm.DB) error {
		if err := t.Where("piece_id = ?", p.ID).Delete(&glazingRow{}).Error; err != nil {
			return err
		}
		return t.Delete(&pieceRow{}, p.ID).Error
	})
	if err != nil {
		return nil, ledgerFault(err)
	}
	return &emptypb.Empty{}, nil
}

func (b *pieceBench) TailKiln(in *kilnv1.PieceRef, out grpc.ServerStreamingServer[kilnv1.KilnLine]) error {
	ctx := out.Context()
	p, err := b.mine(b.db.WithContext(ctx), in.GetPieceId(), callerOf(ctx).id)
	if err != nil {
		return err
	}
	for i := int32(1); i <= p.Firings; i++ {
		if err := out.Send(&kilnv1.KilnLine{Text: fmt.Sprintf("piece %d firing %d done", p.ID, i)}); err != nil {
			return err
		}
	}
	return nil
}
