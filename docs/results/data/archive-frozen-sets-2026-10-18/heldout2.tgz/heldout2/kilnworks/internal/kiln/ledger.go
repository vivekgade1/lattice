package kiln

import (
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"github.com/glebarez/sqlite"
)

// The rows the studio keeps. The schema itself is created by whoever provisions the
// database file; the server only reads and writes it.

type potter struct {
	ID         int64
	Handle     string
	Passphrase string
	Role       string // "lead" | "potter"
}

func (potter) TableName() string { return "users" }

type session struct {
	Token  string `gorm:"primaryKey"`
	UserID int64
}

func (session) TableName() string { return "sessions" }

type studioRow struct {
	ID   int64
	Slug string
	Name string
	Open bool
}

func (studioRow) TableName() string { return "studios" }

type glazeRow struct {
	ID   int64
	Code string
	Name string
	Cone int32
}

func (glazeRow) TableName() string { return "glazes" }

type projectRow struct {
	ID       int64
	OwnerID  int64
	StudioID int64
	Title    string
	State    string // "open" -> "archived"
}

func (projectRow) TableName() string { return "projects" }

type pieceRow struct {
	ID        int64
	ProjectID int64
	Form      int32
	State     string // greenware -> bisque -> glazed -> finished
	Firings   int32
}

func (pieceRow) TableName() string { return "pieces" }

type glazingRow struct {
	ID      int64
	PieceID int64
	GlazeID int64
	Coats   int32
}

func (glazingRow) TableName() string { return "glazings" }

// openLedger opens the SQLite file at path (pure Go driver, no cgo).
func openLedger(path string) (*gorm.DB, error) {
	db, err := gorm.Open(sqlite.Open(path+"?_pragma=busy_timeout(5000)&_pragma=foreign_keys(1)"),
		&gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		return nil, err
	}
	raw, err := db.DB()
	if err != nil {
		return nil, err
	}
	raw.SetMaxOpenConns(1)
	return db, nil
}
