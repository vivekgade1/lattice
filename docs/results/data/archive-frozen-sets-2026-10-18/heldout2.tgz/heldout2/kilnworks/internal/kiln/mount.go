package kiln

import (
	"context"
	"net"
	"os"
	"os/signal"
	"syscall"

	"google.golang.org/grpc"
	"google.golang.org/grpc/health"
	healthpb "google.golang.org/grpc/health/grpc_health_v1"
	"gorm.io/gorm"

	"kilnworks.example/kiln/internal/wire/kilnv1"
)

// A mount attaches one slice of the studio to the server.
type mount func(grpc.ServiceRegistrar, *gorm.DB)

var mounts = []mount{
	func(r grpc.ServiceRegistrar, db *gorm.DB) { kilnv1.RegisterPassportServer(r, newPassportDesk(db)) },
	mountWorkshop,
}

func mountWorkshop(r grpc.ServiceRegistrar, db *gorm.DB) {
	kilnv1.RegisterProjectsServer(r, &projectDesk{db: db})
	kilnv1.RegisterPiecesServer(r, newPieceBench(db))
}

// Assemble builds the server over the ledger at dbPath. Billing is declared in the
// contract but deliberately not mounted.
func Assemble(dbPath string) (*grpc.Server, error) {
	db, err := openLedger(dbPath)
	if err != nil {
		return nil, err
	}
	g := gate{db: db}
	srv := grpc.NewServer(
		grpc.ChainUnaryInterceptor(steady, g.unary),
		grpc.StreamInterceptor(g.stream),
	)
	for _, m := range mounts {
		m(srv, db)
	}
	srv.RegisterService(&kilnv1.Catalog_ServiceDesc, catalogShelf{db: db})
	healthpb.RegisterHealthServer(srv, health.NewServer())
	return srv, nil
}

// Serve listens on 127.0.0.1:port until SIGTERM/SIGINT or ctx ends.
func Serve(ctx context.Context, dbPath, port string) error {
	srv, err := Assemble(dbPath)
	if err != nil {
		return err
	}
	lis, err := net.Listen("tcp", net.JoinHostPort("127.0.0.1", port))
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(ctx, os.Interrupt, syscall.SIGTERM)
	defer stop()
	go func() {
		<-ctx.Done()
		srv.GracefulStop()
	}()
	return srv.Serve(lis)
}
