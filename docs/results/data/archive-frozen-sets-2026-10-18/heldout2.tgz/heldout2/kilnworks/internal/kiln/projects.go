package kiln

import (
	"context"
	"errors"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/emptypb"
	"gorm.io/gorm"

	"kilnworks.example/kiln/internal/wire/kilnv1"
)

const openProjectCap = 3

type projectDesk struct {
	kilnv1.UnimplementedProjectsServer // TransferProject is not built yet
	db                                 *gorm.DB
}

func (d *projectDesk) present(tx *gorm.DB, p projectRow) (*kilnv1.Project, error) {
	var st studioRow
	if err := tx.Take(&st, p.StudioID).Error; err != nil {
		return nil, ledgerFault(err)
	}
	return &kilnv1.Project{Id: p.ID, OwnerId: p.OwnerID, StudioSlug: st.Slug, Title: p.Title, State: p.State}, nil
}

// owned loads a project only when the caller owns it; anyone else's project does not exist.
func (d *projectDesk) owned(tx *gorm.DB, id, me int64) (projectRow, error) {
	var p projectRow
	err := tx.Where("id = ? AND owner_id = ?", id, me).Take(&p).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return p, missing("project", id)
	}
	if err != nil {
		return p, ledgerFault(err)
	}
	return p, nil
}

func (d *projectDesk) OpenProject(ctx context.Context, in *kilnv1.OpenProjectRequest) (*kilnv1.Project, error) {
	me := callerOf(ctx)
	if in.GetStudioSlug() == "" {
		return nil, malformed("studio_slug is required")
	}
	if n := len(in.GetTitle()); n == 0 || n > 80 {
		return nil, malformed("title must be 1-80 characters, got %d", n)
	}
	tx := d.db.WithContext(ctx)
	var st studioRow
	err := tx.Where("slug = ?", in.GetStudioSlug()).Take(&st).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, missing("studio", in.GetStudioSlug())
	} else if err != nil {
		return nil, ledgerFault(err)
	}
	if !st.Open {
		return nil, status.Errorf(codes.FailedPrecondition, "studio %s is closed", st.Slug)
	}
	var live int64
	if err := tx.Model(&projectRow{}).Where("owner_id = ? AND state = ?", me.id, "open").Count(&live).Error; err != nil {
		return nil, ledgerFault(err)
	}
	if live >= openProjectCap {
		return nil, refuse(codes.ResourceExhausted, "too many open projects")
	}
	p := projectRow{OwnerID: me.id, StudioID: st.ID, Title: in.GetTitle(), State: "open"}
	if err := tx.Create(&p).Error; err != nil {
		return nil, ledgerFault(err)
	}
	return d.present(tx, p)
}

func (d *projectDesk) GetProject(ctx context.Context, in *kilnv1.GetProjectRequest) (*kilnv1.Project, error) {
	tx := d.db.WithContext(ctx)
	p, err := d.owned(tx, in.GetId(), callerOf(ctx).id)
	if err != nil {
		return nil, err
	}
	return d.present(tx, p)
}

func (d *projectDesk) ListProjects(ctx context.Context, _ *emptypb.Empty) (*kilnv1.ProjectList, error) {
	tx := d.db.WithContext(ctx)
	var rows []projectRow
	if err := tx.Where("owner_id = ?", callerOf(ctx).id).Order("id").Find(&rows).Error; err != nil {
		return nil, ledgerFault(err)
	}
	out := &kilnv1.ProjectList{}
	for _, r := range rows {
		m, err := d.present(tx, r)
		if err != nil {
			return nil, err
		}
		out.Projects = append(out.Projects, m)
	}
	return out, nil
}

func (d *projectDesk) ArchiveProject(ctx context.Context, in *kilnv1.ArchiveProjectRequest) (*kilnv1.Project, error) {
	tx := d.db.WithContext(ctx)
	p, err := d.owned(tx, in.GetProjectId(), callerOf(ctx).id)
	if err != nil {
		return nil, err
	}
	if p.State == "archived" {
		return nil, refuse(codes.FailedPrecondition, "project is already archived")
	}
	p.State = "archived"
	if err := tx.Model(&projectRow{}).Where("id = ?", p.ID).Update("state", p.State).Error; err != nil {
		return nil, ledgerFault(err)
	}
	return d.present(tx, p)
}
