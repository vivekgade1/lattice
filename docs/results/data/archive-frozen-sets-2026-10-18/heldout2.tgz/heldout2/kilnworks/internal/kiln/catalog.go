package kiln

import (
	"context"
	"errors"
	"fmt"

	"google.golang.org/protobuf/types/known/emptypb"
	"gorm.io/gorm"

	"kilnworks.example/kiln/internal/wire/kilnv1"
)

// catalogShelf serves the seeded reference rows. Value receiver: it holds only the handle.
type catalogShelf struct {
	kilnv1.UnimplementedCatalogServer
	db *gorm.DB
}

func (s catalogShelf) ListStudios(ctx context.Context, _ *emptypb.Empty) (*kilnv1.StudioList, error) {
	var rows []studioRow
	if err := s.db.WithContext(ctx).Order("id").Find(&rows).Error; err != nil {
		return nil, ledgerFault(err)
	}
	out := &kilnv1.StudioList{}
	for _, r := range rows {
		out.Studios = append(out.Studios, &kilnv1.Studio{Id: r.ID, Slug: r.Slug, Name: r.Name, Open: r.Open})
	}
	return out, nil
}

func (s catalogShelf) ListGlazes(ctx context.Context, _ *emptypb.Empty) (*kilnv1.GlazeShelf, error) {
	var rows []glazeRow
	if err := s.db.WithContext(ctx).Order("id").Find(&rows).Error; err != nil {
		return nil, fmt.Errorf("glaze shelf: %w", err)
	}
	out := &kilnv1.GlazeShelf{}
	for _, r := range rows {
		out.Glazes = append(out.Glazes, glazeMsg(r))
	}
	return out, nil
}

func (s catalogShelf) LookupGlaze(ctx context.Context, in *kilnv1.LookupGlazeRequest) (*kilnv1.Glaze, error) {
	if in.GetGlazeCode() == "" {
		return nil, malformed("glaze_code is required")
	}
	g, err := glazeByCode(s.db.WithContext(ctx), in.GetGlazeCode())
	if err != nil {
		return nil, err
	}
	return glazeMsg(g), nil
}

func glazeMsg(r glazeRow) *kilnv1.Glaze {
	return &kilnv1.Glaze{Id: r.ID, Code: r.Code, Name: r.Name, Cone: r.Cone}
}

// glazeByCode finds a glaze by its shelf code.
func glazeByCode(db *gorm.DB, code string) (glazeRow, error) {
	var g glazeRow
	err := db.Where("code = ?", code).Take(&g).Error
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		return g, missing("glaze", code)
	case err != nil:
		return g, ledgerFault(err)
	}
	return g, nil
}
