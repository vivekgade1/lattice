package kiln

import (
	"context"
	"errors"
	"strings"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	healthpb "google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"gorm.io/gorm"

	"kilnworks.example/kiln/internal/wire/kilnv1"
)

// openDoors are the rpcs anyone may call without a session.
var openDoors = map[string]bool{
	kilnv1.Passport_SignIn_FullMethodName:    true,
	kilnv1.Catalog_ListGlazes_FullMethodName: true,
	healthpb.Health_Check_FullMethodName:     true,
	healthpb.Health_Watch_FullMethodName:     true,
}

type caller struct {
	id     int64
	handle string
	role   string
	token  string
}

type callerKey struct{}

func callerOf(ctx context.Context) caller {
	c, _ := ctx.Value(callerKey{}).(caller)
	return c
}

// gate resolves the bearer token in the "authorization" metadata to a caller.
type gate struct{ db *gorm.DB }

func (g gate) resolve(ctx context.Context) (context.Context, error) {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return nil, errNoTicket
	}
	vals := md.Get("authorization")
	if len(vals) == 0 {
		return nil, errNoTicket
	}
	tok, found := strings.CutPrefix(vals[0], "Bearer ")
	if !found || tok == "" {
		return nil, errNoTicket
	}
	var s session
	if err := g.db.Where("token = ?", tok).Take(&s).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, errNoTicket
		}
		return nil, ledgerFault(err)
	}
	var p potter
	if err := g.db.Take(&p, s.UserID).Error; err != nil {
		return nil, errNoTicket
	}
	return context.WithValue(ctx, callerKey{}, caller{id: p.ID, handle: p.Handle, role: p.Role, token: tok}), nil
}

func (g gate) unary(ctx context.Context, req any, info *grpc.UnaryServerInfo, next grpc.UnaryHandler) (any, error) {
	if openDoors[info.FullMethod] {
		return next(ctx, req)
	}
	ctx, err := g.resolve(ctx)
	if err != nil {
		return nil, err
	}
	return next(ctx, req)
}

type admittedStream struct {
	grpc.ServerStream
	ctx context.Context
}

func (a admittedStream) Context() context.Context { return a.ctx }

func (g gate) stream(srv any, ss grpc.ServerStream, info *grpc.StreamServerInfo, next grpc.StreamHandler) error {
	if openDoors[info.FullMethod] {
		return next(srv, ss)
	}
	ctx, err := g.resolve(ss.Context())
	if err != nil {
		return err
	}
	return next(srv, admittedStream{ServerStream: ss, ctx: ctx})
}

// steady turns a handler panic into INTERNAL instead of killing the server.
func steady(ctx context.Context, req any, _ *grpc.UnaryServerInfo, next grpc.UnaryHandler) (resp any, err error) {
	defer func() {
		if r := recover(); r != nil {
			resp, err = nil, status.Errorf(codes.Internal, "panic: %v", r)
		}
	}()
	return next(ctx, req)
}
