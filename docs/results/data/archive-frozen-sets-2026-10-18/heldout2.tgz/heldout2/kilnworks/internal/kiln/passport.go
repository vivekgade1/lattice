package kiln

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"

	"google.golang.org/grpc/codes"
	"google.golang.org/protobuf/types/known/emptypb"
	"gorm.io/gorm"

	"kilnworks.example/kiln/internal/wire/kilnv1"
)

type passportDesk struct {
	kilnv1.UnsafePassportServer
	db *gorm.DB
}

func newPassportDesk(db *gorm.DB) *passportDesk { return &passportDesk{db: db} }

func roleOf(s string) kilnv1.Role {
	if s == "lead" {
		return kilnv1.Role_ROLE_LEAD
	}
	return kilnv1.Role_ROLE_POTTER
}

func (d *passportDesk) SignIn(ctx context.Context, in *kilnv1.SignInRequest) (*kilnv1.SessionTicket, error) {
	if in.GetHandle() == "" || in.GetPassphrase() == "" {
		return nil, malformed("handle and passphrase are required")
	}
	var p potter
	err := d.db.WithContext(ctx).Where("handle = ?", in.GetHandle()).Take(&p).Error
	if errors.Is(err, gorm.ErrRecordNotFound) || (err == nil && p.Passphrase != in.GetPassphrase()) {
		return nil, refuse(codes.Unauthenticated, "unknown handle or passphrase")
	}
	if err != nil {
		return nil, ledgerFault(err)
	}
	buf := make([]byte, 16)
	if _, err := rand.Read(buf); err != nil {
		return nil, ledgerFault(err)
	}
	tok := hex.EncodeToString(buf)
	if err := d.db.WithContext(ctx).Create(&session{Token: tok, UserID: p.ID}).Error; err != nil {
		return nil, ledgerFault(err)
	}
	return &kilnv1.SessionTicket{Token: tok, UserId: p.ID, Role: roleOf(p.Role)}, nil
}

func (d *passportDesk) WhoAmI(ctx context.Context, _ *emptypb.Empty) (*kilnv1.Badge, error) {
	c := callerOf(ctx)
	return &kilnv1.Badge{UserId: c.id, Handle: c.handle, Role: roleOf(c.role)}, nil
}

// SignOff revokes the session that made the call; the token stops working at once.
func (d *passportDesk) SignOff(ctx context.Context, _ *emptypb.Empty) (*kilnv1.SignOffReceipt, error) {
	c := callerOf(ctx)
	res := d.db.WithContext(ctx).Where("token = ?", c.token).Delete(&session{})
	if res.Error != nil {
		return nil, ledgerFault(res.Error)
	}
	return &kilnv1.SignOffReceipt{SessionsEnded: int32(res.RowsAffected)}, nil
}

// StepDown demotes a lead to potter. A potter has nothing to step down from.
func (d *passportDesk) StepDown(ctx context.Context, _ *emptypb.Empty) (*kilnv1.Badge, error) {
	c := callerOf(ctx)
	if c.role != "lead" {
		return nil, refuse(codes.FailedPrecondition, "only a lead can step down")
	}
	if err := d.db.WithContext(ctx).Model(&potter{}).Where("id = ?", c.id).Update("role", "potter").Error; err != nil {
		return nil, ledgerFault(err)
	}
	return &kilnv1.Badge{UserId: c.id, Handle: c.handle, Role: kilnv1.Role_ROLE_POTTER}, nil
}
