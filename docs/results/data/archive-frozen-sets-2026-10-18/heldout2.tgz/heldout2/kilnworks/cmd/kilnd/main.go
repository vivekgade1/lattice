// kilnd: the studio ledger over gRPC.
//
//	KILN_DB=/path/to/kiln.db KILN_LISTEN_PORT=50051 kilnd
package main

import (
	"context"
	"fmt"
	"os"

	"kilnworks.example/kiln/internal/kiln"
)

func main() {
	db, port := os.Getenv("KILN_DB"), os.Getenv("KILN_LISTEN_PORT")
	if db == "" || port == "" {
		fmt.Fprintln(os.Stderr, "kilnd: KILN_DB and KILN_LISTEN_PORT must be set")
		os.Exit(2)
	}
	if err := kiln.Serve(context.Background(), db, port); err != nil {
		fmt.Fprintln(os.Stderr, "kilnd:", err)
		os.Exit(1)
	}
}
