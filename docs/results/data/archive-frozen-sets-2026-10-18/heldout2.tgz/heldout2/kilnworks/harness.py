"""Harness for kilnworks (held-out grpc-go app over pure-Go SQLite).

The server is ``cmd/kilnd``: it reads ``KILN_DB`` (the SQLite file) and ``KILN_LISTEN_PORT``
(loopback port), serves gRPC only, and answers ``grpc.health.v1.Health/Check`` SERVING once
it is up. Callers log in with ``kiln.v1.Passport/SignIn {handle, passphrase}`` and present
the answered ``token`` as metadata ``authorization: Bearer <token>``.

Nothing is written under this directory: the binary is built (once per source hash) into
``$KILNWORKS_BIN_DIR`` (default: ``<tempdir>/kilnworks-bin``), or taken from ``$KILNWORKS_BIN``.

Exports: ``make_app``, ``build_db``, ``RUNTIME``, ``USERS``, ``PROTOS``, ``PROTO_PATHS``,
``RPC_LOGIN``, ``ROOT``.
"""

from __future__ import annotations

import dataclasses
import hashlib
import inspect
import os
import sqlite3
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# handle -> (login handle, passphrase). The first user is the lead.
USERS = {
    "ada": ("ada", "kiln-ada-7"),
    "bo": ("bo", "kiln-bo-3"),
    "cy": ("cy", "kiln-cy-5"),
}
ROLES = {"ada": "lead", "bo": "potter", "cy": "potter"}

# Project-relative .proto files and include roots.
PROTOS = (
    "proto/kiln/v1/billing.proto",
    "proto/kiln/v1/catalog.proto",
    "proto/kiln/v1/passport.proto",
    "proto/kiln/v1/workshop.proto",
)
PROTO_PATHS = ("proto",)

# How a caller logs in over gRPC.
RPC_LOGIN = {
    "service": "kiln.v1.Passport",
    "method": "SignIn",
    "username_field": "handle",
    "password_field": "passphrase",
    "token_field": "token",
    "metadata_key": "authorization",
    "scheme": "Bearer",
}

PORT_ENV = "KILN_LISTEN_PORT"
DB_ENV = "KILN_DB"

DDL = """
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    handle TEXT NOT NULL UNIQUE,
    passphrase TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('lead', 'potter'))
);
CREATE TABLE sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id)
);
CREATE TABLE studios (
    id INTEGER PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    open BOOLEAN NOT NULL
);
CREATE TABLE glazes (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    cone INTEGER NOT NULL
);
CREATE TABLE projects (
    id INTEGER PRIMARY KEY,
    owner_id INTEGER NOT NULL REFERENCES users(id),
    studio_id INTEGER NOT NULL REFERENCES studios(id),
    title TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('open', 'archived'))
);
CREATE TABLE pieces (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id),
    form INTEGER NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('greenware', 'bisque', 'glazed', 'finished')),
    firings INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE glazings (
    id INTEGER PRIMARY KEY,
    piece_id INTEGER NOT NULL REFERENCES pieces(id),
    glaze_id INTEGER NOT NULL REFERENCES glazes(id),
    coats INTEGER NOT NULL
);
"""

# Seed rows. Ids are deliberately not in natural-key order: the smallest studio slug is
# 'east-wing' (id 2, open); 'north-loft' (id 1) is closed. The smallest glaze code is
# 'SIX-ASH' (id 3). bo owns project 1 with pieces 1 (greenware) and 2 (bisque), so the
# first project, piece and glazing created on a fresh database get ids 2, 3 and 1.
SEED = [
    ("INSERT INTO studios VALUES (?, ?, ?, ?)", (1, "north-loft", "North Loft", 0)),
    ("INSERT INTO studios VALUES (?, ?, ?, ?)", (2, "east-wing", "East Wing", 1)),
    ("INSERT INTO studios VALUES (?, ?, ?, ?)", (3, "west-yard", "West Yard", 1)),
    ("INSERT INTO glazes VALUES (?, ?, ?, ?)", (1, "TEN-CEL", "Celadon", 10)),
    ("INSERT INTO glazes VALUES (?, ?, ?, ?)", (2, "SIX-SHI", "Shino", 6)),
    ("INSERT INTO glazes VALUES (?, ?, ?, ?)", (3, "SIX-ASH", "Wood ash", 6)),
    ("INSERT INTO projects VALUES (?, ?, ?, ?, ?)", (1, 2, 3, "Teabowls", "open")),
    ("INSERT INTO pieces VALUES (?, ?, ?, ?, ?)", (1, 1, 2, "greenware", 0)),
    ("INSERT INTO pieces VALUES (?, ?, ?, ?, ?)", (2, 1, 1, "bisque", 1)),
]


def build_db(path: Path) -> Path:
    """A fresh kilnworks database at ``path`` (schema + seed)."""
    path = Path(path)
    conn = sqlite3.connect(path)
    try:
        conn.executescript(DDL)
        for i, (handle, (login, pw)) in enumerate(USERS.items(), 1):
            conn.execute("INSERT INTO users VALUES (?, ?, ?, ?)", (i, login, pw, ROLES[handle]))
        for sql, args in SEED:
            conn.execute(sql, args)
        conn.commit()
    finally:
        conn.close()
    return path


def _source_hash() -> str:
    h = hashlib.sha256()
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and (p.suffix in {".go", ".proto"} or p.name in {"go.mod", "go.sum"}):
            h.update(p.relative_to(ROOT).as_posix().encode())
            h.update(b"\0")
            h.update(p.read_bytes())
    return h.hexdigest()[:16]


def binary() -> Path:
    """The built ``kilnd`` (``$KILNWORKS_BIN`` if set; else built once into a cache dir)."""
    if os.environ.get("KILNWORKS_BIN"):
        return Path(os.environ["KILNWORKS_BIN"])
    out_dir = Path(
        os.environ.get("KILNWORKS_BIN_DIR") or Path(tempfile.gettempdir()) / "kilnworks-bin"
    )
    out = out_dir / f"kilnd-{_source_hash()}"
    if not out.exists():
        out_dir.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(".tmp")
        env = {**os.environ, "CGO_ENABLED": "0"}
        go = os.environ.get("GO", "go")
        subprocess.run(
            [
                go,
                "build",
                "-trimpath",
                "-buildvcs=false",
                "-mod=readonly",
                "-o",
                str(tmp),
                "./cmd/kilnd",
            ],
            cwd=ROOT,
            env=env,
            check=True,
        )
        tmp.replace(out)
    return out


def make_app(db_path: Path):
    """The kilnd process on ``db_path`` (not started), ready when gRPC health is SERVING."""
    from lattice.spec.process import ProcessApp

    names = {f.name for f in dataclasses.fields(ProcessApp)}
    if "ready" not in names:
        raise RuntimeError("this lattice has no gRPC process support (ProcessApp.ready)")
    kwargs = {
        "db_path": db_path,
        "port_env": PORT_ENV,
        "db_env": DB_ENV,
        "ready": "grpc",
        "protos": PROTOS,
        "proto_paths": PROTO_PATHS,
        "proto_root": str(ROOT),
    }
    return ProcessApp([str(binary())], **{k: v for k, v in kwargs.items() if k in names})


def _runtime():
    from lattice.importer.transport import AuthDriver
    from lattice.spec.process import process_runtime

    rpc = getattr(AuthDriver, "rpc", None)
    if rpc is None:
        return None
    params = inspect.signature(rpc).parameters
    kwargs = {
        k: RPC_LOGIN[k] for k in ("username_field", "password_field", "token_field") if k in params
    }
    auth = rpc(RPC_LOGIN["service"], RPC_LOGIN["method"], USERS, **kwargs)
    return process_runtime(framework="go", auth=auth)


try:
    RUNTIME = _runtime()
except ImportError:  # imported without lattice on the path
    RUNTIME = None
