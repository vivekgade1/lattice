namespace Outlay.Domain;

/// <summary>One receipt on a report. Belongs to a user only through its report.</summary>
public class ExpenseLine
{
    public int Id { get; set; }
    public int ReportId { get; set; }
    public ExpenseReport? Report { get; set; }

    public string Description { get; set; } = "";
    public ExpenseCategory Category { get; set; }
    public long AmountCents { get; set; }
    public DateOnly IncurredOn { get; set; }
    public DateTime CreatedAt { get; set; }
}
