using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Outlay.Features.Auth;

public sealed class LoginRequest
{
    [Required, StringLength(254, MinimumLength = 3)]
    public string? Email { get; init; }

    [Required, StringLength(200, MinimumLength = 1)]
    public string? Password { get; init; }
}

public sealed record LoginResponse(
    [property: JsonPropertyName("access_token")] string AccessToken,
    [property: JsonPropertyName("token_type")] string TokenType,
    [property: JsonPropertyName("expires_in")] long ExpiresIn,
    [property: JsonPropertyName("user")] CurrentUserResponse User);

public sealed record CurrentUserResponse(int Id, string Email, string DisplayName, string Role);
