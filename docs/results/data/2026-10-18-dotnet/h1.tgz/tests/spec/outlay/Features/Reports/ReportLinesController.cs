using Microsoft.AspNetCore.Mvc;
using Outlay.Auth;

namespace Outlay.Features.Reports;

/// <summary>Lines of one of the caller's reports; a line is reached only through its report.</summary>
[ApiController]
[Route("reports/{reportId:int}/lines")]
public sealed class ReportLinesController(ReportService reports) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<LineResponse>>> List(int reportId, CancellationToken ct) =>
        Ok(await reports.ListLines(User.UserId(), reportId, ct));

    [HttpPost]
    public async Task<ActionResult<LineResponse>> Add(int reportId, CreateLineRequest request, CancellationToken ct)
    {
        var line = await reports.AddLine(User.UserId(), reportId, request, ct);
        return StatusCode(StatusCodes.Status201Created, line);
    }

    [HttpDelete("{lineId:int}")]
    public async Task<IActionResult> Delete(int reportId, int lineId, CancellationToken ct)
    {
        await reports.DeleteLine(User.UserId(), reportId, lineId, ct);
        return NoContent();
    }
}
