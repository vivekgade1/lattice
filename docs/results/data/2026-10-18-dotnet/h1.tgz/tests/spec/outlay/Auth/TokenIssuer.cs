using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.WebUtilities;

namespace Outlay.Auth;

public sealed class TokenOptions
{
    /// <summary>HMAC key. Empty: a random key per process (tokens do not survive a restart).</summary>
    public string SigningKey { get; set; } = "";
    public TimeSpan Lifetime { get; set; } = TimeSpan.FromHours(8);
}

/// <summary>Opaque bearer tokens: base64url("v1.{userId}.{expiresUnix}") + "." + base64url(HMAC-SHA256).</summary>
public sealed class TokenIssuer
{
    private readonly byte[] _key;
    private readonly TimeProvider _clock;

    public TokenIssuer(TokenOptions options, TimeProvider clock)
    {
        _key = string.IsNullOrEmpty(options.SigningKey)
            ? RandomNumberGenerator.GetBytes(32)
            : Encoding.UTF8.GetBytes(options.SigningKey);
        _clock = clock;
        Lifetime = options.Lifetime;
    }

    public TimeSpan Lifetime { get; }

    public string Issue(int userId)
    {
        var expires = _clock.GetUtcNow().Add(Lifetime).ToUnixTimeSeconds();
        var payload = Encoding.UTF8.GetBytes($"v1.{userId}.{expires}");
        return WebEncoders.Base64UrlEncode(payload) + "." + WebEncoders.Base64UrlEncode(Sign(payload));
    }

    /// <summary>The user id of a valid, unexpired token; null otherwise.</summary>
    public int? Validate(string token)
    {
        var dot = token.IndexOf('.');
        if (dot <= 0 || dot == token.Length - 1)
            return null;
        byte[] payload, signature;
        try
        {
            payload = WebEncoders.Base64UrlDecode(token[..dot]);
            signature = WebEncoders.Base64UrlDecode(token[(dot + 1)..]);
        }
        catch (FormatException)
        {
            return null;
        }
        if (!CryptographicOperations.FixedTimeEquals(signature, Sign(payload)))
            return null;

        var parts = Encoding.UTF8.GetString(payload).Split('.');
        if (parts.Length != 3 || parts[0] != "v1"
            || !int.TryParse(parts[1], out var userId) || !long.TryParse(parts[2], out var expires))
            return null;
        return _clock.GetUtcNow().ToUnixTimeSeconds() < expires ? userId : null;
    }

    private byte[] Sign(byte[] payload) => HMACSHA256.HashData(_key, payload);
}
