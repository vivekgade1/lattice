using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Outlay.Auth;
using Outlay.Data;
using Outlay.Errors;

namespace Outlay.Features.Auth;

public sealed class AuthService(OutlayDbContext db, TokenIssuer tokens)
{
    public async Task<LoginResponse> Login(LoginRequest request, CancellationToken ct)
    {
        var email = request.Email!.Trim();
        var user = await db.Users.AsNoTracking().SingleOrDefaultAsync(u => u.Email == email, ct);
        // One answer for an unknown email and a wrong password: the caller learns nothing about which it was.
        if (user is null || !SamePassword(user.Password, request.Password!))
            throw new UnauthorizedException("email or password is incorrect");

        return new LoginResponse(
            tokens.Issue(user.Id),
            "Bearer",
            (long)tokens.Lifetime.TotalSeconds,
            new CurrentUserResponse(user.Id, user.Email, user.DisplayName, user.Role.ToString().ToLowerInvariant()));
    }

    private static bool SamePassword(string stored, string typed) =>
        CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(stored), Encoding.UTF8.GetBytes(typed));
}
