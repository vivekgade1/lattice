using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Outlay.Domain;

namespace Outlay.Data.Configurations;

public class ExpenseReportConfiguration : IEntityTypeConfiguration<ExpenseReport>
{
    public void Configure(EntityTypeBuilder<ExpenseReport> b)
    {
        b.ToTable("expense_reports");
        b.HasKey(r => r.Id);
        b.Property(r => r.Id).HasColumnName("id");
        b.Property(r => r.UserId).HasColumnName("user_id");
        b.HasOne(r => r.User).WithMany().HasForeignKey(r => r.UserId).OnDelete(DeleteBehavior.Cascade);
        b.HasIndex(r => r.UserId).HasDatabaseName("ix_expense_reports_user_id");

        b.Property(r => r.Title).HasColumnName("title").HasMaxLength(120).IsRequired();
        b.Property(r => r.Purpose).HasColumnName("purpose").HasMaxLength(500);
        b.Property(r => r.Status).HasColumnName("status").HasMaxLength(16).IsRequired()
            .HasConversion(EnumStorage.LowercaseText(ReportStatus.Draft));
        b.HasIndex(r => r.Status).HasDatabaseName("ix_expense_reports_status");

        b.Property(r => r.SubmittedAt).HasColumnName("submitted_at");
        b.Property(r => r.ReviewerId).HasColumnName("reviewer_id");
        b.HasOne(r => r.Reviewer).WithMany().HasForeignKey(r => r.ReviewerId).OnDelete(DeleteBehavior.SetNull);
        b.HasIndex(r => r.ReviewerId).HasDatabaseName("ix_expense_reports_reviewer_id");
        b.Property(r => r.ReviewComment).HasColumnName("review_comment").HasMaxLength(500);
        b.Property(r => r.DecidedAt).HasColumnName("decided_at");
        b.Property(r => r.CreatedAt).HasColumnName("created_at");
        b.Property(r => r.UpdatedAt).HasColumnName("updated_at");

        b.HasMany(r => r.Lines).WithOne(l => l.Report).HasForeignKey(l => l.ReportId).OnDelete(DeleteBehavior.Cascade);
    }
}
