using System.ComponentModel.DataAnnotations;
using Outlay.Domain;

namespace Outlay.Features.Reports;

public sealed class CreateReportRequest
{
    [Required, StringLength(120, MinimumLength = 1)]
    public string? Title { get; init; }

    [StringLength(500)]
    public string? Purpose { get; init; }
}

public sealed class UpdateReportRequest : IValidatableObject
{
    [StringLength(120, MinimumLength = 1)]
    public string? Title { get; init; }

    [StringLength(500)]
    public string? Purpose { get; init; }

    public IEnumerable<ValidationResult> Validate(ValidationContext context)
    {
        if (Title is null && Purpose is null)
            yield return new ValidationResult("give at least one of title or purpose", [nameof(Title), nameof(Purpose)]);
    }
}

public sealed class CreateLineRequest : IValidatableObject
{
    [Required, StringLength(200, MinimumLength = 1)]
    public string? Description { get; init; }

    [Required]
    public ExpenseCategory? Category { get; init; }

    /// <summary>Amount in cents; one line is at most 50,000.00.</summary>
    [Required, Range(1, 5_000_000)]
    public long? AmountCents { get; init; }

    [Required]
    public DateOnly? IncurredOn { get; init; }

    public IEnumerable<ValidationResult> Validate(ValidationContext context)
    {
        var today = DateOnly.FromDateTime(TimeProvider.System.GetUtcNow().UtcDateTime);
        if (IncurredOn > today)
            yield return new ValidationResult("incurredOn cannot be in the future", [nameof(IncurredOn)]);
    }
}

public sealed record ReportResponse(
    int Id,
    int UserId,
    string Title,
    string? Purpose,
    ReportStatus Status,
    long TotalCents,
    int LineCount,
    DateTime? SubmittedAt,
    int? ReviewerId,
    string? ReviewComment,
    DateTime? DecidedAt,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public sealed record ReportDetailResponse(ReportResponse Report, IReadOnlyList<LineResponse> Lines);

public sealed record LineResponse(
    int Id,
    int ReportId,
    string Description,
    ExpenseCategory Category,
    long AmountCents,
    DateOnly IncurredOn,
    DateTime CreatedAt);

public static class ReportMapping
{
    public static LineResponse ToResponse(this ExpenseLine l) =>
        new(l.Id, l.ReportId, l.Description, l.Category, l.AmountCents, l.IncurredOn, l.CreatedAt);
}
