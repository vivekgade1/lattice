using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Outlay.Auth;
using Outlay.Domain;
using Outlay.Errors;
using Outlay.Features.Reports;

namespace Outlay.Features.Review;

/// <summary>The review queue; admins only.</summary>
[ApiController]
[Route("review/reports")]
[Authorize(Policy = Policies.Reviewer)]
public sealed class ReviewController(ReviewService review) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<ReportResponse>>> Queue(
        [FromQuery] string? status, CancellationToken ct) =>
        Ok(await review.Queue(ParseStatus(status), ct));

    [HttpPost("{reportId:int}/approve")]
    public async Task<ActionResult<ReportResponse>> Approve(
        int reportId,
        [FromBody(EmptyBodyBehavior = EmptyBodyBehavior.Allow)] ApproveRequest? request,
        CancellationToken ct) =>
        Ok(await review.Approve(User.UserId(), reportId, request?.Comment, ct));

    [HttpPost("{reportId:int}/reject")]
    public async Task<ActionResult<ReportResponse>> Reject(int reportId, RejectRequest request, CancellationToken ct) =>
        Ok(await review.Reject(User.UserId(), reportId, request.Comment!, ct));

    private static ReportStatus ParseStatus(string? status)
    {
        if (string.IsNullOrEmpty(status))
            return ReportStatus.Submitted;
        if (!status.All(char.IsAsciiLetter) || !Enum.TryParse<ReportStatus>(status, ignoreCase: true, out var parsed))
            throw new BadRequestException("status must be one of draft, submitted, approved, rejected");
        return parsed;
    }
}
