using Outlay.Hosting;

var builder = WebApplication.CreateBuilder(args);
var settings = ServiceSettings.FromEnvironment(builder.Configuration);
builder.AddOutlay(settings);

var app = builder.Build();
app.EnsureSchema();

app.UseExceptionHandler();
app.UseStatusCodePages();
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/health", () => Results.Ok(new { status = "ok" })).AllowAnonymous();
app.MapControllers();

app.Run();
