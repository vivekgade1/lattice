namespace Outlay.Errors;

/// <summary>
/// A refusal the API reports to the caller. Thrown from services and controllers, turned into an
/// RFC 9457 problem document by <see cref="ApiExceptionHandler"/>.
/// </summary>
public abstract class ApiException(int status, string title, string detail) : Exception(detail)
{
    public int Status { get; } = status;
    public string Title { get; } = title;
}

public sealed class NotFoundException(string detail)
    : ApiException(StatusCodes.Status404NotFound, "Not Found", detail);

public sealed class ConflictException(string detail)
    : ApiException(StatusCodes.Status409Conflict, "Conflict", detail);

public sealed class ForbiddenException(string detail)
    : ApiException(StatusCodes.Status403Forbidden, "Forbidden", detail);

public sealed class UnauthorizedException(string detail)
    : ApiException(StatusCodes.Status401Unauthorized, "Unauthorized", detail);

public sealed class BadRequestException(string detail)
    : ApiException(StatusCodes.Status400BadRequest, "Bad Request", detail);
