using System.Xml.Linq;
using Microsoft.AspNetCore.DataProtection.Repositories;

namespace Outlay.Auth;

/// <summary>
/// Keeps the data-protection key ring in memory. The default repository persists keys under the home
/// directory; this service must not write there, and it protects nothing that has to outlive the process.
/// </summary>
public sealed class InMemoryXmlRepository : IXmlRepository
{
    private readonly List<XElement> _elements = [];
    private readonly Lock _gate = new();

    public IReadOnlyCollection<XElement> GetAllElements()
    {
        lock (_gate)
            return _elements.Select(e => new XElement(e)).ToList();
    }

    public void StoreElement(XElement element, string friendlyName)
    {
        lock (_gate)
            _elements.Add(new XElement(element));
    }
}
