using Microsoft.EntityFrameworkCore;
using Outlay.Data;
using Outlay.Domain;
using Outlay.Errors;

namespace Outlay.Features.Reports;

/// <summary>An owner's own expense reports and their lines. Every lookup is scoped to the owner.</summary>
public sealed class ReportService(OutlayDbContext db, TimeProvider clock)
{
    public const int MaxLinesPerReport = 50;

    public async Task<IReadOnlyList<ReportResponse>> ListMine(int userId, CancellationToken ct) =>
        await Summaries(db.ExpenseReports
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedAt).ThenByDescending(r => r.Id))
            .ToListAsync(ct);

    public async Task<ReportDetailResponse> GetMine(int userId, int reportId, CancellationToken ct)
    {
        var report = await Summaries(db.ExpenseReports.Where(r => r.Id == reportId && r.UserId == userId))
            .SingleOrDefaultAsync(ct) ?? throw ReportNotFound(reportId);
        var lines = await ListLines(userId, reportId, ct);
        return new ReportDetailResponse(report, lines);
    }

    public async Task<ReportResponse> Create(int userId, CreateReportRequest request, CancellationToken ct)
    {
        var now = Now();
        var report = new ExpenseReport
        {
            UserId = userId,
            Title = request.Title!.Trim(),
            Purpose = request.Purpose?.Trim(),
            Status = ReportStatus.Draft,
            CreatedAt = now,
            UpdatedAt = now,
        };
        db.ExpenseReports.Add(report);
        await db.SaveChangesAsync(ct);
        return await Summary(report.Id, ct);
    }

    public async Task<ReportResponse> Update(int userId, int reportId, UpdateReportRequest request, CancellationToken ct)
    {
        var report = await FindOwned(userId, reportId, ct);
        EnsureEditable(report);
        if (request.Title is not null)
            report.Title = request.Title.Trim();
        if (request.Purpose is not null)
            report.Purpose = request.Purpose.Trim();
        report.UpdatedAt = Now();
        await db.SaveChangesAsync(ct);
        return await Summary(report.Id, ct);
    }

    public async Task Delete(int userId, int reportId, CancellationToken ct)
    {
        var report = await FindOwned(userId, reportId, ct);
        if (report.Status != ReportStatus.Draft)
            throw new ConflictException($"expense report {reportId} is {Wire(report.Status)}; only a draft can be deleted");
        db.ExpenseReports.Remove(report);
        await db.SaveChangesAsync(ct);
    }

    public async Task<ReportResponse> Submit(int userId, int reportId, CancellationToken ct)
    {
        var report = await FindOwned(userId, reportId, ct);
        if (!ReportStatusRules.CanTransition(report.Status, ReportStatus.Submitted))
            throw new ConflictException($"expense report {reportId} is {Wire(report.Status)} and cannot be submitted");
        if (!await db.ExpenseLines.AnyAsync(l => l.ReportId == reportId, ct))
            throw new ConflictException($"expense report {reportId} has no lines; add at least one before submitting");

        // Conditional update: two concurrent submits (or a submit racing a review) cannot both win.
        var now = Now();
        var from = report.Status;
        var changed = await db.ExpenseReports
            .Where(r => r.Id == reportId && r.Status == from)
            .ExecuteUpdateAsync(s => s
                .SetProperty(r => r.Status, ReportStatus.Submitted)
                .SetProperty(r => r.SubmittedAt, now)
                .SetProperty(r => r.ReviewerId, (int?)null)
                .SetProperty(r => r.ReviewComment, (string?)null)
                .SetProperty(r => r.DecidedAt, (DateTime?)null)
                .SetProperty(r => r.UpdatedAt, now), ct);
        if (changed == 0)
            throw new ConflictException($"expense report {reportId} changed while it was being submitted");
        return await Summary(reportId, ct);
    }

    public async Task<IReadOnlyList<LineResponse>> ListLines(int userId, int reportId, CancellationToken ct)
    {
        if (!await db.ExpenseReports.AnyAsync(r => r.Id == reportId && r.UserId == userId, ct))
            throw ReportNotFound(reportId);
        var lines = await db.ExpenseLines.AsNoTracking()
            .Where(l => l.ReportId == reportId)
            .OrderBy(l => l.IncurredOn).ThenBy(l => l.Id)
            .ToListAsync(ct);
        return lines.Select(l => l.ToResponse()).ToList();
    }

    public async Task<LineResponse> AddLine(int userId, int reportId, CreateLineRequest request, CancellationToken ct)
    {
        var report = await FindOwned(userId, reportId, ct);
        EnsureEditable(report);
        if (await db.ExpenseLines.CountAsync(l => l.ReportId == reportId, ct) >= MaxLinesPerReport)
            throw new ConflictException($"expense report {reportId} already has {MaxLinesPerReport} lines");

        var line = new ExpenseLine
        {
            ReportId = reportId,
            Description = request.Description!.Trim(),
            Category = request.Category!.Value,
            AmountCents = request.AmountCents!.Value,
            IncurredOn = request.IncurredOn!.Value,
            CreatedAt = Now(),
        };
        db.ExpenseLines.Add(line);
        report.UpdatedAt = line.CreatedAt;
        await db.SaveChangesAsync(ct);
        return line.ToResponse();
    }

    public async Task DeleteLine(int userId, int reportId, int lineId, CancellationToken ct)
    {
        var report = await FindOwned(userId, reportId, ct);
        var line = await db.ExpenseLines.SingleOrDefaultAsync(l => l.Id == lineId && l.ReportId == reportId, ct)
                   ?? throw new NotFoundException($"line {lineId} not found on expense report {reportId}");
        EnsureEditable(report);
        db.ExpenseLines.Remove(line);
        report.UpdatedAt = Now();
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------------------------------------------ shared with the review queue

    /// <summary>Projects reports (already filtered and ordered) to their wire form, totals computed in SQL.</summary>
    internal static IQueryable<ReportResponse> Summaries(IQueryable<ExpenseReport> reports) =>
        reports.AsNoTracking().Select(r => new ReportResponse(
            r.Id, r.UserId, r.Title, r.Purpose, r.Status,
            r.Lines.Sum(l => (long?)l.AmountCents) ?? 0,
            r.Lines.Count,
            r.SubmittedAt, r.ReviewerId, r.ReviewComment, r.DecidedAt, r.CreatedAt, r.UpdatedAt));

    internal static string Wire(ReportStatus status) => status.ToString().ToLowerInvariant();

    internal static NotFoundException ReportNotFound(int reportId) =>
        new($"expense report {reportId} not found");

    private Task<ReportResponse> Summary(int reportId, CancellationToken ct) =>
        Summaries(db.ExpenseReports.Where(r => r.Id == reportId)).SingleAsync(ct);

    private async Task<ExpenseReport> FindOwned(int userId, int reportId, CancellationToken ct) =>
        await db.ExpenseReports.SingleOrDefaultAsync(r => r.Id == reportId && r.UserId == userId, ct)
        ?? throw ReportNotFound(reportId);

    private static void EnsureEditable(ExpenseReport report)
    {
        if (!report.Status.IsEditable())
            throw new ConflictException(
                $"expense report {report.Id} is {Wire(report.Status)}; only a draft or rejected report can be changed");
    }

    private DateTime Now() => clock.GetUtcNow().UtcDateTime;
}
