using Microsoft.AspNetCore.Mvc;
using Outlay.Auth;

namespace Outlay.Features.Payouts;

/// <summary>The caller's own payout methods.</summary>
[ApiController]
[Route("payout-methods")]
public sealed class PayoutMethodsController(PayoutService payouts) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<PayoutMethodResponse>>> List(CancellationToken ct) =>
        Ok(await payouts.ListMine(User.UserId(), ct));

    [HttpPost]
    public async Task<ActionResult<PayoutMethodResponse>> Add(CreatePayoutMethodRequest request, CancellationToken ct)
    {
        var method = await payouts.Add(User.UserId(), request, ct);
        return StatusCode(StatusCodes.Status201Created, method);
    }
}
