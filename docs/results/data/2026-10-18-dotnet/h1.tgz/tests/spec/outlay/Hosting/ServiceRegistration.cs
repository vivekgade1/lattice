using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.EntityFrameworkCore;
using Outlay.Auth;
using Outlay.Data;
using Outlay.Domain;
using Outlay.Errors;
using Outlay.Features.Auth;
using Outlay.Features.Payouts;
using Outlay.Features.Reports;
using Outlay.Features.Review;

namespace Outlay.Hosting;

public static class ServiceRegistration
{
    public static WebApplicationBuilder AddOutlay(this WebApplicationBuilder builder, ServiceSettings settings)
    {
        // Loopback only, on the port we were given (ASPNETCORE_URLS, if set, is not ours to follow).
        builder.WebHost.ConfigureKestrel(k => k.Listen(IPAddress.Loopback, settings.Port));

        var services = builder.Services;
        services.AddSingleton(TimeProvider.System);
        services.AddDbContext<OutlayDbContext>(o => o.UseSqlite(settings.SqliteConnection));

        services.AddControllers()
            .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(
                new JsonStringEnumConverter(JsonNamingPolicy.CamelCase, allowIntegerValues: false)));
        services.AddProblemDetails();
        services.AddExceptionHandler<ApiExceptionHandler>();

        services.AddSingleton(new TokenOptions { SigningKey = settings.TokenSigningKey });
        services.AddSingleton<TokenIssuer>();
        services.AddAuthentication(BearerTokenHandler.SchemeName)
            .AddScheme<AuthenticationSchemeOptions, BearerTokenHandler>(BearerTokenHandler.SchemeName, null);
        services.AddAuthorizationBuilder()
            .SetFallbackPolicy(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build())
            .AddPolicy(Policies.Reviewer, p => p.RequireAuthenticatedUser().RequireRole(nameof(UserRole.Admin)));
        // Authentication pulls in data protection; keep its key ring off the disk.
        services.Configure<KeyManagementOptions>(o => o.XmlRepository = new InMemoryXmlRepository());

        services.AddScoped<AuthService>();
        services.AddScoped<ReportService>();
        services.AddScoped<ReviewService>();
        services.AddScoped<PayoutService>();
        return builder;
    }

    /// <summary>Creates the schema on a missing or empty database; leaves an existing one untouched.</summary>
    public static void EnsureSchema(this WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        scope.ServiceProvider.GetRequiredService<OutlayDbContext>().Database.EnsureCreated();
    }
}
