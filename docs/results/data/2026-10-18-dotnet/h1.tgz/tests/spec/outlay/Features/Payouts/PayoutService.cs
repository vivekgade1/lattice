using Microsoft.EntityFrameworkCore;
using Outlay.Data;
using Outlay.Domain;
using Outlay.Errors;

namespace Outlay.Features.Payouts;

public sealed class PayoutService(OutlayDbContext db, TimeProvider clock)
{
    public const int MaxMethodsPerUser = 5;

    public async Task<IReadOnlyList<PayoutMethodResponse>> ListMine(int userId, CancellationToken ct)
    {
        var methods = await db.PayoutMethods.AsNoTracking()
            .Where(p => p.UserId == userId)
            .OrderByDescending(p => p.IsDefault).ThenBy(p => p.Id)
            .ToListAsync(ct);
        return methods.Select(PayoutMethodResponse.From).ToList();
    }

    public async Task<PayoutMethodResponse> Add(int userId, CreatePayoutMethodRequest request, CancellationToken ct)
    {
        var existing = await db.PayoutMethods.Where(p => p.UserId == userId).ToListAsync(ct);
        if (existing.Count >= MaxMethodsPerUser)
            throw new ConflictException($"a user can keep at most {MaxMethodsPerUser} payout methods");

        var number = request.AccountNumber!.Trim().ToUpperInvariant();
        if (existing.Any(p => p.AccountNumber == number))
            throw new ConflictException("this account is already one of your payout methods");

        // The first method is the default; a new default replaces the old one.
        var makeDefault = existing.Count == 0 || request.IsDefault == true;
        if (makeDefault)
            existing.ForEach(p => p.IsDefault = false);

        var method = new PayoutMethod
        {
            UserId = userId,
            Label = request.Label!.Trim(),
            AccountHolder = request.AccountHolder!.Trim(),
            AccountNumber = number,
            AccountLast4 = number[^4..],
            IsDefault = makeDefault,
            CreatedAt = clock.GetUtcNow().UtcDateTime,
        };
        db.PayoutMethods.Add(method);
        await db.SaveChangesAsync(ct);
        return PayoutMethodResponse.From(method);
    }
}
