using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Outlay.Domain;

namespace Outlay.Data.Configurations;

public class PayoutMethodConfiguration : IEntityTypeConfiguration<PayoutMethod>
{
    public void Configure(EntityTypeBuilder<PayoutMethod> b)
    {
        b.ToTable("payout_methods");
        b.HasKey(p => p.Id);
        b.Property(p => p.Id).HasColumnName("id");
        b.Property(p => p.UserId).HasColumnName("user_id");
        b.HasOne(p => p.User).WithMany().HasForeignKey(p => p.UserId).OnDelete(DeleteBehavior.Cascade);
        b.HasIndex(p => p.UserId).HasDatabaseName("ix_payout_methods_user_id");
        b.Property(p => p.Label).HasColumnName("label").HasMaxLength(60).IsRequired();
        b.Property(p => p.AccountHolder).HasColumnName("account_holder").HasMaxLength(100).IsRequired();
        b.Property(p => p.AccountNumber).HasColumnName("account_number").HasMaxLength(34).IsRequired();
        b.Property(p => p.AccountLast4).HasColumnName("account_last4").HasMaxLength(4).IsRequired();
        b.Property(p => p.IsDefault).HasColumnName("is_default");
        b.Property(p => p.CreatedAt).HasColumnName("created_at");
    }
}
