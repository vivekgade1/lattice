using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Outlay.Domain;

namespace Outlay.Data.Configurations;

public class ExpenseLineConfiguration : IEntityTypeConfiguration<ExpenseLine>
{
    public void Configure(EntityTypeBuilder<ExpenseLine> b)
    {
        b.ToTable("expense_lines");
        b.HasKey(l => l.Id);
        b.Property(l => l.Id).HasColumnName("id");
        b.Property(l => l.ReportId).HasColumnName("report_id");
        b.HasIndex(l => l.ReportId).HasDatabaseName("ix_expense_lines_report_id");
        b.Property(l => l.Description).HasColumnName("description").HasMaxLength(200).IsRequired();
        b.Property(l => l.Category).HasColumnName("category").HasMaxLength(16).IsRequired()
            .HasConversion(EnumStorage.LowercaseText(ExpenseCategory.Other));
        b.Property(l => l.AmountCents).HasColumnName("amount_cents");
        b.Property(l => l.IncurredOn).HasColumnName("incurred_on");
        b.Property(l => l.CreatedAt).HasColumnName("created_at");
    }
}
