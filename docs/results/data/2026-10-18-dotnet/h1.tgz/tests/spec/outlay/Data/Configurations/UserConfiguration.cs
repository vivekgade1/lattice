using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Outlay.Domain;

namespace Outlay.Data.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> b)
    {
        b.ToTable("users");
        b.HasKey(u => u.Id);
        b.Property(u => u.Id).HasColumnName("id");
        b.Property(u => u.Email).HasColumnName("email").HasMaxLength(254).IsRequired();
        b.HasIndex(u => u.Email).IsUnique().HasDatabaseName("ux_users_email");
        b.Property(u => u.DisplayName).HasColumnName("display_name").HasMaxLength(100).IsRequired();
        b.Property(u => u.Password).HasColumnName("password").HasMaxLength(200).IsRequired();
        b.Property(u => u.Role).HasColumnName("role").HasMaxLength(16).IsRequired()
            .HasConversion(EnumStorage.LowercaseText(UserRole.Member));
        b.Property(u => u.CreatedAt).HasColumnName("created_at");
    }
}
