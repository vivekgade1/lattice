using System.ComponentModel.DataAnnotations;
using Outlay.Domain;

namespace Outlay.Features.Payouts;

public sealed class CreatePayoutMethodRequest
{
    [Required, StringLength(60, MinimumLength = 1)]
    public string? Label { get; init; }

    [Required, StringLength(100, MinimumLength = 1)]
    public string? AccountHolder { get; init; }

    [Required, StringLength(34, MinimumLength = 6)]
    [RegularExpression("^[0-9A-Za-z]+$", ErrorMessage = "accountNumber may hold only letters and digits")]
    public string? AccountNumber { get; init; }

    public bool? IsDefault { get; init; }
}

/// <summary>What a client sees of a payout method: never the full account number.</summary>
public sealed record PayoutMethodResponse(
    int Id,
    string Label,
    string AccountHolder,
    string AccountLast4,
    bool IsDefault,
    DateTime CreatedAt)
{
    public static PayoutMethodResponse From(PayoutMethod p) =>
        new(p.Id, p.Label, p.AccountHolder, p.AccountLast4, p.IsDefault, p.CreatedAt);
}
