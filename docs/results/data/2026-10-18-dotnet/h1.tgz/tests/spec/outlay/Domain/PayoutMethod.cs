namespace Outlay.Domain;

/// <summary>Where approved reimbursements are paid. The full account number is stored, never returned.</summary>
public class PayoutMethod
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public User? User { get; set; }

    public string Label { get; set; } = "";
    public string AccountHolder { get; set; } = "";
    public string AccountNumber { get; set; } = "";
    public string AccountLast4 { get; set; } = "";
    public bool IsDefault { get; set; }
    public DateTime CreatedAt { get; set; }
}
