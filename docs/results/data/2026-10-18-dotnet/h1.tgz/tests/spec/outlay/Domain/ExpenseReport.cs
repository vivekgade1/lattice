namespace Outlay.Domain;

public class ExpenseReport
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public User? User { get; set; }

    public string Title { get; set; } = "";
    public string? Purpose { get; set; }
    public ReportStatus Status { get; set; } = ReportStatus.Draft;

    public DateTime? SubmittedAt { get; set; }
    public int? ReviewerId { get; set; }
    public User? Reviewer { get; set; }
    public string? ReviewComment { get; set; }
    public DateTime? DecidedAt { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public List<ExpenseLine> Lines { get; set; } = [];
}
