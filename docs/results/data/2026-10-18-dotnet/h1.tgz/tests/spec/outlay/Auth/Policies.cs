using System.Security.Claims;
using Outlay.Domain;

namespace Outlay.Auth;

public static class Policies
{
    /// <summary>Reviewing other people's reports: admins only.</summary>
    public const string Reviewer = "reviewer";
}

public static class ClaimsPrincipalExtensions
{
    public static int UserId(this ClaimsPrincipal principal) =>
        int.Parse(principal.FindFirstValue(ClaimTypes.NameIdentifier)
                  ?? throw new InvalidOperationException("no authenticated user on this request"));

    public static bool IsAdmin(this ClaimsPrincipal principal) => principal.IsInRole(nameof(UserRole.Admin));
}
