using Microsoft.AspNetCore.Mvc;
using Outlay.Auth;

namespace Outlay.Features.Reports;

/// <summary>The caller's own expense reports.</summary>
[ApiController]
[Route("reports")]
public sealed class ReportsController(ReportService reports) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<ReportResponse>>> List(CancellationToken ct) =>
        Ok(await reports.ListMine(User.UserId(), ct));

    [HttpPost]
    public async Task<ActionResult<ReportResponse>> Create(CreateReportRequest request, CancellationToken ct)
    {
        var created = await reports.Create(User.UserId(), request, ct);
        return CreatedAtAction(nameof(Get), new { reportId = created.Id }, created);
    }

    [HttpGet("{reportId:int}")]
    public async Task<ActionResult<ReportDetailResponse>> Get(int reportId, CancellationToken ct) =>
        Ok(await reports.GetMine(User.UserId(), reportId, ct));

    [HttpPatch("{reportId:int}")]
    public async Task<ActionResult<ReportResponse>> Update(int reportId, UpdateReportRequest request, CancellationToken ct) =>
        Ok(await reports.Update(User.UserId(), reportId, request, ct));

    [HttpDelete("{reportId:int}")]
    public async Task<IActionResult> Delete(int reportId, CancellationToken ct)
    {
        await reports.Delete(User.UserId(), reportId, ct);
        return NoContent();
    }

    [HttpPost("{reportId:int}/submit")]
    public async Task<ActionResult<ReportResponse>> Submit(int reportId, CancellationToken ct) =>
        Ok(await reports.Submit(User.UserId(), reportId, ct));
}
