using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace Outlay.Errors;

/// <summary>Maps <see cref="ApiException"/> to its status; anything else is a 500 that reveals nothing.</summary>
public sealed class ApiExceptionHandler(IProblemDetailsService problems, ILogger<ApiExceptionHandler> log)
    : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext http, Exception error, CancellationToken ct)
    {
        ProblemDetails problem;
        if (error is ApiException api)
        {
            problem = new ProblemDetails { Status = api.Status, Title = api.Title, Detail = api.Message };
        }
        else
        {
            log.LogError(error, "unhandled error on {Method} {Path}", http.Request.Method, http.Request.Path);
            problem = new ProblemDetails
            {
                Status = StatusCodes.Status500InternalServerError,
                Title = "Internal Server Error",
                Detail = "an unexpected error occurred",
            };
        }

        http.Response.StatusCode = problem.Status!.Value;
        return await problems.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = http,
            ProblemDetails = problem,
            Exception = error,
        });
    }
}
