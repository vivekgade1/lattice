using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Outlay.Data;

/// <summary>
/// Enums are stored as lowercase text ("draft", "admin"). A value the service does not know reads back as
/// <c>fallback</c> instead of failing the whole query.
/// </summary>
public static class EnumStorage
{
    public static ValueConverter<TEnum, string> LowercaseText<TEnum>(TEnum fallback) where TEnum : struct, Enum =>
        new(v => v.ToString().ToLowerInvariant(), s => Parse(s, fallback));

    public static TEnum Parse<TEnum>(string? stored, TEnum fallback) where TEnum : struct, Enum =>
        Enum.TryParse<TEnum>(stored, ignoreCase: true, out var value) && Enum.IsDefined(value) ? value : fallback;
}
