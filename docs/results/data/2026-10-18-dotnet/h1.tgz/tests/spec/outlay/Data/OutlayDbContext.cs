using Microsoft.EntityFrameworkCore;
using Outlay.Domain;

namespace Outlay.Data;

public class OutlayDbContext(DbContextOptions<OutlayDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<ExpenseReport> ExpenseReports => Set<ExpenseReport>();
    public DbSet<ExpenseLine> ExpenseLines => Set<ExpenseLine>();
    public DbSet<PayoutMethod> PayoutMethods => Set<PayoutMethod>();

    /// <summary>SQLite keeps no time zone: every DateTime the service stores is UTC, so it reads back as UTC.</summary>
    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder) =>
        configurationBuilder.Properties<DateTime>().HaveConversion<UtcDateTimeConverter>();

    protected override void OnModelCreating(ModelBuilder modelBuilder) =>
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OutlayDbContext).Assembly);
}
