namespace Outlay.Domain;

public class User
{
    public int Id { get; set; }
    public string Email { get; set; } = "";
    public string DisplayName { get; set; } = "";

    /// <summary>The credential as typed at login. Never leaves the service.</summary>
    public string Password { get; set; } = "";

    public UserRole Role { get; set; } = UserRole.Member;
    public DateTime CreatedAt { get; set; }
}
