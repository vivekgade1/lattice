using System.ComponentModel.DataAnnotations;

namespace Outlay.Features.Review;

public sealed class ApproveRequest
{
    [StringLength(500)]
    public string? Comment { get; init; }
}

public sealed class RejectRequest
{
    /// <summary>The owner needs to know what to fix, so a rejection always says why.</summary>
    [Required, StringLength(500, MinimumLength = 1)]
    public string? Comment { get; init; }
}
