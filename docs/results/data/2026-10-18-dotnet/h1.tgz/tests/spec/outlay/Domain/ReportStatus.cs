namespace Outlay.Domain;

/// <summary>
/// Lifecycle of an expense report:
/// draft -> submitted -> approved | rejected, and rejected -> submitted after the owner fixes it.
/// </summary>
public enum ReportStatus
{
    Draft,
    Submitted,
    Approved,
    Rejected,
}

public static class ReportStatusRules
{
    /// <summary>States in which the owner may still change the report and its lines.</summary>
    public static bool IsEditable(this ReportStatus status) =>
        status is ReportStatus.Draft or ReportStatus.Rejected;

    public static bool CanTransition(ReportStatus from, ReportStatus to) => (from, to) switch
    {
        (ReportStatus.Draft, ReportStatus.Submitted) => true,
        (ReportStatus.Rejected, ReportStatus.Submitted) => true,
        (ReportStatus.Submitted, ReportStatus.Approved) => true,
        (ReportStatus.Submitted, ReportStatus.Rejected) => true,
        _ => false,
    };
}
