using Microsoft.EntityFrameworkCore;
using Outlay.Data;
using Outlay.Domain;
using Outlay.Errors;
using Outlay.Features.Reports;

namespace Outlay.Features.Review;

/// <summary>The admins' review queue: reports of every user, decided one way or the other.</summary>
public sealed class ReviewService(OutlayDbContext db, TimeProvider clock)
{
    public async Task<IReadOnlyList<ReportResponse>> Queue(ReportStatus status, CancellationToken ct) =>
        await ReportService.Summaries(db.ExpenseReports
                .Where(r => r.Status == status)
                .OrderBy(r => r.SubmittedAt).ThenBy(r => r.Id))
            .ToListAsync(ct);

    public Task<ReportResponse> Approve(int reviewerId, int reportId, string? comment, CancellationToken ct) =>
        Decide(reviewerId, reportId, ReportStatus.Approved, comment, ct);

    public Task<ReportResponse> Reject(int reviewerId, int reportId, string comment, CancellationToken ct) =>
        Decide(reviewerId, reportId, ReportStatus.Rejected, comment, ct);

    private async Task<ReportResponse> Decide(
        int reviewerId, int reportId, ReportStatus to, string? comment, CancellationToken ct)
    {
        var report = await db.ExpenseReports.AsNoTracking()
            .Where(r => r.Id == reportId)
            .Select(r => new { r.UserId, r.Status })
            .SingleOrDefaultAsync(ct) ?? throw ReportService.ReportNotFound(reportId);
        if (report.UserId == reviewerId)
            throw new ForbiddenException("a reviewer cannot decide their own expense report");
        if (!ReportStatusRules.CanTransition(report.Status, to))
            throw new ConflictException(
                $"expense report {reportId} is {ReportService.Wire(report.Status)}; only a submitted report can be {ReportService.Wire(to)}");

        var now = clock.GetUtcNow().UtcDateTime;
        var trimmed = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim();
        var changed = await db.ExpenseReports
            .Where(r => r.Id == reportId && r.Status == ReportStatus.Submitted)
            .ExecuteUpdateAsync(s => s
                .SetProperty(r => r.Status, to)
                .SetProperty(r => r.ReviewerId, reviewerId)
                .SetProperty(r => r.ReviewComment, trimmed)
                .SetProperty(r => r.DecidedAt, now)
                .SetProperty(r => r.UpdatedAt, now), ct);
        if (changed == 0)
            throw new ConflictException($"expense report {reportId} was decided by someone else");

        return await ReportService.Summaries(db.ExpenseReports.Where(r => r.Id == reportId)).SingleAsync(ct);
    }
}
