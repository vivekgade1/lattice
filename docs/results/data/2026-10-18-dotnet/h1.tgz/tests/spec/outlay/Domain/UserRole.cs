namespace Outlay.Domain;

public enum UserRole
{
    Member,
    Admin,
}
