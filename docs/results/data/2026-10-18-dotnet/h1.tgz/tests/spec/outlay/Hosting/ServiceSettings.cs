namespace Outlay.Hosting;

/// <summary>
/// Process settings read from the environment. PORT and the database are given by whoever starts the service;
/// everything else has a default.
/// </summary>
public sealed record ServiceSettings(int Port, string SqliteConnection, string TokenSigningKey)
{
    public static ServiceSettings FromEnvironment(IConfiguration config)
    {
        var portText = config["PORT"];
        var port = 8080;
        if (!string.IsNullOrEmpty(portText) && (!int.TryParse(portText, out port) || port is < 1 or > 65535))
            throw new InvalidOperationException($"PORT must be a TCP port number, got '{portText}'");

        var provider = config["DB_PROVIDER"];
        if (!string.IsNullOrEmpty(provider) && !provider.Equals("sqlite", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"DB_PROVIDER '{provider}' is not supported; this service runs on sqlite");

        var connection = config["DB_CONNECTION"];
        if (string.IsNullOrEmpty(connection))
        {
            var path = config["DB_PATH"];
            connection = $"Data Source={(string.IsNullOrEmpty(path) ? "outlay.db" : Path.GetFullPath(path))}";
        }

        return new ServiceSettings(port, connection, config["TOKEN_SIGNING_KEY"] ?? "");
    }
}
