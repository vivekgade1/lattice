namespace Outlay.Domain;

public enum ExpenseCategory
{
    Travel,
    Lodging,
    Meals,
    Supplies,
    Other,
}
