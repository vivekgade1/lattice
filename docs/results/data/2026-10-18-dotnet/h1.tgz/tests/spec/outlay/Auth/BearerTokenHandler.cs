using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Outlay.Data;

namespace Outlay.Auth;

/// <summary>
/// Authenticates "Authorization: Bearer &lt;token&gt;": the token must verify, and its user must still exist.
/// The role claim comes from the database row, so a role change applies to tokens already issued.
/// </summary>
public sealed class BearerTokenHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder,
    TokenIssuer tokens,
    OutlayDbContext db)
    : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "Bearer";

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        string? header = Request.Headers.Authorization;
        if (string.IsNullOrEmpty(header) || !header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return AuthenticateResult.NoResult();

        var userId = tokens.Validate(header["Bearer ".Length..].Trim());
        if (userId is null)
            return AuthenticateResult.Fail("invalid or expired token");

        var user = await db.Users.AsNoTracking()
            .Where(u => u.Id == userId)
            .Select(u => new { u.Id, u.Email, u.Role })
            .SingleOrDefaultAsync(Context.RequestAborted);
        if (user is null)
            return AuthenticateResult.Fail("unknown user");

        var identity = new ClaimsIdentity(
        [
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.Email),
            new Claim(ClaimTypes.Role, user.Role.ToString()),
        ], SchemeName);
        return AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), SchemeName));
    }

    protected override Task HandleChallengeAsync(AuthenticationProperties properties) =>
        WriteProblem(StatusCodes.Status401Unauthorized, "Unauthorized", "a valid bearer token is required");

    protected override Task HandleForbiddenAsync(AuthenticationProperties properties) =>
        WriteProblem(StatusCodes.Status403Forbidden, "Forbidden", "this action requires the admin role");

    private Task WriteProblem(int status, string title, string detail)
    {
        Response.StatusCode = status;
        if (status == StatusCodes.Status401Unauthorized)
            Response.Headers.WWWAuthenticate = "Bearer";
        return Response.WriteAsJsonAsync(
            new ProblemDetails { Status = status, Title = title, Detail = detail },
            options: null, contentType: "application/problem+json");
    }
}
