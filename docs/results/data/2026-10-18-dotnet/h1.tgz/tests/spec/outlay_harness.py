"""Harness of tests/spec/outlay: how the service is built and started, how its database is seeded, how callers log in.

``make_app(db)`` answers a ProcessApp (the command, not started). The service is built once per change of its sources,
from a copy of the module directory, into the system temp directory; the module directory is never written.
"""

from __future__ import annotations

import datetime as dt
import os
import shutil
import sqlite3
import subprocess
import tempfile
import zlib
from pathlib import Path

from lattice.importer.transport import AuthDriver
from lattice.spec import ServiceCmd
from lattice.spec.process import ProcessApp, process_runtime

MODULE = Path(__file__).resolve().parent / "outlay"
PROJECT = "outlay.csproj"  # the startup project, relative to MODULE
ASSEMBLY = "outlay"  # its assembly name: the build writes <ASSEMBLY>.dll
BUILD_ENV = "outlay_OUT"  # optional: a directory holding an already built <ASSEMBLY>.dll, instead of building
# handle -> (login name, password); at least two entries; the password is the one typed at login
USERS = {"maya": ("maya@outlay.test", "pw-maya-1729"), "omar": ("omar@outlay.test", "pw-omar-4104")}
BUILD_TIMEOUT_S = 900


# ---------------------------------------------------------------- build and start


def _source_key() -> str:
    """A short key of the module's sources: the build is redone only when they change."""
    crc = 0
    for p in sorted(MODULE.rglob("*")):
        rel = p.relative_to(MODULE)
        if p.is_file() and not {"bin", "obj"} & set(rel.parts):
            crc = zlib.crc32(rel.as_posix().encode() + b"\0" + p.read_bytes() + b"\0", crc)
    return f"{crc:08x}"


def _dotnet() -> str:
    found = shutil.which("dotnet")
    if found is None:
        raise RuntimeError("outlay: `dotnet` is not on PATH")
    return found


def build_dir() -> Path:
    """The directory holding the built service: ``$outlay_OUT``, else built (once per source key) into the system
    temp directory from a copy of MODULE (bin and obj left out)."""
    if env := os.environ.get(BUILD_ENV):
        return Path(env)
    root = Path(tempfile.gettempdir()) / f"build-outlay-{_source_key()}"
    out = root / "out"
    if (out / f"{ASSEMBLY}.dll").is_file():
        return out
    shutil.rmtree(root, ignore_errors=True)
    src = root / "src"
    shutil.copytree(MODULE, src, ignore=shutil.ignore_patterns("bin", "obj"))
    env = {**os.environ, "DOTNET_CLI_TELEMETRY_OPTOUT": "1", "DOTNET_NOLOGO": "1"}
    tmp = root / f"out-{os.getpid()}"
    proc = subprocess.run(  # noqa: S603 -- the module's own build
        [_dotnet(), "build", str(src / PROJECT), "-c", "Release", "-p:RestoreLockedMode=true", "-o", str(tmp), "--nologo"],
        cwd=src, capture_output=True, text=True, check=False, env=env, timeout=BUILD_TIMEOUT_S,
    )  # fmt: skip
    if proc.returncode != 0:
        shutil.rmtree(root, ignore_errors=True)
        raise RuntimeError(f"outlay: dotnet build failed:\n{(proc.stdout + proc.stderr).strip()[-3000:]}")
    os.replace(tmp, out)
    return out


# ---------------------------------------------------------------- database references


def adonet_sqlite(path: str | Path) -> str:
    """The Microsoft.Data.Sqlite connection string of a database file."""
    return f"Data Source={Path(path).resolve()}"


# ---------------------------------------------------------------- the app and its services


def make_app(db: Path | str) -> ProcessApp:
    """The service on ``db`` (a SQLite path). The service creates its own schema when it starts on an empty database.
    It receives PORT, DB_PATH (``db`` made absolute), DB_PROVIDER (``sqlite``) and DB_CONNECTION (the ADO.NET string)."""
    out = build_dir()
    env = {"DB_PROVIDER": "sqlite", "DB_CONNECTION": adonet_sqlite(db)}
    return ProcessApp([_dotnet(), str(out / f"{ASSEMBLY}.dll")], db_path=db, env=env, cwd=str(out), health_path="/health")


# background services {name: (db) -> ServiceCmd}: this service has none
SERVICES: dict = {}

RUNTIME = process_runtime(framework="dotnet", auth=AuthDriver.json("/auth/login", USERS, username_field="email"))
LOGIN = RUNTIME.auth.login


# ---------------------------------------------------------------- the seed


# handle -> role in the users table; the first entry of USERS is a member, the second an admin (truth.json seed_users)
ROLES = {"maya": "member", "omar": "admin"}
DISPLAY_NAMES = {"maya": "Maya Lindqvist", "omar": "Omar Haddad"}


def seed_rows() -> dict[str, list[dict]]:
    """The seed: table -> rows (column -> value; str, int, float, bool, None or datetime), parents before children.
    The users of USERS carry id 1, 2, ... and their plain password in the password column. Row 1 of every table a
    route names is reachable by the member (maya, user 1): report 1 is her draft with lines 1 and 2, report 2 her
    submitted report waiting in the review queue, payout method 1 hers. Report 3 is the admin's own draft."""
    t0 = dt.datetime(2026, 9, 1, 9, 0, 0)
    users = []
    for i, (handle, (login_name, password)) in enumerate(USERS.items(), 1):
        users.append({"id": i, "email": login_name, "display_name": DISPLAY_NAMES[handle], "password": password,
                      "role": ROLES[handle], "created_at": t0})  # fmt: skip
    reports = [
        {"id": 1, "user_id": 1, "title": "Client visit, Lisbon", "purpose": "Kick-off workshop with the client",
         "status": "draft", "submitted_at": None, "reviewer_id": None, "review_comment": None, "decided_at": None,
         "created_at": t0 + dt.timedelta(days=2), "updated_at": t0 + dt.timedelta(days=2)},
        {"id": 2, "user_id": 1, "title": "Conference, September", "purpose": None,
         "status": "submitted", "submitted_at": t0 + dt.timedelta(days=5), "reviewer_id": None, "review_comment": None,
         "decided_at": None, "created_at": t0 + dt.timedelta(days=4), "updated_at": t0 + dt.timedelta(days=5)},
        {"id": 3, "user_id": 2, "title": "Office supplies", "purpose": None,
         "status": "draft", "submitted_at": None, "reviewer_id": None, "review_comment": None, "decided_at": None,
         "created_at": t0 + dt.timedelta(days=6), "updated_at": t0 + dt.timedelta(days=6)},
    ]  # fmt: skip
    lines = [
        {"id": 1, "report_id": 1, "description": "Train to the airport", "category": "travel", "amount_cents": 2450,
         "incurred_on": "2026-09-02", "created_at": t0 + dt.timedelta(days=2)},
        {"id": 2, "report_id": 1, "description": "Hotel, two nights", "category": "lodging", "amount_cents": 31800,
         "incurred_on": "2026-09-03", "created_at": t0 + dt.timedelta(days=2)},
        {"id": 3, "report_id": 2, "description": "Conference pass", "category": "other", "amount_cents": 49900,
         "incurred_on": "2026-09-04", "created_at": t0 + dt.timedelta(days=4)},
        {"id": 4, "report_id": 3, "description": "Printer paper", "category": "supplies", "amount_cents": 1999,
         "incurred_on": "2026-09-06", "created_at": t0 + dt.timedelta(days=6)},
    ]  # fmt: skip
    payouts = [
        {"id": 1, "user_id": 1, "label": "Salary account", "account_holder": "Maya Lindqvist",
         "account_number": "SE4550000000058398257466", "account_last4": "7466", "is_default": True,
         "created_at": t0 + dt.timedelta(days=1)},
    ]  # fmt: skip
    return {"users": users, "expense_reports": reports, "expense_lines": lines, "payout_methods": payouts}


# The schema exactly as the service creates it on an empty SQLite file (``python3 smoke.py OUT outlay schema`` prints it).
DDL = """
CREATE TABLE "users" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_users" PRIMARY KEY AUTOINCREMENT,
    "email" TEXT NOT NULL,
    "display_name" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "created_at" TEXT NOT NULL
);
CREATE TABLE "expense_reports" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_expense_reports" PRIMARY KEY AUTOINCREMENT,
    "user_id" INTEGER NOT NULL,
    "title" TEXT NOT NULL,
    "purpose" TEXT NULL,
    "status" TEXT NOT NULL,
    "submitted_at" TEXT NULL,
    "reviewer_id" INTEGER NULL,
    "review_comment" TEXT NULL,
    "decided_at" TEXT NULL,
    "created_at" TEXT NOT NULL,
    "updated_at" TEXT NOT NULL,
    CONSTRAINT "FK_expense_reports_users_reviewer_id" FOREIGN KEY ("reviewer_id") REFERENCES "users" ("id") ON DELETE SET NULL,
    CONSTRAINT "FK_expense_reports_users_user_id" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);
CREATE TABLE "expense_lines" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_expense_lines" PRIMARY KEY AUTOINCREMENT,
    "report_id" INTEGER NOT NULL,
    "description" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "amount_cents" INTEGER NOT NULL,
    "incurred_on" TEXT NOT NULL,
    "created_at" TEXT NOT NULL,
    CONSTRAINT "FK_expense_lines_expense_reports_report_id" FOREIGN KEY ("report_id") REFERENCES "expense_reports" ("id") ON DELETE CASCADE
);
CREATE TABLE "payout_methods" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_payout_methods" PRIMARY KEY AUTOINCREMENT,
    "user_id" INTEGER NOT NULL,
    "label" TEXT NOT NULL,
    "account_holder" TEXT NOT NULL,
    "account_number" TEXT NOT NULL,
    "account_last4" TEXT NOT NULL,
    "is_default" INTEGER NOT NULL,
    "created_at" TEXT NOT NULL,
    CONSTRAINT "FK_payout_methods_users_user_id" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);
CREATE INDEX "ix_expense_lines_report_id" ON "expense_lines" ("report_id");
CREATE INDEX "ix_expense_reports_reviewer_id" ON "expense_reports" ("reviewer_id");
CREATE INDEX "ix_expense_reports_status" ON "expense_reports" ("status");
CREATE INDEX "ix_expense_reports_user_id" ON "expense_reports" ("user_id");
CREATE INDEX "ix_payout_methods_user_id" ON "payout_methods" ("user_id");
CREATE UNIQUE INDEX "ux_users_email" ON "users" ("email");
"""  # noqa: E501

def _sqlite_value(v: object) -> object:
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S.%f")
    return v


def build_db(db: Path | str) -> Path | str:
    """A seeded SQLite database: the file replaced, the schema by hand (DDL), then the rows. Answers ``db``, the very
    argument."""
    path = Path(db)
    if path.exists():
        path.unlink()
    conn = sqlite3.connect(path)
    try:
        conn.executescript(DDL)
        for table, rows in seed_rows().items():
            for row in rows:
                cols = list(row)
                conn.execute(f'INSERT INTO "{table}" ({", ".join(chr(34) + c + chr(34) for c in cols)}) '
                             f'VALUES ({", ".join("?" for _ in cols)})', [_sqlite_value(row[c]) for c in cols])  # fmt: skip
        conn.commit()
    finally:
        conn.close()
    return db
