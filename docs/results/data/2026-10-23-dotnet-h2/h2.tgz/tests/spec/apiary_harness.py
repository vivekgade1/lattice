"""Harness of tests/spec/apiary: how the service is built and started, how its database is seeded, how callers log in.

``make_app(db)`` answers a ProcessApp (the command, not started). The service is built once per change of its sources,
from a copy of the module directory, into the system temp directory; the module directory is never written.
"""

from __future__ import annotations

import datetime as dt
import os
import shutil
import sqlite3
import subprocess
import tempfile
import zlib
from pathlib import Path
from urllib.parse import unquote, urlsplit

from lattice.importer.transport import AuthDriver
from lattice.spec import ServiceCmd
from lattice.spec.process import ProcessApp, process_runtime

MODULE = Path(__file__).resolve().parent / "apiary"
PROJECT = "apiary.csproj"  # the startup project, relative to MODULE
ASSEMBLY = "apiary"  # its assembly name: the build writes <ASSEMBLY>.dll
BUILD_ENV = "apiary_OUT"  # optional: a directory holding an already built <ASSEMBLY>.dll, instead of building
# handle -> (login name, password); at least two entries; the password is the one typed at login
USERS = {"mara": ("mara", "pw-mara-bees"), "tobias": ("tobias", "pw-tobias-bees"), "ines": ("ines", "pw-ines-inspector")}
BUILD_TIMEOUT_S = 900


# ---------------------------------------------------------------- build and start


def _source_key() -> str:
    """A short key of the module's sources: the build is redone only when they change."""
    crc = 0
    for p in sorted(MODULE.rglob("*")):
        rel = p.relative_to(MODULE)
        if p.is_file() and not {"bin", "obj"} & set(rel.parts):
            crc = zlib.crc32(rel.as_posix().encode() + b"\0" + p.read_bytes() + b"\0", crc)
    return f"{crc:08x}"


def _dotnet() -> str:
    found = shutil.which("dotnet")
    if found is None:
        raise RuntimeError("apiary: `dotnet` is not on PATH")
    return found


def build_dir() -> Path:
    """The directory holding the built service: ``$apiary_OUT``, else built (once per source key) into the system
    temp directory from a copy of MODULE (bin and obj left out)."""
    if env := os.environ.get(BUILD_ENV):
        return Path(env)
    root = Path(tempfile.gettempdir()) / f"build-apiary-{_source_key()}"
    out = root / "out"
    if (out / f"{ASSEMBLY}.dll").is_file():
        return out
    shutil.rmtree(root, ignore_errors=True)
    src = root / "src"
    shutil.copytree(MODULE, src, ignore=shutil.ignore_patterns("bin", "obj"))
    env = {**os.environ, "DOTNET_CLI_TELEMETRY_OPTOUT": "1", "DOTNET_NOLOGO": "1"}
    tmp = root / f"out-{os.getpid()}"
    proc = subprocess.run(  # noqa: S603 -- the module's own build
        [_dotnet(), "build", str(src / PROJECT), "-c", "Release", "-p:RestoreLockedMode=true", "-o", str(tmp), "--nologo"],
        cwd=src, capture_output=True, text=True, check=False, env=env, timeout=BUILD_TIMEOUT_S,
    )  # fmt: skip
    if proc.returncode != 0:
        shutil.rmtree(root, ignore_errors=True)
        raise RuntimeError(f"apiary: dotnet build failed:\n{(proc.stdout + proc.stderr).strip()[-3000:]}")
    os.replace(tmp, out)
    return out


# ---------------------------------------------------------------- database references


def is_url(db: object) -> bool:
    """A server database is a URL (``mysql://user:password@host:port/name``), a SQLite database a file path."""
    return "://" in str(db)


def _value(v: str) -> str:
    """One ADO.NET connection-string value, quoted when it holds a character the syntax reserves."""
    if v == "" or any(c in v for c in ";\"'=") or v != v.strip():
        return '"' + v.replace('"', '""') + '"'
    return v


def adonet_sqlite(path: str | Path) -> str:
    """The Microsoft.Data.Sqlite connection string of a database file."""
    return f"Data Source={Path(path).resolve()}"


# ---------------------------------------------------------------- the app and its services


def make_app(db: Path | str) -> ProcessApp:
    """The service on ``db`` (a SQLite path, or a MySQL URL). The service creates its own schema when it starts on an
    empty database. It receives PORT, DB_PATH (``db`` as given, a path made absolute), DB_PROVIDER (``sqlite`` or
    ``mysql``) and DB_CONNECTION (the ADO.NET string)."""
    out = build_dir()
    env = {"DB_PROVIDER": "sqlite", "DB_CONNECTION": adonet_sqlite(db)}
    return ProcessApp([_dotnet(), str(out / f"{ASSEMBLY}.dll")], db_path=db, env=env, cwd=str(out), health_path="/health")


# the spec's background services {name: (db) -> ServiceCmd}; empty when the product has none
SERVICES: dict = {}

RUNTIME = process_runtime(framework="dotnet", auth=AuthDriver.json("/login", USERS))
LOGIN = RUNTIME.auth.login


# ---------------------------------------------------------------- the seed


def seed_rows() -> dict[str, list[dict]]:
    """The seed: table -> rows (column -> value), parents before children. Row 1 of every table belongs to the first
    keeper (mara) so that the route check can reach it."""
    roles = {"mara": "Keeper", "tobias": "Keeper", "ines": "Inspector"}
    users = [{"id": i, "name": name, "password": pw, "role": roles[name]} for i, (name, pw) in enumerate(USERS.values(), 1)]
    at = dt.datetime(2026, 6, 1, 9, 0, 0)
    return {
        "users": users,
        "hives": [
            {"id": 1, "owner_id": 1, "name": "Meadow", "queen_year": 2025, "boxes": 2, "yard_location": "55.67,12.56"},
            {"id": 2, "owner_id": 2, "name": "Orchard", "queen_year": 2024, "boxes": 3, "yard_location": None},
        ],
        "inspections": [
            {"id": 1, "hive_id": 1, "inspected_at": at, "brood_frames": 6, "temperament": 2, "remarks": "calm"},
            {"id": 2, "hive_id": 2, "inspected_at": at, "brood_frames": 4, "temperament": 4, "remarks": None},
        ],
        "lots": [
            {"id": 1, "owner_id": 1, "label": "Spring clover", "weight_kg": 12.5, "moisture_pct": 17.2, "state": "Curing",
             "created_at": at, "updated_at": at},
            {"id": 2, "owner_id": 2, "label": "Linden", "weight_kg": 8.0, "moisture_pct": 19.4, "state": "Extracted",
             "created_at": at, "updated_at": at},
        ],
    }


# The schema exactly as the service creates it on an empty SQLite file (``python3 smoke.py OUT apiary schema`` prints it).
DDL = """
CREATE TABLE "hives" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_hives" PRIMARY KEY AUTOINCREMENT,
    "owner_id" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "queen_year" INTEGER NOT NULL,
    "boxes" INTEGER NOT NULL,
    "yard_location" TEXT NULL,
    CONSTRAINT "FK_hives_users_owner_id" FOREIGN KEY ("owner_id") REFERENCES "users" ("id") ON DELETE CASCADE
);
CREATE TABLE "inspections" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_inspections" PRIMARY KEY AUTOINCREMENT,
    "hive_id" INTEGER NOT NULL,
    "inspected_at" TEXT NOT NULL,
    "brood_frames" INTEGER NOT NULL,
    "temperament" INTEGER NOT NULL,
    "remarks" TEXT NULL,
    CONSTRAINT "FK_inspections_hives_hive_id" FOREIGN KEY ("hive_id") REFERENCES "hives" ("id") ON DELETE CASCADE
);
CREATE TABLE "lots" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_lots" PRIMARY KEY AUTOINCREMENT,
    "owner_id" INTEGER NOT NULL,
    "label" TEXT NOT NULL,
    "weight_kg" REAL NOT NULL,
    "moisture_pct" REAL NOT NULL,
    "state" TEXT NOT NULL,
    "created_at" TEXT NOT NULL,
    "updated_at" TEXT NOT NULL,
    CONSTRAINT "FK_lots_users_owner_id" FOREIGN KEY ("owner_id") REFERENCES "users" ("id") ON DELETE CASCADE
);
CREATE TABLE "sessions" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_sessions" PRIMARY KEY AUTOINCREMENT,
    "token" TEXT NOT NULL,
    "user_id" INTEGER NOT NULL,
    "expires_at" TEXT NOT NULL,
    CONSTRAINT "FK_sessions_users_user_id" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);
CREATE TABLE "users" (
    "id" INTEGER NOT NULL CONSTRAINT "PK_users" PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "role" TEXT NOT NULL
);
CREATE UNIQUE INDEX "IX_hives_owner_id_name" ON "hives" ("owner_id", "name");
CREATE INDEX "IX_inspections_hive_id" ON "inspections" ("hive_id");
CREATE INDEX "IX_lots_owner_id" ON "lots" ("owner_id");
CREATE UNIQUE INDEX "IX_sessions_token" ON "sessions" ("token");
CREATE INDEX "IX_sessions_user_id" ON "sessions" ("user_id");
CREATE UNIQUE INDEX "IX_users_name" ON "users" ("name");
"""  # noqa: E501

def _sqlite_value(v: object) -> object:
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S.%f")
    return v


def build_db(db: Path | str) -> Path | str:
    """A seeded database. A SQLite path: replaced, schema by hand (DDL), then the rows. A MySQL URL (an empty
    database): the service starts once and creates its schema, then the rows go in through Lattice's adapter.
    Answers ``db``, the very argument."""
    path = Path(db)
    if path.exists():
        path.unlink()
    conn = sqlite3.connect(path)
    try:
        conn.executescript(DDL)
        for table, rows in seed_rows().items():
            for row in rows:
                cols = list(row)
                conn.execute(f'INSERT INTO "{table}" ({", ".join(chr(34) + c + chr(34) for c in cols)}) '
                             f'VALUES ({", ".join("?" for _ in cols)})', [_sqlite_value(row[c]) for c in cols])  # fmt: skip
        conn.commit()
    finally:
        conn.close()
    return db

