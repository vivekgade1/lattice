using Apiary.Data;
using Apiary.Domain;
using Apiary.Http;
using Microsoft.EntityFrameworkCore;

namespace Apiary.Endpoints;

public static class AdminEndpoints
{
    public static void MapAdmin(this IEndpointRouteBuilder app)
    {
        app.MapGet("/admin/overview", async (ApiaryDb db, CancellationToken ct) =>
        {
            var byState = await db.Lots.AsNoTracking().GroupBy(l => l.State)
                .Select(g => new { state = g.Key, lots = g.Count(), kilograms = g.Sum(l => l.WeightKg) }).ToListAsync(ct);
            return Results.Json(new
            {
                keepers = await db.Users.CountAsync(u => u.Role == Roles.Keeper, ct),
                hives = await db.Hives.CountAsync(ct),
                inspections = await db.Inspections.CountAsync(ct),
                lots_by_state = byState.OrderBy(x => x.state),
            });
        }).RequireSignIn(Roles.Inspector);
    }
}
