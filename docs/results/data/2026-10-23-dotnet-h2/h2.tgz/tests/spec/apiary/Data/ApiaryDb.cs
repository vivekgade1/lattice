using System.Text;
using Apiary.Domain;
using Microsoft.EntityFrameworkCore;

namespace Apiary.Data;

public class ApiaryDb(DbContextOptions<ApiaryDb> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Session> Sessions => Set<Session>();
    public DbSet<Hive> Hives => Set<Hive>();
    public DbSet<Inspection> Inspections => Set<Inspection>();
    public DbSet<Lot> Lots => Set<Lot>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>(e =>
        {
            e.ToTable("users");
            e.Property(x => x.Name).HasMaxLength(80);
            e.Property(x => x.Password).HasMaxLength(200);
            e.Property(x => x.Role).HasMaxLength(20);
            e.HasIndex(x => x.Name).IsUnique();
        });
        b.Entity<Session>(e =>
        {
            e.ToTable("sessions");
            e.Property(x => x.Token).HasMaxLength(64);
            e.HasIndex(x => x.Token).IsUnique();
            e.HasOne<User>().WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<Hive>(e =>
        {
            e.ToTable("hives");
            e.Property(x => x.Name).HasMaxLength(60);
            e.Property(x => x.YardLocation).HasMaxLength(200);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.OwnerId).OnDelete(DeleteBehavior.Cascade);
            e.HasIndex(x => new { x.OwnerId, x.Name }).IsUnique();
        });
        b.Entity<Inspection>(e =>
        {
            e.ToTable("inspections");
            e.Property(x => x.Remarks).HasMaxLength(500);
            e.HasOne<Hive>().WithMany().HasForeignKey(x => x.HiveId).OnDelete(DeleteBehavior.Cascade);
            e.HasIndex(x => x.HiveId);
        });
        b.Entity<Lot>(e =>
        {
            e.ToTable("lots");
            e.Property(x => x.Label).HasMaxLength(60);
            e.Property(x => x.State).HasMaxLength(20);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.OwnerId).OnDelete(DeleteBehavior.Cascade);
            e.HasIndex(x => x.OwnerId);
        });

        foreach (var prop in b.Model.GetEntityTypes().SelectMany(t => t.GetProperties()))
            prop.SetColumnName(Snake(prop.Name));
    }

    private static string Snake(string name)
    {
        var sb = new StringBuilder();
        for (var i = 0; i < name.Length; i++)
        {
            if (char.IsUpper(name[i]) && i > 0) sb.Append('_');
            sb.Append(char.ToLowerInvariant(name[i]));
        }
        return sb.ToString();
    }
}
