namespace Apiary.Http;

// Request bodies. Every value is nullable so that "left out" can be told from zero and turned away by Check.
public record LoginBody(string? Username, string? Password);
public record HiveBody(string? Name, int? QueenYear, int? Boxes, string? YardLocation);
public record InspectionBody(int? BroodFrames, int? Temperament, string? Remarks);
public record LotBody(string? Label, double? WeightKg, double? MoisturePct);
public record AdvanceBody(string? To, double? MoisturePct);
