using System.Text.Json;
using Apiary.Data;
using Apiary.Endpoints;
using Apiary.Http;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// The harness names the port and the database; nothing else is needed to start.
var port = Environment.GetEnvironmentVariable("PORT") ?? "5000";
builder.WebHost.UseUrls($"http://127.0.0.1:{port}");

var connection = Environment.GetEnvironmentVariable("DB_CONNECTION")
    ?? $"Data Source={Environment.GetEnvironmentVariable("DB_PATH") ?? "apiary.db"}";
builder.Services.AddDbContext<ApiaryDb>(o => o.UseSqlite(connection));
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower);
builder.Logging.ClearProviders();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
    scope.ServiceProvider.GetRequiredService<ApiaryDb>().Database.EnsureCreated();

// A body that is not JSON, or has a value of the wrong type, is answered like any other invalid request.
app.Use(async (ctx, next) =>
{
    try { await next(ctx); }
    catch (BadHttpRequestException e) when (!ctx.Response.HasStarted)
    {
        var bad = new Check();
        bad.Problems["body"] = e.InnerException is JsonException ? "is not valid JSON for this route" : "could not be read";
        await Failure.Invalid(bad).ExecuteAsync(ctx);
    }
});

app.MapAccount();
app.MapHives();
app.MapLots();
app.MapAdmin();

app.Run();
