using System.Security.Cryptography;
using System.Text;
using Apiary.Data;
using Apiary.Domain;
using Microsoft.EntityFrameworkCore;

namespace Apiary.Http;

/// <summary>The signed-in person behind a request, put on the request by <see cref="Guard"/>.</summary>
public sealed record Caller(int Id, string Name, string Role)
{
    private const string Key = "apiary.caller";

    public static Caller Of(HttpContext ctx) => (Caller)ctx.Items[Key]!;

    public static void Set(HttpContext ctx, Caller c) => ctx.Items[Key] = c;
}

public static class Guard
{
    public static readonly TimeSpan SessionLife = TimeSpan.FromHours(12);

    /// <summary>Requires a valid bearer token; with <paramref name="role"/>, only people holding that role pass.</summary>
    public static RouteHandlerBuilder RequireSignIn(this RouteHandlerBuilder route, string? role = null) =>
        route.AddEndpointFilter(async (ctx, next) =>
        {
            var http = ctx.HttpContext;
            var header = http.Request.Headers.Authorization.ToString();
            const string prefix = "Bearer ";
            if (!header.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || header.Length == prefix.Length)
                return Failure.Unauthorized("sign in first");

            var token = header[prefix.Length..].Trim();
            var db = http.RequestServices.GetRequiredService<ApiaryDb>();
            var now = DateTime.UtcNow;
            var who = await db.Sessions.AsNoTracking()
                .Where(s => s.Token == token && s.ExpiresAt > now)
                .Join(db.Users, s => s.UserId, u => u.Id, (s, u) => new Caller(u.Id, u.Name, u.Role))
                .FirstOrDefaultAsync(http.RequestAborted);
            if (who is null) return Failure.Unauthorized("the token is not valid");
            if (role is not null && who.Role != role) return Failure.Forbidden($"only the {role} role may do this");

            Caller.Set(http, who);
            return await next(ctx);
        });

    public static string NewToken() => Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
        .Replace('+', '-').Replace('/', '_').TrimEnd('=');

    public static bool SameSecret(string stored, string typed) =>
        CryptographicOperations.FixedTimeEquals(
            SHA256.HashData(Encoding.UTF8.GetBytes(stored)), SHA256.HashData(Encoding.UTF8.GetBytes(typed)));
}
