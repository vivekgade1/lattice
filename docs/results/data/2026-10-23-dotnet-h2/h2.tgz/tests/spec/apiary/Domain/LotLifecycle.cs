namespace Apiary.Domain;

/// <summary>The life of a honey lot: Extracted, Curing, Bottled, then possibly Recalled; Discarded ends an unbottled one.</summary>
public static class LotLifecycle
{
    public const string Extracted = "Extracted";
    public const string Curing = "Curing";
    public const string Bottled = "Bottled";
    public const string Recalled = "Recalled";
    public const string Discarded = "Discarded";

    /// <summary>Honey wetter than this ferments on the shelf, so it may not be bottled.</summary>
    public const double MaxBottlingMoisture = 18.6;

    private static readonly Dictionary<string, string[]> Edges = new()
    {
        [Extracted] = [Curing, Discarded],
        [Curing] = [Bottled, Discarded],
        [Bottled] = [Recalled],
        [Recalled] = [],
        [Discarded] = [],
    };

    public static IReadOnlyCollection<string> All => Edges.Keys;

    public static bool IsState(string s) => Edges.ContainsKey(s);

    public static bool CanMove(string from, string to) => Edges.TryGetValue(from, out var next) && next.Contains(to);
}
