using Apiary.Data;
using Apiary.Domain;
using Apiary.Http;
using Microsoft.EntityFrameworkCore;

namespace Apiary.Endpoints;

public static class AccountEndpoints
{
    public static void MapAccount(this IEndpointRouteBuilder app)
    {
        app.MapGet("/health", () => Results.Json(new { status = "ok" }));

        app.MapPost("/login", async (LoginBody body, ApiaryDb db, CancellationToken ct) =>
        {
            var check = new Check();
            var name = check.Text("username", body.Username, 1, 80);
            if (string.IsNullOrEmpty(body.Password)) check.Problems["password"] = "is required";
            if (!check.Ok) return Failure.Invalid(check);

            var user = await db.Users.FirstOrDefaultAsync(u => u.Name == name, ct);
            if (user is null || !Guard.SameSecret(user.Password, body.Password!))
                return Failure.Unauthorized("wrong name or password");

            var session = new Session { Token = Guard.NewToken(), UserId = user.Id, ExpiresAt = DateTime.UtcNow + Guard.SessionLife };
            db.Sessions.Add(session);
            await db.SaveChangesAsync(ct);
            return Results.Json(new { access_token = session.Token, role = user.Role, expires_at = session.ExpiresAt });
        });
    }
}
