namespace Apiary.Domain;

public static class Roles
{
    public const string Keeper = "Keeper";
    public const string Inspector = "Inspector";
}

public class User
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Password { get; set; } = "";
    public string Role { get; set; } = Roles.Keeper;
}

public class Session
{
    public int Id { get; set; }
    public string Token { get; set; } = "";
    public int UserId { get; set; }
    public DateTime ExpiresAt { get; set; }
}

public class Hive
{
    public int Id { get; set; }
    public int OwnerId { get; set; }
    public string Name { get; set; } = "";
    public int QueenYear { get; set; }
    public int Boxes { get; set; }
    /// <summary>Where the hive stands. Kept for theft recovery; no answer carries it.</summary>
    public string? YardLocation { get; set; }
}

public class Inspection
{
    public int Id { get; set; }
    public int HiveId { get; set; }
    public DateTime InspectedAt { get; set; }
    public int BroodFrames { get; set; }
    public int Temperament { get; set; }
    public string? Remarks { get; set; }
}

public class Lot
{
    public int Id { get; set; }
    public int OwnerId { get; set; }
    public string Label { get; set; } = "";
    public double WeightKg { get; set; }
    public double MoisturePct { get; set; }
    public string State { get; set; } = LotLifecycle.Extracted;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}
