using Apiary.Data;
using Apiary.Domain;
using Apiary.Http;
using Microsoft.EntityFrameworkCore;

namespace Apiary.Endpoints;

public static class LotEndpoints
{
    private static object View(Lot l) => new
    {
        id = l.Id, label = l.Label, weight_kg = l.WeightKg, moisture_pct = l.MoisturePct,
        state = l.State, created_at = l.CreatedAt, updated_at = l.UpdatedAt,
    };

    public static void MapLots(this IEndpointRouteBuilder app)
    {
        app.MapGet("/lots", async (string? state, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            if (state is not null && !LotLifecycle.IsState(state))
            {
                var bad = new Check();
                bad.Problems["state"] = "is not a lot state";
                return Failure.Invalid(bad);
            }
            var me = Caller.Of(http);
            var query = db.Lots.AsNoTracking().Where(l => l.OwnerId == me.Id);
            if (state is not null) query = query.Where(l => l.State == state);
            return Results.Json((await query.OrderBy(l => l.Id).ToListAsync(ct)).Select(View));
        }).RequireSignIn();

        app.MapPost("/lots", async (LotBody body, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var check = new Check();
            var label = check.Text("label", body.Label, 1, 60);
            var weight = check.Number("weight_kg", body.WeightKg, 0.1, 500);
            var moisture = check.Number("moisture_pct", body.MoisturePct, 10, 30);
            if (!check.Ok) return Failure.Invalid(check);

            var now = DateTime.UtcNow;
            var lot = new Lot
            {
                OwnerId = Caller.Of(http).Id, Label = label!, WeightKg = weight, MoisturePct = moisture,
                State = LotLifecycle.Extracted, CreatedAt = now, UpdatedAt = now,
            };
            db.Lots.Add(lot);
            await db.SaveChangesAsync(ct);
            return Results.Json(View(lot), statusCode: 201);
        }).RequireSignIn();

        app.MapGet("/lots/{id:int}", async (int id, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            var lot = await db.Lots.AsNoTracking().FirstOrDefaultAsync(l => l.Id == id && l.OwnerId == me.Id, ct);
            return lot is null ? Failure.NotFound("lot") : Results.Json(View(lot));
        }).RequireSignIn();

        app.MapPost("/lots/{id:int}/advance", async (int id, AdvanceBody body, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            var check = new Check();
            if (body.To is null) check.Problems["to"] = "is required";
            else if (!LotLifecycle.IsState(body.To)) check.Problems["to"] = "is not a lot state";
            if (body.MoisturePct is { } m && (double.IsNaN(m) || m < 10 || m > 30)) check.Problems["moisture_pct"] = "must be between 10 and 30";
            if (!check.Ok) return Failure.Invalid(check);

            var lot = await db.Lots.AsNoTracking().FirstOrDefaultAsync(l => l.Id == id && l.OwnerId == me.Id, ct);
            if (lot is null) return Failure.NotFound("lot");

            var to = body.To!;
            if (!LotLifecycle.CanMove(lot.State, to))
                return Failure.Conflict($"a lot that is {lot.State} cannot become {to}");
            var moisture = body.MoisturePct ?? lot.MoisturePct;
            if (to == LotLifecycle.Bottled && moisture > LotLifecycle.MaxBottlingMoisture)
                return Failure.Conflict($"moisture {moisture} is above {LotLifecycle.MaxBottlingMoisture}; the honey is too wet to bottle");

            // The state in the WHERE clause makes the move atomic when two requests race on one lot.
            var from = lot.State;
            var changed = await db.Lots.Where(l => l.Id == id && l.OwnerId == me.Id && l.State == from)
                .ExecuteUpdateAsync(s => s.SetProperty(l => l.State, to)
                    .SetProperty(l => l.MoisturePct, moisture).SetProperty(l => l.UpdatedAt, DateTime.UtcNow), ct);
            if (changed == 0) return Failure.Conflict("the lot changed meanwhile; read it again");

            var fresh = await db.Lots.AsNoTracking().FirstAsync(l => l.Id == id, ct);
            return Results.Json(View(fresh));
        }).RequireSignIn();
    }
}
