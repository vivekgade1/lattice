using Apiary.Data;
using Apiary.Domain;
using Apiary.Http;
using Microsoft.EntityFrameworkCore;

namespace Apiary.Endpoints;

public static class HiveEndpoints
{
    private static object View(Hive h) => new { id = h.Id, name = h.Name, queen_year = h.QueenYear, boxes = h.Boxes };

    private static object View(Inspection i) => new
    {
        id = i.Id, hive_id = i.HiveId, inspected_at = i.InspectedAt,
        brood_frames = i.BroodFrames, temperament = i.Temperament, remarks = i.Remarks,
    };

    public static void MapHives(this IEndpointRouteBuilder app)
    {
        app.MapGet("/hives", async (HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            var hives = await db.Hives.AsNoTracking().Where(h => h.OwnerId == me.Id).OrderBy(h => h.Id).ToListAsync(ct);
            return Results.Json(hives.Select(View));
        }).RequireSignIn();

        app.MapPost("/hives", async (HiveBody body, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            var check = new Check();
            var name = check.Text("name", body.Name, 1, 60);
            var year = check.Int("queen_year", body.QueenYear, 2000, DateTime.UtcNow.Year);
            var boxes = check.Int("boxes", body.Boxes, 1, 6);
            var yard = check.OptionalText("yard_location", body.YardLocation, 200);
            if (!check.Ok) return Failure.Invalid(check);

            if (await db.Hives.AnyAsync(h => h.OwnerId == me.Id && h.Name == name, ct))
                return Failure.Conflict("you already have a hive with that name");

            var hive = new Hive { OwnerId = me.Id, Name = name!, QueenYear = year, Boxes = boxes, YardLocation = yard };
            db.Hives.Add(hive);
            await db.SaveChangesAsync(ct);
            return Results.Json(View(hive), statusCode: 201);
        }).RequireSignIn();

        app.MapGet("/hives/{id:int}", async (int id, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            var hive = await db.Hives.AsNoTracking().FirstOrDefaultAsync(h => h.Id == id && h.OwnerId == me.Id, ct);
            return hive is null ? Failure.NotFound("hive") : Results.Json(View(hive));
        }).RequireSignIn();

        app.MapDelete("/hives/{id:int}", async (int id, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            await using var tx = await db.Database.BeginTransactionAsync(ct);
            var owned = db.Hives.Where(h => h.Id == id && h.OwnerId == me.Id);
            await db.Inspections.Where(i => owned.Any(h => h.Id == i.HiveId)).ExecuteDeleteAsync(ct);
            var gone = await owned.ExecuteDeleteAsync(ct);
            await tx.CommitAsync(ct);
            return gone == 0 ? Failure.NotFound("hive") : Results.NoContent();
        }).RequireSignIn();

        app.MapGet("/hives/{id:int}/inspections", async (int id, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            if (!await db.Hives.AnyAsync(h => h.Id == id && h.OwnerId == me.Id, ct)) return Failure.NotFound("hive");
            var rows = await db.Inspections.AsNoTracking().Where(i => i.HiveId == id)
                .OrderByDescending(i => i.InspectedAt).ThenByDescending(i => i.Id).ToListAsync(ct);
            return Results.Json(rows.Select(View));
        }).RequireSignIn();

        app.MapPost("/hives/{id:int}/inspections", async (int id, InspectionBody body, HttpContext http, ApiaryDb db, CancellationToken ct) =>
        {
            var me = Caller.Of(http);
            var check = new Check();
            var brood = check.Int("brood_frames", body.BroodFrames, 0, 20);
            var temper = check.Int("temperament", body.Temperament, 1, 5);
            var remarks = check.OptionalText("remarks", body.Remarks, 500);
            if (!check.Ok) return Failure.Invalid(check);

            if (!await db.Hives.AnyAsync(h => h.Id == id && h.OwnerId == me.Id, ct)) return Failure.NotFound("hive");
            var row = new Inspection { HiveId = id, InspectedAt = DateTime.UtcNow, BroodFrames = brood, Temperament = temper, Remarks = remarks };
            db.Inspections.Add(row);
            await db.SaveChangesAsync(ct);
            return Results.Json(View(row), statusCode: 201);
        }).RequireSignIn();
    }
}
