namespace Apiary.Http;

/// <summary>Every refusal the service sends, in one shape: <c>{"error": code, "detail": text, "fields": {...}}</c>.</summary>
public static class Failure
{
    private static IResult Make(int status, string code, string detail, object? fields = null) =>
        Results.Json(new { error = code, detail, fields }, statusCode: status);

    public static IResult Unauthorized(string detail) => Make(401, "unauthorized", detail);
    public static IResult Forbidden(string detail) => Make(403, "forbidden", detail);
    public static IResult NotFound(string what) => Make(404, "not_found", $"{what} not found");
    public static IResult Conflict(string detail) => Make(409, "conflict", detail);
    public static IResult Invalid(Check check) => Make(400, "invalid", "the request has missing or out-of-range values", check.Problems);
}

/// <summary>Collects what is wrong with a request body; an empty set means the body is acceptable.</summary>
public sealed class Check
{
    public Dictionary<string, string> Problems { get; } = new();

    public bool Ok => Problems.Count == 0;

    public string? Text(string field, string? value, int min, int max)
    {
        if (value is null) { Problems[field] = "is required"; return null; }
        var t = value.Trim();
        if (t.Length < min || t.Length > max) Problems[field] = $"must be {min} to {max} characters";
        return t;
    }

    public string? OptionalText(string field, string? value, int max)
    {
        if (value is null) return null;
        if (value.Length > max) Problems[field] = $"must be at most {max} characters";
        return value;
    }

    public int Int(string field, int? value, int min, int max)
    {
        if (value is null) { Problems[field] = "is required"; return 0; }
        if (value < min || value > max) Problems[field] = $"must be between {min} and {max}";
        return value.Value;
    }

    public double Number(string field, double? value, double min, double max)
    {
        if (value is null) { Problems[field] = "is required"; return 0; }
        if (double.IsNaN(value.Value) || value < min || value > max) Problems[field] = $"must be between {min} and {max}";
        return value.Value;
    }
}
