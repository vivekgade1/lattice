// dnbuild: the Shelf HTTP service.
using System.Text.Json;
using Microsoft.EntityFrameworkCore;

var port = Environment.GetEnvironmentVariable("PORT");
var path = Environment.GetEnvironmentVariable("DB_PATH");
if (string.IsNullOrEmpty(port) || string.IsNullOrEmpty(path))
{
    Console.Error.WriteLine("dnbuild: PORT and DB_PATH are required");
    return 2;
}

var builder = WebApplication.CreateSlimBuilder();
builder.WebHost.UseUrls("http://127.0.0.1:" + port);
builder.Logging.ClearProviders();
builder.Services.AddDbContext<ShelfDb>(o => o.UseSqlite("Data Source=" + path));
var app = builder.Build();

static IResult Err(int status, string detail) =>
    Results.Json(new Dictionary<string, string> { ["detail"] = detail }, statusCode: status);

static object Dto(Item i) => new Dictionary<string, object> { ["id"] = i.Id, ["name"] = i.Name, ["qty"] = i.Qty };

app.MapGet("/health", () => Results.Json(new Dictionary<string, bool> { ["ok"] = true }));

app.MapPost("/items", async (HttpRequest req, ShelfDb db) =>
{
    string? name;
    long qty;
    try
    {
        using var doc = await JsonDocument.ParseAsync(req.Body);
        var root = doc.RootElement;
        if (root.ValueKind != JsonValueKind.Object) return Err(422, "invalid body");
        if (!root.TryGetProperty("name", out var n) || n.ValueKind != JsonValueKind.String) return Err(422, "name is required");
        name = n.GetString();
        if (string.IsNullOrEmpty(name)) return Err(422, "name must not be empty");
        if (!root.TryGetProperty("qty", out var q) || q.ValueKind != JsonValueKind.Number || !q.TryGetInt64(out qty))
            return Err(422, "qty must be an integer");
        if (qty < 0) return Err(422, "qty must not be negative");
    }
    catch (JsonException)
    {
        return Err(422, "malformed body");
    }
    if (await db.Items.AnyAsync(i => i.Name == name)) return Err(409, "name already used");
    var item = new Item { Name = name!, Qty = qty };
    db.Items.Add(item);
    try { await db.SaveChangesAsync(); }
    catch (DbUpdateException) { return Err(409, "name already used"); }
    return Results.Json(Dto(item), statusCode: 201);
});

app.MapGet("/items", async (ShelfDb db) =>
{
    var items = await db.Items.AsNoTracking().OrderBy(i => i.Id).ToListAsync();
    return Results.Json(new Dictionary<string, object> { ["items"] = items.Select(Dto).ToList() });
});

app.MapGet("/items/{id}", async (string id, ShelfDb db) =>
{
    if (!long.TryParse(id, out var key)) return Err(422, "id must be an integer");
    var item = await db.Items.AsNoTracking().FirstOrDefaultAsync(i => i.Id == key);
    return item is null ? Err(404, "item not found") : Results.Json(Dto(item));
});

app.MapDelete("/items/{id}", async (string id, ShelfDb db) =>
{
    if (!long.TryParse(id, out var key)) return Err(422, "id must be an integer");
    var item = await db.Items.FirstOrDefaultAsync(i => i.Id == key);
    if (item is null) return Err(404, "item not found");
    db.Items.Remove(item);
    await db.SaveChangesAsync();
    return Results.Json(new Dictionary<string, bool> { ["ok"] = true });
});

app.Run();
return 0;

class Item
{
    public long Id { get; set; }
    public string Name { get; set; } = "";
    public long Qty { get; set; }
}

class ShelfDb : DbContext
{
    public ShelfDb(DbContextOptions<ShelfDb> options) : base(options) { }
    public DbSet<Item> Items => Set<Item>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Item>(e =>
        {
            e.ToTable("items");
            e.HasKey(i => i.Id);
            e.Property(i => i.Id).HasColumnName("id");
            e.Property(i => i.Name).HasColumnName("name");
            e.Property(i => i.Qty).HasColumnName("qty");
        });
    }
}
