# H-Streak: the Streak rule-shape set for Spike H (typed rule conditions)

Written 2026-10-18 by a separate author (a Claude Code subagent; no API key, no model calls)
for the Streak arm (PS0-PSx) registered in `docs/results/2026-10-17-typed-conditions-prereg.md`
section 3.3 ("`streak/`: the same files for Streak a0679e9 (rules picked from its 148)") and carried
by the round-2 (3.4) and round-3 (5.4) preregs. Nothing here was committed. Nothing was written
into `~/Documents/streak` or the main lattice checkout.

**App:** Streak `build/streak` at `a0679e9044486c98611febcd050a1fd23b6cd756`, taken with
`git -C ~/Documents/streak archive a0679e9` into scratch. Its own `REQUIREMENTS.md`, `spec.py` and
`spec.trace.json` are **the rules and the hand-written checks H**; they are not copied here (their
sha256 are in `source.sha256`). Rule ids are the trace's (148 rules, R1 and R2 context: 146 in scope).

**Library read (vocabulary only):** worktree `/Users/vivekgade/Documents/lattice-ha` (np-h-arm).

## What the author read, and did not read

Read: `docs/HANDOFF-2026-10-18.md`; the round-1/2/3 typed-conditions preregs (D1, D1', D1'', D3,
D4/D4'/D4'', D5, D6, Amendments); `2026-10-18-typed-conditions-streak-arm-results.md`; the archived
earlier sets `hshapes*.tgz` (development data; read for their file formats, README layout and JSON
shapes); Streak's `REQUIREMENTS.md`, `spec.py`, `spec.trace.json`, `CONTEXT.md`, `check.sh` and the Go
handlers under `internal/`. From `lattice/spec/forms.py` only the module docstring, the constant
lists (`NOT_EXPRESSIBLE`, `NOT_EXPR_NODES`, `NOT_EXPR_KEYS`), `canon`/`form_sha`, `norm_template`/
`known_templates` (what an Endpoint may be), `load_forms_file`/`coverage` (the forms file's
`not_expressible` key) and the list of function names; `rationale.anchor_of`/`norm_text`;
`impact_report.read_side` (what a candidate directory holds); the D/E author run recipe
(`scratchpad/e-planted/_work/run1.sh`).
Not read: the generator, type checker or contradiction code (`_Gen`, `_Checker`, `complete_row`,
`forms_tier2.py` bodies), `dogfood/forms_*`, `tests/spec/test_forms*`, any typed-conditions
results doc other than the Streak-arm one named above.
**The truth was written by hand from the English rules and the Go edits, never from a run.**

## Files

| file | content |
|---|---|
| `forms.json` | `lattice.forms/1`, source `REQUIREMENTS.md`: **43 approved forms over 23 rules** (34 bound, of which 5 column-only; 5 row_limit; 4 ownership; 0 transition), plus the forms file's `not_expressible` map for the other 123 in-scope rules (so `forms coverage` reads 0 `english`). Copy it as `REQUIREMENTS.forms.json` beside Streak's `REQUIREMENTS.md` |
| `classification.json` | all 146 in-scope rules: `expressible` true/false; formed rules with `coverage` (full/partial), their forms, what the forms state and what they leave out; the others with a D6 category and a reason |
| `handwritten.json` | per formed rule, H: the trace's `scenario:`/`invariant:` links of Streak's own `spec.py` (profile links listed apart, they are not checks) |
| `mutants.json`, `mutants/*.diff` | 29 Go mutants (25 aimed at formed rules, 4 controls aimed at not-formed rules), unified diffs under `internal/`, each with the patch's sha256 |
| `truth.json` | 23 formed rules x 30 apps (ok + 29 mutants) = 690 cells, `violates` + reason; flags `form_gap` and `k6` |
| `h_verdicts.json` | H (Streak's spec, the existing checker, layers ACD, Docker MySQL 8.4) run on all 30 apps; per cell pass/fail, failing elements, `h_incomplete` where H != truth; build/vet status per app |
| `author_check.json` | the author's own expansion of each form into scenarios/invariants (`_author_tools/author_spec.py`, by the author's reading of D1'/D3, not the library) run with the existing checker on all 30 apps, compared with truth. Not part of the set's scoring |
| `pairs.json` | 24 form pairs (13 contradictory, 11 compatible; classes a 8, b 5, c 5, e 6; no class d, see below), including **P9, the 50-vs-60 active-habit limit** |
| `candidates/{limit50,limit60,stated_twice}/REQUIREMENTS.forms.json` | the 50/60 pair as candidate forms files over the unchanged Streak spec (below) |
| `invalid.json` | 27 forms that must be refused, 19 distinct codes (F001-F009, F011-F019, F021) |
| `not_expressible.json` | all 123 not-formed rules with category and reason; 16 attempted forms (each must be refused F001/F017), 4 with a non-literal in an outcome `db` value |
| `source.sha256` | sha256 of Streak's REQUIREMENTS.md, spec.py, spec.trace.json, CONTEXT.md at a0679e9 |
| `_author_tools/` | the author's scripts (forms, classification, truth, mutants, pairs as Python data; the run scripts; the author expansion). Data only; nothing imports the library except the run of the checker |
| `MANIFEST.sha256` | `sha256sum` of every file above, sorted by path; `READY` marks completion |

## Layout (JSON shapes; the same as hshapes3 where the file exists there)

- **Form entry**: `{id, rule, anchor: sha256 of the rule's whitespace-normalised trace text
  (rationale.anchor_of), kind, form, status: "approved", author: "hand", approved_by:
  "streak-shapes-agent", approved_sha: sha256 of canon({kind, form})}`.
- `forms.json`: `{schema, source, forms: [entry], not_expressible: {rule: {category, reason}}}`.
- `mutants.json`: `{schema, base, apply, mutants: [{name, kind, rules (formed rules it aims at;
  [] for a control), aim, file, patch, patch_sha256}]}`. Apply: `git apply mutants/<name>.diff` in
  a fresh `git archive a0679e9` tree (no git repo needed), then `go build ./...`.
- `truth.json`: `{schema, apps, rules, cells: {rule: {app: {violates, reason, form_gap?, k6?}}}}`.
- `h_verdicts.json`: as hshapes3 (`cells: {rule: {app: {verdict, failing, h_incomplete, reason?}}}`,
  `elements_failing: {app: [element]}`) plus `build` per app; layers `ACD`.
- `pairs.json`: as hshapes3 (`{id, class, expect, forms: [entry], handwritten?: {name, scenario:
  {given, steps: [{method, path, user, json?, params?, expect_status}]}}, path_or_query_bound,
  witness, why}`).
- `invalid.json`, `not_expressible.json`: as hshapes3 (`app` is `"streak"`, `rule` a trace id).

**App names**: `ok`, then the 29 mutant names (truth/h_verdicts order).

## Conventions and reading of the rules

- **Endpoints** are written with named placeholders (`PATCH /v1/habits/{id}`,
  `POST /v1/habits/{habit_id}/completions`); `norm_template` maps them to the `{}` templates of
  Streak's scenario steps (Streak's spec has no contracts or programs, so no named template is known
  to the library; every form endpoint occurs in a hand-written step).
- **Callers** are `ann`, `ben` and `anon`; `ben` is the other user (CONTEXT.md).
- **Givens** carry every NOT NULL column (CONTEXT.md); a given habit has its `habit_targets` row;
  integer ids from 100, UUIDs `00000000-0000-4000-8000-0000000001NN`.
- **Row limits** give an explicit template row of the counted table: for F29 (R56) it matches the
  count (m = 1, so `below` needs 48 synthesised rows, `at_limit` 49); for F3, F28, F35 it does not
  match the locus (other email / name / date), so it only serves as a template; F33 (R69) gives the
  archived habit it restores (not counted).
- **`stores`** is named only where the request value is stored verbatim (name, description, period,
  target_count, note, platform, push_token, push_enabled); never for the password (stored hashed).
- **Error codes** (`habit_limit`, `not_found`, ...) are response-body values: no form states them,
  and a mutant that changed only a code would be invisible to every form (none of the 29 does).
- **One rule, several forms**: R51 has 8 forms, R31/R86 3, R9/R14/R28/R39/R42/R60/R92/R147 2.
- `R14`/`R19` use an `In` with one value: "any password but ann's", "any refresh token but the live
  one" (the given state has only that token). `R62` states the version comparison through the given
  row's version 1 (`eq 1`; the beyond value 2 or 0 is a stale version either way).

## Classification (146 in-scope rules)

formed **23** (16 %) ; not expressible **123**: time 32, other 21, response_shape 18, cross_table 13,
background 10, effect_value 9, cross_request 7, aggregate 5, external 5, rate 3.
(The PS0 prediction was formed 22-45 and not_expressible 40-70 with time and cross_request largest;
here every not-formed rule was classified, so the not-expressible count is the complement.)

Formed: R9, R10, R14, R19, R25, R28, R31, R33, R37, R39, R42, R51, R55, R56, R60, R62, R69, R77, R78,
R86, R92, R137, R147 (full: R14, R56, R77, R78; the rest partial, see `classification.json`).

### Findings about the form language on Streak (stated, not guessed)

1. **No transition is expressible.** Streak's only `Machine` is `Nudge.delivery` (pending ->
   sent|failed|suppressed). Its edges are taken only by the background nudger's daily pass
   (R124, R127-R134: `background`). The "unchanged" edges a request causes (a check-in rewrite keeps
   the delivery, R123; a dismissal keeps it, R141) would need a `to: null` transition whose nudge row
   has a parent habit: rule C must fill `nudges.habit_id` from a given habits row, and the
   transition kind has no `given` (D1). So R123/R141 are `cross_table`/`external`; `invalid.json`
   I2 (transition with `given`: F001) and I27 (a well-typed transition on a real edge: F021) are the
   two concrete probes of that claim. Hence `pairs.json` has no class d pair.
2. **Ownership forms cover only body-less endpoints.** An ownership form has no request body, so
   PATCH habit, POST check-in, the batch and the two-id check-in delete cannot be named. R28's forms
   cover GET/DELETE habit, progress, history, the check-in list, dismiss and device delete; mutant
   `m_patch_habit_any_owner` is a planned `form_gap` cell.
3. **Column-only bounds** (R37, R39, R42; class K6) are invariants only. `m_platform_unchecked`
   makes R37's violated state reachable (the R31 `beyond` case and H's `device_registration` both
   store a bad platform), so it tests whether G evaluates F15 on states other cases reach.
4. **Case-insensitive uniqueness** (R10, R55) is outside a count bound (exact matches):
   `m_name_taken_case_sensitive` is a planned `form_gap` cell for R55.

## Truth (690 cells)

34 of 690 cells are violated, 0 on `ok` (every formed rule holds on a0679e9). Flags:
- `form_gap` (3 cells, the violated part is outside what the rule's forms state):
  R28 x `m_patch_habit_any_owner` (ownership has no request body), R55 x
  `m_name_taken_case_sensitive` (case folding), R60 x `m_description_max_499` (R60's forms state
  name and weekly target on PATCH, not description). A correct G misses these by construction.
- `k6` (90 cells: every cell of R37, R39, R42); one is violated: R37 x `m_platform_unchecked`.
- Correction made **before** the manifest: R56 x `m_restore_limit_skipped` was first written
  `violates: false`; the author's own check (below) failed R56's count invariant on that app, and on
  re-reading R56 ("A user has at most 50 active habits") the state rule is broken by a restore to 51,
  so the cell was changed to `true`. It is the only truth edit made after a run; G sees it only if
  R56's generated count invariant is evaluated on the states of R69's generated `at_limit` case.

Violated cells per rule: R56 3, R69 3, R51 3, R60 3 (1 gap), R28 4 (1 gap), R31 2, R55 2 (1 gap),
R9, R10, R14, R19, R25, R33, R37, R62, R77, R78, R86, R92, R137, R147 1 each; R39, R42 0.

## The 50-vs-60 pair (PS2)

`pairs.json` P9: F29 (R56, `max 50`) and F111 (the same row_limit with `max 60`), class b,
contradictory, witness: 50 counted active habits and ann's create. As candidate specs that differ
only in the limit, all over the unchanged Streak a0679e9 `REQUIREMENTS.md`/`spec.py`/`spec.trace.json`
(so the anchors stay `current`):

- `candidates/limit50/REQUIREMENTS.forms.json`: F29 alone (max 50);
- `candidates/limit60/REQUIREMENTS.forms.json`: F29 with max 60 (byte-identical otherwise);
- `candidates/stated_twice/REQUIREMENTS.forms.json`: F29 (50) and F44 (60) on R56.

`forms contradictions` on `stated_twice` should determine exactly the 50/60 item; `lattice spec impact
--project <archive + limit50 forms> --candidate <archive + stated_twice forms> --tiers 23 --json`
should gain it in `tier2.determined` (the candidate's item, absent from the base). An English
variant (R56/R69/G10/M17 saying 60) is **not** provided: it would need a re-extracted trace (the
anchors of R56 and R69 change), and the author does not write Streak trace files.

## Mutants

All 29 apply with `git apply --check` on a fresh `git archive a0679e9` tree, each alone, and pass
`go build ./...` and `go vet ./...` (recorded per app in `h_verdicts.json` `build`). Columns: truth =
formed rules violated; H = formed rules whose linked hand-written elements fail (Streak spec, ACD);
author-G = formed rules whose author-expanded form checks fail. The 4 controls violate no formed
rule (each is caught by some other hand-written scenario of Streak's spec, as expected).
D's change-set reference diffs (reversed) are **not** included: D's 21-change set is itself not
run, and none is needed for the >= 10 minimum.

| mutant | kind | intent | truth (violated formed rules) | H fails | author-G fails |
|---|---|---|---|---|---|
| `m_habit_limit_gt` | row_limit | the shared active-habit limit check lets the count reach 51 (>= becomes >) | R56, R69 | R56, R69 | R56, R69 |
| `m_habit_limit_49` | row_limit | the active-habit limit constant is 49, so the 50th active habit is refused | R56, R69 | R56 | R56, R69 |
| `m_restore_limit_skipped` | row_limit | restoring an archived habit no longer checks the active-habit limit | R56, R69 | R56, R69 | R56, R69 |
| `m_name_max_101` | bound | a habit name of 101 characters is accepted (create and rename share the check) | R51, R60 | R51 | R51, R60 |
| `m_description_max_499` | bound | a description of exactly 500 characters is refused (create and patch share the check) | R51, R60 | R51 | R51 |
| `m_target_week_max_8` | bound | a weekly target_count of 8 is accepted on create and patch | R51, R60 | R51 | R51, R60 |
| `m_note_max_281` | bound | a check-in note of 281 characters is accepted | R77 | R77 | R77 |
| `m_list_limit_max_201` | bound | every cursor list (habits, check-ins, nudges) accepts ?limit=201 | R86, R137 | R86, R137 | R86, R137 |
| `m_sync_limit_min_0` | bound | GET /v1/sync accepts ?limit=0 | R92 | R92 | R92 |
| `m_history_limit_max_101` | bound | GET /v1/habits/{id}/history accepts ?limit=101 | R147 | R147 | R147 |
| `m_checkin_same_day_twice` | row_limit | a second non-deleted check-in on the same date with a new id is stored | R78 | R78 | R78 |
| `m_name_taken_case_sensitive` | row_limit | habit names are compared case-sensitively for uniqueness (Run and run no longer conflict) | R55 | R55 | - |
| `m_name_taken_create_skipped` | row_limit | POST /v1/habits no longer checks for a duplicate name (rename still does) | R55 | R55 | R55 |
| `m_get_habit_any_owner` | ownership | GET /v1/habits/{id} loads the habit by id without the owner filter | R28 | R28 | R28 |
| `m_patch_habit_any_owner` | ownership | PATCH /v1/habits/{id} changes another user's habit (the owner filter is dropped) | R28 | R28 | - |
| `m_dismiss_any_owner` | ownership | POST /v1/nudges/{id}/dismiss dismisses another user's nudge | R28 | R28 | R28 |
| `m_delete_device_any_owner` | ownership | DELETE /v1/devices/{id} deletes the row whoever owns it | R28, R33 | R28 | R28, R33 |
| `m_rewrite_resets_delivery` | control | control on a not-formed rule (R123): a check-in that rewrites today's nudge also resets its delivery to pending | - (none) | - | - |
| `m_dismiss_marks_suppressed` | control | control on a not-formed rule (R141): a dismissal also sets the nudge's delivery to suppressed with reason dismissed | - (none) | - | - |
| `m_patch_version_ignored` | bound | PATCH applies the change whatever version the body names | R62 | R60, R62 | R62 |
| `m_password_min_7` | bound | a 7-byte password is accepted at registration | R9 | R9 | R9 |
| `m_platform_unchecked` | bound | POST /v1/devices stores any platform string | R31, R37 | R31 | R31, R37 |
| `m_push_token_max_4097` | bound | a push_token of 4097 characters is accepted | R31 | R31 | R31 |
| `m_email_taken_422` | row_limit | registering an email that is already registered answers 422 instead of 409 | R10 | R10 | R10 |
| `m_login_skip_password` | bound | login accepts any non-empty password for a known email | R14 | R14 | R14 |
| `m_refresh_unknown_422` | bound | an unknown refresh token answers 422 instead of 401 | R19 | R19 | R19 |
| `m_push_enabled_lenient` | bound | PUT /v1/me with a non-boolean push_enabled stores false and answers 200 | R25 | R25 | R25 |
| `m_date_too_old_59` | control | control on a not-formed rule (R75): a check-in dated t-60 is refused as date_too_old | - (none) | - | - |
| `m_behind_one_decimal` | control | control on a not-formed rule (R117): the behind message writes rates with one decimal | - (none) | - | - |


## H (Streak's own checks) and the author's check

**H** (`h_verdicts.json`): agrees with truth on 683 of 690 cells; 7 `h_incomplete`:
R33 x `m_delete_device_any_owner` (ben's delete is linked to R28 only), R37 x `m_platform_unchecked`
(no invariant on devices.platform), R60 x `m_name_max_101` / `m_description_max_499` /
`m_target_week_max_8` (PATCH validation is linked to R5/R7, not R60), R69 x `m_habit_limit_49` (H
tests the restore only at 50) — H misses; and R60 x `m_patch_version_ignored` (H fails because
`patch_version_rules` is linked to both R60 and R62; the version rule is R62's). On `ok` no
hand-written element fails (verdict pass, 480 cases, about 29 s per run; the controls take up to 88 s
because their failing `Await`s wait out their 30 s windows).

**Author's check** (`author_check.json`, not part of the scoring): the author expanded every form
by their own reading of D1'/D3 into 92 scenarios and 9 invariants added to Streak's SPEC (layers CD).
On `ok` all pass. Against truth: 687 of 690 cells agree; the 3 misses are exactly the 3 `form_gap`
cells; 0 false fails. (A library G may differ: it synthesises its own rows, derives loci and accepted
statuses, and may report hand-written invariants inside generated scenarios.)

## Ambiguities and risks (for the orchestrator)

1. **Expressible means "formed with coverage"**: 19 of the 23 formed rules are `partial`
   (`classification.json` says what is left out). PS0 counts them as formed; a stricter reading
   (only `full`: R14, R56, R77, R78) would give 4.
2. **No transition forms** (finding 1 above). The commission named "nudge delivery state machine
   edges" as an example; the author judged them not expressible. If the orchestrator rules that a
   transition may carry `given` (a D1 change, a new prereg), R123 and R141 become formable.
3. **R60 "the same validation as creation applies"** is read as "creation's bounds (R51) apply to
   PATCH", so a mutant that changes a shared bound violates both R51 and R60.
4. **R56 is a state rule** ("at most 50 active"), so any route to a 51st active habit violates it
   (the correction above). R69's restore limit is the same count; P10 (F29 vs F33, both 50) is
   compatible, P11 (F33 50 vs 60) contradictory.
5. **R62 and R14/R19 forms state the rule through the witness** (version 1; ann's password; the one
   live token). They are true instances, not the general comparison.
6. **Synthesised rows**: F29 needs 48/49 synthesised habits with distinct names (R55's form counts
   by name; round-3 ruling (c) asks for distinct values) and UUID keys; F3 a synthesised users row
   (email bound from the witness). If the generator cannot make UUID keys or valid DATE/DATETIME
   values (CONTEXT.md: every NOT NULL column), that is a library limitation, not a truth question;
   every row-limit form gives a full template row to help.
7. **Locus of `db: unchanged`**: several refusals have no path placeholder and no given row
   (register, login, list limits); only `stores` (where given) or the given rows make "unchanged"
   checkable. Truth does not depend on it (no mutant writes on those refusals except
   `m_push_enabled_lenient`, whose F7 names `stores: NotificationPrefs.push_enabled`).
8. **Hand-written invariants inside generated cases**: Streak's invariants (e.g.
   `nudge_reason_matches_delivery`, `habit_name_not_empty`, `habit_target_in_bounds`) will be
   evaluated on generated givens; a template-free synthesised row with typed-zero values (name "",
   target_count 0) would trip them on `ok`. The templates here are valid rows.
9. **Error codes are not expressible** anywhere (Outcome has a status, no body); no mutant changes a
   code alone, so no cell depends on it.
10. **Runner**: no frozen runner has a Streak stage (results doc 4.3); these files assume a new
   runner that builds `bin/streak-api` per mutant, runs CD with and without G on MySQL, and reads
   this layout. The `candidates/` assume the runner copies a forms file beside an archive tree.
