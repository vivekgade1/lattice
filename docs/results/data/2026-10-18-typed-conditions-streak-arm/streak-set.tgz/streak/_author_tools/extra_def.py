"""pairs.json, invalid.json and not_expressible.json attempts for Streak (hand-written)."""

import copy

from forms_def import FORMS, H100, H100_FEB, NEW_HABIT, UNCH, habit, nudge, target, u

BY_ID = {f[0]: f for f in FORMS}


def fx(fid, new_id, **changes):
    """A copy of form fid as (new_id, rule, kind, form) with top-level form keys replaced."""
    _, rule, kind, form = BY_ID[fid]
    form = copy.deepcopy(form)
    for k, v in changes.items():
        if v is None:
            form.pop(k, None)
        else:
            form[k] = v
    return (new_id, rule, kind, form)


def with_cond(fid, new_id, cond, **more):
    return fx(fid, new_id, cond=cond, **more)


# ---- pairs ---------------------------------------------------------------------------------
# (id, class, expect, [form tuples or form ids], handwritten|None, path_or_query_bound, witness, why)
HABIT_HIST_1 = {"method": "GET", "path": f"/v1/habits/{u(100)}/history", "user": "ann",
                "params": {"limit": 1}}
PAIRS = [
    ("P1", "a", "contradictory", ["F20", with_cond("F20", "F101", {"op": "min_len", "value": 101})],
     None, False, {"field": "body.name", "value": "a 100- or 101-character name"},
     "name length <= 100 and >= 101: no length satisfies both"),
    ("P2", "a", "compatible", ["F20", with_cond("F20", "F102", {"op": "min_len", "value": 100})],
     None, False, {"field": "body.name", "value": "a 100-character name"},
     "<= 100 and >= 100 meet at exactly 100 characters"),
    ("P3", "a", "contradictory", ["F37", with_cond("F37", "F103", {"op": "ge", "value": 201})],
     None, True, {"field": "query.limit", "value": 200},
     "GET /v1/habits ?limit <= 200 and >= 201 on an INT: empty"),
    ("P4", "a", "compatible", ["F25", with_cond("F25", "F104", {"op": "ge", "value": 7})],
     None, False, {"field": "body.target_count", "value": 7},
     "target_count <= 7 and >= 7 meet at 7"),
    ("P5", "a", "contradictory", ["F24", with_cond("F24", "F105", {"node": "Cmp", "op": "lt", "value": 1})],
     None, False, {"field": "body.target_count", "value": 1},
     "target_count >= 1 and < 1: empty"),
    ("P6", "a", "compatible", [with_cond("F25", "F106", {"op": "gt", "value": 6}),
                               with_cond("F25", "F107", {"op": "lt", "value": 8})],
     None, False, {"field": "body.target_count", "value": 7},
     "on an INT, > 6 and < 8 leave exactly 7 (near miss of an empty FLOAT-style reading)"),
    ("P7", "a", "contradictory", [with_cond("F11", "F108", {"values": ["android"]}),
                                  with_cond("F11", "F109", {"values": ["ios"]})],
     None, False, {"field": "body.platform", "value": "android"},
     "platform in {android} and in {ios}: disjoint"),
    ("P8", "a", "compatible", ["F11", with_cond("F11", "F110", {"values": ["ios"]})],
     None, False, {"field": "body.platform", "value": "ios"},
     "{android, ios} and {ios} share ios"),
    ("P9", "b", "contradictory", ["F29", fx("F29", "F111", max=60)],
     None, False, {"counted_rows": 50, "request": {"method": "POST", "path": "/v1/habits",
                                                    "user": "ann"}},
     "THE 50-vs-60 PAIR: R56's active-habit limit stated twice, 50 and 60, on the same (Habit, "
     "[user_id], active) count: with 50 active habits the 60-form accepts the create the "
     "50-form refuses"),
    ("P10", "b", "compatible", ["F29", "F33"], None, False,
     {"counted_rows": 50},
     "the same count with the same limit (50) through two endpoints (create, restore)"),
    ("P11", "b", "contradictory", ["F33", fx("F33", "F112", max=60)], None, False,
     {"counted_rows": 50, "request": {"method": "PATCH", "path": f"/v1/habits/{u(151)}",
                                      "user": "ann"}},
     "restore limit stated as 50 and 60 on the same count"),
    ("P12", "b", "compatible", ["F28", "F29"], None, False, {"counted_rows": 1},
     "different counts (by [user_id, name] vs by [user_id]): both hold together"),
    ("P13", "b", "contradictory", ["F35", fx("F35", "F113", max=2)], None, False,
     {"counted_rows": 1, "request": {"method": "POST",
                                     "path": f"/v1/habits/{u(100)}/completions", "user": "ann"}},
     "one vs two check-ins per (habit, date): with one stored, the 2-form accepts what the "
     "1-form refuses"),
    ("P14", "c", "contradictory", ["F10", fx("F10", "F114", refused_other=UNCH(403))], None, False,
     {"request": {"method": "DELETE", "path": "/v1/devices/100", "user": "ben"}},
     "another user's device delete: 404 vs 403"),
    ("P15", "c", "compatible", ["F10", "F14"], None, False,
     {"request": {"method": "DELETE", "path": "/v1/devices/100", "user": "ben"}},
     "scope owner(user_id) and owner name the same owner column (devices.user_id); same statuses"),
    ("P16", "c", "contradictory", ["F9", fx("F9", "F115", scope="any")], None, False,
     {"request": {"method": "POST", "path": f"/v1/nudges/{u(500)}/dismiss", "user": "ben"}},
     "owner-only vs anyone: ben's dismiss of ann's nudge is 404 in one, allowed in the other"),
    ("P17", "c", "compatible", ["F8", fx("F8", "F116", endpoints=["GET /v1/habits/{id}"],
                                         accepted={"GET /v1/habits/{id}": {"status": 200}})],
     None, False, {"request": {"method": "GET", "path": f"/v1/habits/{u(100)}", "user": "ben"}},
     "a sub-set of the endpoints with the same statuses"),
    ("P18", "c", "contradictory", ["F8", fx("F8", "F117", endpoints=["GET /v1/habits/{id}"],
                                            accepted={"GET /v1/habits/{id}": {"status": 200}},
                                            refused_anon=UNCH(403))],
     None, False, {"request": {"method": "GET", "path": f"/v1/habits/{u(100)}", "user": None}},
     "an anonymous read of the habit: 401 vs 403"),
    ("P19", "e", "contradictory", ["F25"],
     {"name": "hs target 7 a week is refused",
      "scenario": {"given": None, "steps": [
          {"method": "POST", "path": "/v1/habits", "user": "ann",
           "json": {**NEW_HABIT, "target_count": 7}, "expect_status": 422}]}},
     False, {"request": {"method": "POST", "path": "/v1/habits", "user": "ann",
                         "json": {**NEW_HABIT, "target_count": 7}}},
     "F25's at_bound sends this exact request and expects 201; the hand-written step expects 422"),
    ("P20", "e", "compatible", ["F25"],
     {"name": "hs target 7 a week is accepted",
      "scenario": {"given": None, "steps": [
          {"method": "POST", "path": "/v1/habits", "user": "ann",
           "json": {**NEW_HABIT, "target_count": 7}, "expect_status": 201}]}},
     False, {"request": {"method": "POST", "path": "/v1/habits", "user": "ann",
                         "json": {**NEW_HABIT, "target_count": 7}}},
     "the same request, the same expectation"),
    ("P21", "e", "contradictory", ["F21", fx("F21", "F118", accepted={"status": 200})], None, False,
     {"request": {"method": "POST", "path": "/v1/habits", "user": "ann",
                  "json": "the witness with a 1-character name"}},
     "the same bound and witness: both at_bound cases send the same request; 201 vs 200"),
    ("P22", "e", "compatible", ["F20", "F21"], None, False,
     {"request": {"method": "POST", "path": "/v1/habits", "user": "ann"}},
     "the two cases never send the same request (lengths 100/101 vs 1/0)"),
    ("P23", "e", "contradictory", ["F42"],
     {"name": "hs history limit 1 is refused",
      "scenario": {"given": H100_FEB, "steps": [{**HABIT_HIST_1, "expect_status": 422}]}},
     True, {"request": HABIT_HIST_1},
     "F42's at_bound (limit 1, same given) expects 200; the hand-written step expects 422"),
    ("P24", "e", "compatible", ["F42"],
     {"name": "hs history limit 0 is refused",
      "scenario": {"given": H100_FEB, "steps": [
          {**HABIT_HIST_1, "params": {"limit": 0}, "expect_status": 422}]}},
     True, {"request": {**HABIT_HIST_1, "params": {"limit": 0}}},
     "F42's beyond case (limit 0) also expects 422"),
]

# ---- invalid forms --------------------------------------------------------------------------
INVALID = [
    ("I1", "F001", "unknown key `between` on a bound",
     [fx("F25", "F201", between=[1, 7])]),
    ("I2", "F001", "a transition carries `given` (not a key of the transition kind)",
     [("F202", "R123", "transition", {
         "machine": "Nudge.delivery", "trigger": "POST /v1/habits/{habit_id}/completions",
         "caller": "ann", "request": {"path": f"/v1/habits/{u(100)}/completions",
                                      "json": {"id": u(301), "date": "2026-03-03"}},
         "given": {**H100, "nudges": [nudge(500, 100)]},
         "row": {"id": u(500)}, "from": ["failed", "pending", "sent", "suppressed"], "to": None,
         "accepted": {"status": 201}, "refused": UNCH(409)})]),
    ("I3", "F002", "unknown column Habit.colour",
     [("F203", "R39", "bound", {"field": {"column": "Habit.colour"},
                                "cond": {"values": ["red"]}, "refused": UNCH(422)})]),
    ("I4", "F002", "unknown table Streaks in a row_limit",
     [fx("F29", "F204", table="Streaks")]),
    ("I5", "F003", "unknown endpoint template POST /v1/habit",
     [fx("F25", "F205", endpoint="POST /v1/habit",
         field={"param": "POST /v1/habit", "path": "body.target_count"},
         request={"path": "/v1/habit", "json": NEW_HABIT})]),
    ("I6", "F004", "a float literal for an INT column bound",
     [("F206", "R39", "bound", {"field": {"column": "Habit.version"},
                                "cond": {"op": "ge", "value": 1.5}, "refused": UNCH(422)})]),
    ("I7", "F004", "a string literal for a BOOL column in a row_limit where",
     [fx("F29", "F207", where={"archived": "no", "deleted_at": None})]),
    ("I8", "F005", "an In value outside Habit.period's one_of",
     [("F208", "R39", "bound", {"field": {"column": "Habit.period"},
                                "cond": {"values": ["day", "week"]}, "refused": UNCH(422)})]),
    ("I9", "F006", "ordering a one_of column (Nudge.kind >= 'behind')",
     [("F209", "R42", "bound", {"field": {"column": "Nudge.kind"},
                                "cond": {"op": "ge", "value": "behind"}, "refused": UNCH(422)})]),
    ("I10", "F007", "unknown caller handle cara",
     [fx("F20", "F210", caller="cara")]),
    ("I11", "F007", "unknown other handle in an ownership form",
     [fx("F10", "F211", other="zed")]),
    ("I12", "F008", "unknown machine Habit.archived",
     [("F212", "R69", "transition", {
         "machine": "Habit.archived", "trigger": "PATCH /v1/habits/{id}", "caller": "ann",
         "request": {"path": f"/v1/habits/{u(100)}", "json": {"version": 1, "archived": True}},
         "row": {"id": u(100)}, "from": [False], "to": True,
         "accepted": {"status": 200}, "refused": UNCH(409)})]),
    ("I13", "F008", "unknown state 'dismissed' of Nudge.delivery",
     [("F213", "R141", "transition", {
         "machine": "Nudge.delivery", "trigger": "POST /v1/nudges/{id}/dismiss", "caller": "ann",
         "request": {"path": f"/v1/nudges/{u(500)}/dismiss"}, "row": {"id": u(500)},
         "from": ["pending"], "to": "dismissed",
         "accepted": {"status": 200}, "refused": UNCH(409)})]),
    ("I14", "F009", "an empty `from`",
     [("F214", "R141", "transition", {
         "machine": "Nudge.delivery", "trigger": "POST /v1/nudges/{id}/dismiss", "caller": "ann",
         "request": {"path": f"/v1/nudges/{u(500)}/dismiss"}, "row": {"id": u(500)},
         "from": [], "to": "sent", "accepted": {"status": 200}, "refused": UNCH(409)})]),
    ("I15", "F011", "row_limit max 0",
     [fx("F29", "F215", max=0)]),
    ("I16", "F011", "a negative length",
     [with_cond("F34", "F216", {"op": "max_len", "value": -1})]),
    ("I17", "F012", "where on a column not in the counted table",
     [fx("F35", "F217", where={"deleted_at": None, "kind": "behind"})]),
    ("I18", "F013", "an ownership scope on a table with neither owner nor owner_via (TestClock)",
     [("F218", "R28", "ownership", {
         "table": "TestClock", "scope": "owner", "endpoints": ["PUT /test/clock"],
         "owner": "ann", "other": "ben", "row": 1,
         "refused_other": UNCH(404), "refused_anon": UNCH(401)})]),
    ("I19", "F014", "a witness path that does not match the endpoint template",
     [fx("F34", "F219", request={"path": f"/v1/habit/{u(100)}/checkins",
                                  "json": {"id": u(300), "date": "2026-03-02", "note": "n"}})]),
    ("I20", "F015", "two forms with the same id",
     [fx("F36", "F220"), fx("F37", "F220")]),
    ("I21", "F016", "a form for a rule that is not in the trace (R999)",
     [("F221", "R999", "bound", {"field": {"column": "Habit.version"},
                                 "cond": {"op": "ge", "value": 1}, "refused": UNCH(422)})]),
    ("I22", "F017", "a non-literal value (`today`) in a bound's condition",
     [with_cond("F25", "F222", {"op": "le", "value": {"today": True}})]),
    ("I23", "F017", "a `within` key (a duration) on a row_limit",
     [fx("F29", "F223", within={"days": 1})]),
    ("I24", "F018", "an Outcome status outside 100..599",
     [fx("F25", "F224", refused={"status": 700, "db": "unchanged"})]),
    ("I25", "F019", "an edge (sent -> pending) the spec's Machine does not have (Machine edges: "
     "pending -> sent|failed|suppressed); F021 may be reported as well (no parent habit row)",
     [("F225", "R123", "transition", {
         "machine": "Nudge.delivery", "trigger": "POST /v1/nudges/{id}/dismiss", "caller": "ann",
         "request": {"path": f"/v1/nudges/{u(500)}/dismiss"}, "row": {"id": u(500)},
         "from": ["sent"], "to": "pending", "accepted": {"status": 200},
         "refused": UNCH(409)})]),
    ("I26", "F021", "a row_limit whose `by` column (note) cannot be bound: not in the witness, "
     "not a foreign key to the path's table, not the owner column",
     [fx("F35", "F226", by=["habit_id", "note"])]),
    ("I27", "F021", "a well-typed Nudge.delivery transition on an edge the Machine has (pending "
     "-> suppressed): the nudge row cannot be completed, its habit_id needs a habits row and a "
     "transition has no given (the author's reason why R123/R141/R124-R134 are not formed)",
     [("F227", "R141", "transition", {
         "machine": "Nudge.delivery", "trigger": "POST /v1/nudges/{id}/dismiss", "caller": "ann",
         "request": {"path": f"/v1/nudges/{u(500)}/dismiss"}, "row": {"id": u(500)},
         "from": ["pending"], "to": "suppressed", "accepted": {"status": 200},
         "refused": UNCH(409)})]),
]

# ---- not-expressible attempts (each must be refused with F001 or F017) ------------------------
ATTEMPTS = {
    "R73": (with_cond("F34", "F301", {"op": "le", "value": {"today": True}},
                      field={"param": "POST /v1/habits/{habit_id}/completions",
                             "path": "body.date"}, stores=None), False),
    "R75": (with_cond("F34", "F302", {"op": "ge", "value": {"sub": [{"today": True}, 60]}},
                      field={"param": "POST /v1/habits/{habit_id}/completions",
                             "path": "body.date"}, stores=None), False),
    "R29": (fx("F29", "F303", per="minute", max=120, table="Habit"), False),
    "R123": ((INVALID[1][3][0][0].replace("F202", "F304"),) + INVALID[1][3][0][1:], False),
    "R141": (fx("F9", "F305", push={"on": "dismiss", "fails": True}), False),
    "R8": (fx("F1", "F306", accepted={"status": 201, "db": {"equals": {
        "email": {"lower": {"param": "body.email"}}}}}), True),
    "R71": (fx("F20", "F307", accepted={"status": 201, "db": {"equals": {
        "change_seq": {"add": [{"column": "User.change_seq"}, 1]}}}}), True),
    "R115": (fx("F34", "F308", accepted={"status": 201, "db": {"equals": {
        "message": {"format": "Behind: do {needed} more"}}}}), True),
    "R57": (fx("F20", "F309", accepted={"status": 201, "db": {"equals": {
        "target_count": {"column": "HabitTarget.target_count"}}}}), True),
    "R52": (with_cond("F20", "F310", {"op": "ge", "value": {"column": "Habit.start_date"}},
                      field={"param": "POST /v1/habits", "path": "body.end_date"}, stores=None),
            False),
    "R80": (fx("F34", "F311", join={"Habit.archived": False}), False),
    "R83": (with_cond("F34", "F312", {"op": "max_items", "value": 100},
                      field={"param": "POST /v1/completions/batch", "path": "body.items"},
                      endpoint="POST /v1/completions/batch", stores=None, given=None,
                      request={"path": "/v1/completions/batch",
                               "json": {"items": [{"id": u(300), "habit_id": u(100),
                                                   "date": "2026-03-02"}]}}), False),
    "R126": (("F313", "R126", "row_limit", {
        "table": "Nudge", "by": ["habit_id", "for_date"], "max": 1, "within": {"minutes": 1},
        "endpoint": "POST /v1/habits/{habit_id}/completions", "caller": "ann",
        "request": {"path": f"/v1/habits/{u(100)}/completions",
                    "json": {"id": u(301), "date": "2026-03-03"}},
        "refused": UNCH(409)}), False),
    "R98": (with_cond("F26", "F314", {"op": "le", "value": {"sum": [{"column": "Habit.target_count"}]}}),
            False),
    "R135": (("F315", "R135", "row_limit", {
        "table": "Nudge", "by": ["habit_id"], "where": {"delivery": "sent"}, "max": 3,
        "per": "day", "endpoint": "POST /v1/nudges/{id}/dismiss", "caller": "ann",
        "request": {"path": f"/v1/nudges/{u(500)}/dismiss"}, "refused": UNCH(409)}), False),
    "R138": (fx("F9", "F316", then={"POST /v1/nudges/{id}/dismiss": {"status": 409}}), False),
}
