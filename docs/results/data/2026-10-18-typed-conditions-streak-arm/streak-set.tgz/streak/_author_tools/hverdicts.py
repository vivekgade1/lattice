"""h_verdicts.json (Streak's own hand-written checks, runs/<app>/acd.json) and author_check.json
(the author's expansion of the forms, runs_author/<app>/cd.json), both against truth.json.
Run with PYTHONPATH=<a Streak tree>:<lattice>:<tools> so `spec` and `author_spec` import."""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import author_spec  # noqa: E402

W = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(os.path.dirname(W), "streak")
truth = json.load(open(os.path.join(OUT, "truth.json")))
hw = json.load(open(os.path.join(OUT, "handwritten.json")))["rules"]
SENT = {i.sentence if hasattr(i, "sentence") else i.text: i.name
        for i in author_spec.SPEC.invariants}
for i in author_spec.SPEC.invariants:
    for attr in ("sentence", "text", "description"):
        if hasattr(i, attr):
            SENT[getattr(i, attr)] = i.name


def elements(report):
    out = set()
    for f in report["findings"]:
        r = f.get("rule") or ""
        if r.startswith("scenario: "):
            out.add("scenario:" + r[len("scenario: "):])
        elif r.startswith("invariant: "):
            out.add("invariant:" + r[len("invariant: "):])
        elif f.get("layer") == "C" and r in SENT:
            out.add("invariant:" + SENT[r])
        elif r:
            out.add(f"{f.get('layer')}:" + r)
        for v in f.get("invariant_violations") or []:
            if isinstance(v, dict) and v.get("invariant"):
                out.add("invariant:" + v["invariant"])
    return out


def load(path):
    with open(path) as fh:
        return json.load(fh)


apps, rules = truth["apps"], truth["rules"]
H, A = {}, {}
efail, afail, status = {}, {}, {}
for a in apps:
    rep = load(os.path.join(W, "runs", a, "acd.json"))
    st = open(os.path.join(W, "runs", a, "status")).read().split()
    status[a] = dict(x.split("=") for x in st)
    efail[a] = sorted(elements(rep))
    arep = load(os.path.join(W, "runs_author", a, "cd.json"))
    afail[a] = sorted(e for e in elements(arep) if "author" in e)
cells = {}
nh = {"agree": 0, "h_incomplete": 0}
for r in rules:
    cells[r] = {}
    linked = set(hw[r]["elements"])
    for a in apps:
        failing = sorted(linked & set(efail[a]))
        verdict = "fail" if failing else "pass"
        t = truth["cells"][r][a]["violates"]
        c = {"verdict": verdict, "failing": failing, "h_incomplete": (verdict == "fail") != t}
        if c["h_incomplete"]:
            c["reason"] = ("the rule is violated (truth) but none of its linked hand-written "
                           "elements fails" if t else
                           "a linked hand-written element fails although the rule holds (truth)")
            nh["h_incomplete"] += 1
        else:
            nh["agree"] += 1
        cells[r][a] = c
json.dump({
    "schema": "hstreak.h_verdicts/1", "layers": "ACD",
    "run": "python -m lattice.spec check --spec spec:SPEC --app harness:make_app --db "
           "harness:build_db --runtime harness:RUNTIME --login harness:login --services "
           "harness:SERVICES --database mysql --layers ACD --go-src <tree> --json, per app on a "
           "fresh git archive of a0679e9 with the mutant's diff applied (Docker mysql:8.4, "
           "LATTICE_CONTAINER_OWNER=h-streak-author); a rule fails when a finding names one of "
           "its linked scenario:/invariant: elements (C findings mapped by sentence)",
    "library": "lattice-ha np-h-arm (next-phases 978b468 + results doc)",
    "apps": apps, "rules": rules, "summary": nh, "cells": cells,
    "elements_failing": efail,
    "build": {a: status[a] for a in apps}}, open(os.path.join(OUT, "h_verdicts.json"), "w"),
    indent=1)
# the author's own check
FORM_RULE = {f[0]: f[1] for f in author_spec.FORMS}
acells, agree, miss, extra = {}, 0, [], []
for r in rules:
    acells[r] = {}
    for a in apps:
        fs = sorted(e for e in afail[a]
                    if FORM_RULE.get(e.split("author")[1].strip(" _").split(" ")[0]) == r)
        v = bool(fs)
        t = truth["cells"][r][a]["violates"]
        acells[r][a] = {"verdict": "fail" if v else "pass", "failing": fs}
        if v == t:
            agree += 1
        elif t:
            miss.append([r, a, truth["cells"][r][a].get("form_gap") or
                         ("k6" if truth["cells"][r][a].get("k6") else "")])
        else:
            extra.append([r, a, fs])
json.dump({"schema": "hstreak.author_check/1",
           "what": "the author's own expansion of each form (tools/author_spec.py, the author's "
                   "reading of D1'/D3, not the library's generator) added to Streak's SPEC and "
                   "run with the existing checker, layers CD, on every app; not part of scoring",
           "agree": agree, "cells": len(apps) * len(rules), "g_miss_vs_truth": miss,
           "g_extra_vs_truth": extra, "failing_by_app": afail, "per_cell": acells},
          open(os.path.join(OUT, "author_check.json"), "w"), indent=1)
print("H", nh, "author agree", agree, "of", len(apps) * len(rules), "miss", miss, "extra", extra)
