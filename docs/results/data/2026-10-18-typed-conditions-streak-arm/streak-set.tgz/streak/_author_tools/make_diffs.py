import os, shutil, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from mutants_def import MUTANTS
W = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PR = os.path.join(W, "pristine")
OUT = os.path.join(os.path.dirname(W), "streak", "mutants")
os.makedirs(OUT, exist_ok=True)
tmp = os.path.join(W, "difftmp")
for mid, kind, rules, aim, f, old, new in MUTANTS:
    src = open(os.path.join(PR, f), encoding="utf-8").read()
    assert src.count(old) == 1, (mid, src.count(old))
    shutil.rmtree(tmp, ignore_errors=True)
    for side, text in (("a", src), ("b", src.replace(old, new))):
        os.makedirs(os.path.dirname(os.path.join(tmp, side, f)), exist_ok=True)
        open(os.path.join(tmp, side, f), "w", encoding="utf-8").write(text)
    r = subprocess.run(["diff", "-u", "--label", "a/" + f, "--label", "b/" + f,
                        os.path.join("a", f), os.path.join("b", f)], cwd=tmp,
                       capture_output=True, text=True)
    assert r.returncode == 1, r.stderr
    hdr = f"diff --git a/{f} b/{f}\n"
    open(os.path.join(OUT, mid + ".diff"), "w", encoding="utf-8").write(hdr + r.stdout)
    print(mid, "ok")
shutil.rmtree(tmp, ignore_errors=True)
