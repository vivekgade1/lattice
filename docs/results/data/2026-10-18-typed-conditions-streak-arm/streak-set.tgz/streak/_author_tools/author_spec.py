"""The author's own expansion of the Streak forms into scenarios and invariants (by the
author's reading of D1'/D3; NOT the library's generator), added to Streak's SPEC, to check
that each form is a true statement on a0679e9 and agrees with truth.json. Not part of the set's
scoring. Element names: scenario 'author F<n> <case>', invariant 'author_F<n>'."""

import dataclasses
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from forms_def import FORMS, T0, habit, target, u  # noqa: E402

import spec as _streak  # noqa: E402  (Streak's spec.py, first on PYTHONPATH)
from lattice.spec import Invariant, Scenario, Step  # noqa: E402

_TABLE = {"User": "users", "Habit": "habits", "Device": "devices", "Completion": "completions",
         "Nudge": "nudges", "NotificationPrefs": "notification_prefs",
         "HabitTarget": "habit_targets", "RefreshToken": "refresh_tokens"}
DEFAULT_OK = {"POST /v1/auth/login": 200, "POST /v1/devices": 201, "GET /v1/habits": 200}


def lit(v):
    return '"' + v + '"' if isinstance(v, str) else str(v)


def values_of(cond):
    if "values" in cond:
        return sorted(cond["values"], key=lambda x: (str(type(x)), x))[0], "~"
    op, v = cond["op"], cond["value"]
    return {"min_len": ("x" * v, "x" * (v - 1)), "max_len": ("x" * v, "x" * (v + 1)),
            "ge": (v, v - 1), "le": (v, v + 1), "gt": (v + 1, v), "lt": (v - 1, v),
            "eq": (v, v + 1)}[op]


def put(req, path, value):
    req = {k: (dict(v) if isinstance(v, dict) else v) for k, v in req.items()}
    where, key = path.split(".", 1)
    slot = {"body": "json", "query": "params"}[where]
    req[slot] = {**req.get(slot, {}), key: value}
    return req


def given_unchanged(given):
    out = {}
    for h in (given or {}).get("habits", []):
        out["habits" if "habits" not in out else "Habit"] = {
            "where": {"id": h["id"]}, "count": 1,
            "equals": {"name": h["name"], "version": h["version"], "archived": h["archived"],
                       "target_count": h["target_count"], "deleted_at": None}}
    for t in (given or {}).get("refresh_tokens", []):
        out["refresh_tokens"] = {"where": {"id": t["id"]},
                                 "equals": {"rotated_at": None, "revoked_at": None}}
    for d in (given or {}).get("devices", []):
        out["devices"] = {"where": {"id": d["id"]}, "count": 1}
    for n in (given or {}).get("nudges", []):
        out["nudges"] = {"where": {"id": n["id"], "dismissed_at": None}, "count": 1}
    return out


def step(method, req, user, status, db=None):
    return Step(method, req["path"], user, json=req.get("json"), params=req.get("params"),
                expect_status=status, expect_db=db or None)


def bound(fid, f):
    method, _tpl = f["endpoint"].split(" ", 1)
    at, beyond = values_of(f["cond"])
    path = f["field"]["path"]
    ok = (f.get("accepted") or {}).get("status") or DEFAULT_OK[f["endpoint"]]
    user = None if f["caller"] == "anon" else f["caller"]
    db = given_unchanged(f.get("given"))
    if f.get("stores") and f["stores"] != "NotificationPrefs.push_enabled":
        t, c = f["stores"].split(".")
        db[t] = {"where": {c: beyond}, "count": 0}
    if f["endpoint"] == "POST /v1/auth/register":
        db["users"] = {"count": 2 + len((f.get("given") or {}).get("users", []))}
    if f["endpoint"] == "POST /v1/auth/login":
        db["refresh_tokens"] = {"where": {"installation_id": u(9)}, "count": 0}
    if f["endpoint"] == "PUT /v1/me":
        db["notification_prefs"] = {"where": {"user_id": 1}, "equals": {"push_enabled": True}}
    g = f.get("given")
    return [Scenario(f"author {fid} at_bound", given=g, steps=(
                step(method, put(f["request"], path, at), user, ok),)),
            Scenario(f"author {fid} beyond", given=g, steps=(
                step(method, put(f["request"], path, beyond), user, f["refused"]["status"], db),))]


def column_inv(fid, f):
    t, c = f["field"]["column"].split(".")
    cond = f["cond"]
    if "values" in cond:
        expr = f"{t}.{c} in (" + ", ".join(lit(v) for v in cond["values"]) + ")"
    else:
        expr = f"{t}.{c} {dict(ge='>=', le='<=', gt='>', lt='<')[cond['op']]} {cond['value']}"
    return Invariant(f"author_{fid}", f"author's reading of {fid}", expr)


def counted(fid, n):
    """n synthesised counted rows for the author's row-limit cases."""
    if fid == "F3":
        return {"users": [{"id": 101, "email": "cara@example.com", "hashed_password": "x",
                           "timezone": "UTC", "change_seq": 0, "created_at": T0}]}
    if fid == "F28":
        return {"habits": [habit(1000, "walk")], "habit_targets": [target(1000, 1000)]}
    if fid in ("F29", "F33"):
        return {"habits": [habit(1000 + i, f"s{i}") for i in range(n)],
                "habit_targets": [target(1000 + i, 1000 + i) for i in range(n)]}
    if fid == "F35":
        return {"completions": [{"id": u(1000), "habit_id": u(100), "date": "2026-03-03",
                                 "note": None, "change_seq": 0, "created_at": T0,
                                 "updated_at": T0, "deleted_at": None}]}
    raise KeyError(fid)


def merge(a, b):
    out = {k: list(v) for k, v in (a or {}).items()}
    for k, v in b.items():
        out[k] = out.get(k, []) + list(v)
    return out


ACTIVE_COUNT = {"habits": {"where": {"user_id": 1, "archived": False, "deleted_at": None},
                           "count": 50}}


def row_limit(fid, f):
    method, _tpl = f["endpoint"].split(" ", 1)
    m = {"F3": 0, "F28": 0, "F29": 1, "F33": 0, "F35": 0}[fid]
    mx = f["max"]
    below = merge(f.get("given"), counted(fid, mx - 1 - m)) if mx - 1 - m else f.get("given")
    at = merge(f.get("given"), counted(fid, mx - m))
    user = None if f["caller"] == "anon" else f["caller"]
    req = f["request"]
    db = {"F3": {"users": {"where": {"email": "cara@example.com"}, "count": 1}},
          "F28": {"habits": {"where": {"name": "walk"}, "count": 1}},
          "F29": {**ACTIVE_COUNT, "Habit": {"where": {"name": "one more"}, "count": 0}},
          "F33": {**ACTIVE_COUNT, "Habit": {"where": {"id": u(151)},
                                            "equals": {"archived": True, "version": 1}}},
          "F35": {"completions": {"where": {"habit_id": u(100), "date": "2026-03-03"},
                                  "count": 1}}}[fid]
    w = []
    for col, v in (f.get("where") or {}).items():
        w.append(f"is_null({f['table']}.{col})" if v is None else
                 (f"not {f['table']}.{col}" if v is False else f"{f['table']}.{col} == {lit(v)}"))
    by = f["by"][0] if len(f["by"]) == 1 else tuple(f["by"])
    expr = f"count({f['table']}, by={lit(by) if isinstance(by, str) else repr(by)}" + (
        f", where={' and '.join(w)}" if w else "") + f") <= {mx}"
    return ([Scenario(f"author {fid} below", given=below, steps=(
                step(method, req, user, f["accepted"]["status"]),)),
             Scenario(f"author {fid} at_limit", given=at, steps=(
                 step(method, req, user, f["refused"]["status"], db),))],
            Invariant(f"author_{fid}", f"author's reading of {fid}", expr))


def ownership(fid, f):
    out = []
    key = f["row"] if not isinstance(f["row"], str) or not f["row"].startswith("/") else \
        f["row"].rstrip("/").split("/")[-1]
    db = given_unchanged(f.get("given"))
    for e in f["endpoints"]:
        method, tpl = e.split(" ", 1)
        path = re.sub(r"\{[^}]*\}", str(key), tpl)
        ok = (f.get("accepted") or {}).get(e, {}).get("status") or {"DELETE": 204}.get(method, 200)
        r = {"path": path}
        slug = re.sub(r"[^a-z]+", "_", e.lower()).strip("_")
        out += [Scenario(f"author {fid} owner {slug}", given=f.get("given"),
                         steps=(step(method, r, f["owner"], ok),)),
                Scenario(f"author {fid} other {slug}", given=f.get("given"),
                         steps=(step(method, r, f["other"], f["refused_other"]["status"], db),)),
                Scenario(f"author {fid} anon {slug}", given=f.get("given"),
                         steps=(step(method, r, None, f["refused_anon"]["status"], db),))]
    return out


SCEN, INV = [], []
for fid, _rule, kind, form in FORMS:
    if kind == "bound" and "column" in form["field"]:
        INV.append(column_inv(fid, form))
    elif kind == "bound":
        SCEN += bound(fid, form)
    elif kind == "row_limit":
        s, i = row_limit(fid, form)
        SCEN += s
        if fid != "F33":  # F29 and F33 state the same count bound
            INV.append(i)
    elif kind == "ownership":
        SCEN += ownership(fid, form)

SPEC = dataclasses.replace(_streak.SPEC, scenarios=(*_streak.SPEC.scenarios, *SCEN),
                           invariants=(*_streak.SPEC.invariants, *INV))
