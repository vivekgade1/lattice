#!/bin/bash
# usage: run1.sh ID   (ID = ok or a mutant id): fresh tree from pristine, apply patch, build, vet, ACD check
set -u
W=/private/tmp/claude-501/-Users-vivekgade-Documents-lattice/ee5b7f26-0758-4aaf-845d-fa75c50a8e80/scratchpad/h-streak-set/_work
OUT=/private/tmp/claude-501/-Users-vivekgade-Documents-lattice/ee5b7f26-0758-4aaf-845d-fa75c50a8e80/scratchpad/h-streak-set/streak
ID=$1
T=$W/trees/$ID; O=$W/runs/$ID
DRV=/private/tmp/claude-501/-Users-vivekgade-Documents-lattice/ee5b7f26-0758-4aaf-845d-fa75c50a8e80/scratchpad/perfengines/perfvenv/bin/python
LAT=/Users/vivekgade/Documents/lattice-ha
case "$T" in "$W"/trees/*) rm -rf "$T";; *) exit 9;; esac
mkdir -p "$T" "$O"
cp -R $W/pristine/. "$T"/
cd "$T"
: > $O/status
if [ "$ID" != ok ]; then
  P=$OUT/mutants/$ID.diff
  git apply --check $P > $O/apply.log 2>&1; echo "apply_check=$?" >> $O/status
  git apply $P >> $O/apply.log 2>&1
fi
go build ./... > $O/build.log 2>&1; echo "build=$?" >> $O/status
go vet ./... > $O/vet.log 2>&1; echo "vet=$?" >> $O/status
go build -o bin/streak-api ./cmd/server >> $O/build.log 2>&1; echo "bin=$?" >> $O/status
export UV_NO_SYNC=1 PYTHONDONTWRITEBYTECODE=1 LATTICE_CONTAINER_OWNER=h-streak-author
export PYTHONPATH=$T:$LAT
s=$(date +%s)
$DRV -m lattice.spec check --spec spec:SPEC --app harness:make_app --db harness:build_db \
  --runtime harness:RUNTIME --login harness:login --services harness:SERVICES --database mysql \
  --layers ACD --go-src $T --json > $O/acd.json 2> $O/acd.err
echo "acd=$?" >> $O/status
echo "wall=$(( $(date +%s) - s ))" >> $O/status
