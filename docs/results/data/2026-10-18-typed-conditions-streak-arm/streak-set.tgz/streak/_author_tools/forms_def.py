"""The Streak forms (hand-written by the separate author; no library code was used to write
them). Rows follow CONTEXT.md: every NOT NULL column given, UUIDs canonical, dates YYYY-MM-DD."""

T0 = "2026-03-01T00:00:00Z"
TODAY = "2026-03-04"
HASH_LIVE = "c51763de293faf5b57c856563a9d0bebb1a8b46ea7ed69bd7a55ba82a2a3c30e"
MSG = "Behind: do 2 more in the next 5 day(s). Needs 2.80 per week, you are at 2.33."


def u(n):
    return f"00000000-0000-4000-8000-{n:012d}"


def habit(n, name, *, user=1, target=3, period="week", start="2026-03-02", end=None,
          archived=False, description=None, version=1):
    return {"id": u(n), "user_id": user, "name": name, "description": description,
            "target_count": target, "period": period, "start_date": start, "end_date": end,
            "archived": archived, "version": version, "change_seq": 0, "created_at": T0,
            "updated_at": T0, "deleted_at": None}


def target(i, n, count=3, frm="2026-03-02"):
    return {"id": i, "habit_id": u(n), "target_count": count, "effective_from": frm}


def completion(n, habit_n, date, note=None):
    return {"id": u(n), "habit_id": u(habit_n), "date": date, "note": note, "change_seq": 0,
            "created_at": T0, "updated_at": T0, "deleted_at": None}


def nudge(n, habit_n):
    return {"id": u(n), "habit_id": u(habit_n), "for_date": TODAY, "kind": "behind",
            "message": MSG, "delivery": "pending", "delivery_reason": None, "change_seq": 0,
            "created_at": "2026-03-04T06:00:00Z", "updated_at": "2026-03-04T06:00:00Z",
            "dismissed_at": None, "deleted_at": None}


def device(n, user, inst, token):
    return {"id": n, "user_id": user, "installation_id": inst, "platform": "android",
            "push_token": token, "timezone": "UTC", "app_version": "2.1.0", "created_at": T0,
            "updated_at": T0}


DEVICE_BODY = {"installation_id": u(9), "platform": "android", "push_token": "tok-ann-2",
               "timezone": "Europe/Berlin", "app_version": "2.2.0"}
NEW_HABIT = {"id": u(200), "name": "walk", "target_count": 3, "period": "week"}
REG = {"email": "cara@example.com", "password": "password-cara"}
LOGIN = {"email": "ann@example.com", "password": "password-ann", "installation_id": u(9)}
H100 = {"habits": [habit(100, "walk")], "habit_targets": [target(100, 100)]}
H100_FEB = {"habits": [habit(100, "walk", start="2026-02-02")],
            "habit_targets": [target(100, 100, frm="2026-02-02")]}
UNCH = lambda s: {"status": s, "db": "unchanged"}  # noqa: E731
ACT = "Habit"
ACTIVE = {"archived": False, "deleted_at": None}


def P(method, tpl):
    return {"param": f"{method} {tpl}"}


def bound_param(method, tpl, path, cond, request, *, caller="ann", refused=422,
                accepted=None, stores=None, given=None, node=None):
    c = dict(cond)
    if node:
        c = {"node": node, **c}
    f = {"field": {**P(method, tpl), "path": path}, "cond": c, "endpoint": f"{method} {tpl}",
         "caller": caller, "request": request}
    if stores:
        f["stores"] = stores
    if given:
        f["given"] = given
    if accepted is not None:
        f["accepted"] = {"status": accepted}
    f["refused"] = UNCH(refused)
    return f


# (form id, rule, kind, form)
FORMS = [
    ("F1", "R9", "bound", bound_param(
        "POST", "/v1/auth/register", "body.password", {"op": "min_len", "value": 8},
        {"path": "/v1/auth/register", "json": REG}, caller="anon", accepted=201, node="Len")),
    ("F2", "R9", "bound", bound_param(
        "POST", "/v1/auth/register", "body.password", {"op": "max_len", "value": 72},
        {"path": "/v1/auth/register", "json": REG}, caller="anon", accepted=201)),
    ("F3", "R10", "row_limit", {
        "table": "User", "by": ["email"], "max": 1, "endpoint": "POST /v1/auth/register",
        "caller": "anon", "request": {"path": "/v1/auth/register", "json": REG},
        "given": {"users": [{"id": 100, "email": "dan@example.com", "hashed_password": "x",
                             "timezone": "UTC", "change_seq": 0, "created_at": T0}]},
        "accepted": {"status": 201}, "refused": UNCH(409)}),
    ("F4", "R14", "bound", bound_param(
        "POST", "/v1/auth/login", "body.password", {"values": ["password-ann"]},
        {"path": "/v1/auth/login", "json": LOGIN}, caller="anon", refused=401, accepted=200)),
    ("F5", "R14", "bound", bound_param(
        "POST", "/v1/auth/login", "body.email", {"values": ["ann@example.com"]},
        {"path": "/v1/auth/login", "json": LOGIN}, caller="anon", refused=401, node="In")),
    ("F6", "R19", "bound", bound_param(
        "POST", "/v1/auth/refresh", "body.refresh_token", {"values": ["rt-ann-live"]},
        {"path": "/v1/auth/refresh", "json": {"refresh_token": "rt-ann-live"}}, caller="anon",
        refused=401, accepted=200,
        given={"refresh_tokens": [{"id": 100, "user_id": 1, "installation_id": u(7),
                                   "token_hash": HASH_LIVE, "expires_at": "2026-04-01T00:00:00Z",
                                   "rotated_at": None, "revoked_at": None, "created_at": T0}]})),
    ("F7", "R25", "bound", bound_param(
        "PUT", "/v1/me", "body.push_enabled", {"values": [False, True]},
        {"path": "/v1/me", "json": {"push_enabled": True}}, accepted=200,
        stores="NotificationPrefs.push_enabled")),
    ("F8", "R28", "ownership", {
        "table": "Habit", "scope": "owner",
        "endpoints": ["GET /v1/habits/{id}", "DELETE /v1/habits/{id}",
                      "GET /v1/habits/{id}/progress", "GET /v1/habits/{id}/history",
                      "GET /v1/habits/{id}/completions"],
        "owner": "ann", "other": "ben", "given": H100, "row": f"/v1/habits/{u(100)}",
        "accepted": {"GET /v1/habits/{id}": {"status": 200},
                     "DELETE /v1/habits/{id}": {"status": 204},
                     "GET /v1/habits/{id}/progress": {"status": 200},
                     "GET /v1/habits/{id}/history": {"status": 200},
                     "GET /v1/habits/{id}/completions": {"status": 200}},
        "refused_other": UNCH(404), "refused_anon": UNCH(401)}),
    ("F9", "R28", "ownership", {
        "table": "Nudge", "scope": "owner", "endpoints": ["POST /v1/nudges/{id}/dismiss"],
        "owner": "ann", "other": "ben",
        "given": {**H100, "nudges": [nudge(500, 100)]}, "row": u(500),
        "accepted": {"POST /v1/nudges/{id}/dismiss": {"status": 200}},
        "refused_other": UNCH(404), "refused_anon": UNCH(401)}),
    ("F10", "R28", "ownership", {
        "table": "Device", "scope": "owner(user_id)", "endpoints": ["DELETE /v1/devices/{id}"],
        "owner": "ann", "other": "ben",
        "given": {"devices": [device(100, 1, u(9), "tok-ann-9")]}, "row": "/v1/devices/100",
        "accepted": {"DELETE /v1/devices/{id}": {"status": 204}},
        "refused_other": UNCH(404), "refused_anon": UNCH(401)}),
    ("F11", "R31", "bound", bound_param(
        "POST", "/v1/devices", "body.platform", {"values": ["android", "ios"]},
        {"path": "/v1/devices", "json": DEVICE_BODY}, accepted=201, stores="Device.platform",
        node="In")),
    ("F12", "R31", "bound", bound_param(
        "POST", "/v1/devices", "body.push_token", {"op": "max_len", "value": 4096},
        {"path": "/v1/devices", "json": DEVICE_BODY}, accepted=201, stores="Device.push_token")),
    ("F13", "R31", "bound", bound_param(
        "POST", "/v1/devices", "body.push_token", {"op": "min_len", "value": 1},
        {"path": "/v1/devices", "json": DEVICE_BODY}, stores="Device.push_token")),
    ("F14", "R33", "ownership", {
        "table": "Device", "scope": "owner", "endpoints": ["DELETE /v1/devices/{id}"],
        "owner": "ann", "other": "ben",
        "given": {"devices": [device(100, 1, u(9), "tok-ann-9")]}, "row": 100,
        "refused_other": UNCH(404), "refused_anon": UNCH(401)}),
    ("F15", "R37", "bound", {"field": {"column": "Device.platform"},
                             "cond": {"values": ["android", "ios"]}, "refused": UNCH(422)}),
    ("F16", "R39", "bound", {"field": {"column": "Habit.version"},
                             "cond": {"op": "ge", "value": 1}, "refused": UNCH(422)}),
    ("F17", "R39", "bound", {"field": {"column": "Habit.period"},
                             "cond": {"node": "In", "values": ["month", "week", "year"]},
                             "refused": UNCH(422)}),
    ("F18", "R42", "bound", {"field": {"column": "Nudge.kind"},
                             "cond": {"values": ["achieved", "behind", "on_track", "unreachable"]},
                             "refused": UNCH(422)}),
    ("F19", "R42", "bound", {"field": {"column": "Nudge.delivery"},
                             "cond": {"values": ["failed", "pending", "sent", "suppressed"]},
                             "refused": UNCH(422)}),
    ("F20", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.name", {"op": "max_len", "value": 100},
        {"path": "/v1/habits", "json": NEW_HABIT}, accepted=201, stores="Habit.name")),
    ("F21", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.name", {"op": "min_len", "value": 1},
        {"path": "/v1/habits", "json": NEW_HABIT}, accepted=201, stores="Habit.name",
        node="Len")),
    ("F22", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.description", {"op": "max_len", "value": 500},
        {"path": "/v1/habits", "json": {**NEW_HABIT, "description": "d"}}, accepted=201,
        stores="Habit.description")),
    ("F23", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.period", {"values": ["month", "week", "year"]},
        {"path": "/v1/habits", "json": NEW_HABIT}, accepted=201, stores="Habit.period")),
    ("F24", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.target_count", {"op": "ge", "value": 1},
        {"path": "/v1/habits", "json": NEW_HABIT}, accepted=201, stores="Habit.target_count",
        node="Cmp")),
    ("F25", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.target_count", {"op": "le", "value": 7},
        {"path": "/v1/habits", "json": NEW_HABIT}, accepted=201, stores="Habit.target_count")),
    ("F26", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.target_count", {"op": "le", "value": 31},
        {"path": "/v1/habits", "json": {**NEW_HABIT, "target_count": 10, "period": "month"}},
        accepted=201)),
    ("F27", "R51", "bound", bound_param(
        "POST", "/v1/habits", "body.target_count", {"op": "le", "value": 366},
        {"path": "/v1/habits", "json": {**NEW_HABIT, "target_count": 100, "period": "year"}},
        accepted=201)),
    ("F28", "R55", "row_limit", {
        "table": "Habit", "by": ["user_id", "name"], "where": {"deleted_at": None}, "max": 1,
        "endpoint": "POST /v1/habits", "caller": "ann",
        "request": {"path": "/v1/habits", "json": NEW_HABIT},
        "given": {"habits": [habit(150, "other")], "habit_targets": [target(150, 150)]},
        "accepted": {"status": 201}, "refused": UNCH(409)}),
    ("F29", "R56", "row_limit", {
        "table": "Habit", "by": ["user_id"], "where": ACTIVE, "max": 50,
        "endpoint": "POST /v1/habits", "caller": "ann",
        "request": {"path": "/v1/habits", "json": {**NEW_HABIT, "name": "one more"}},
        "given": {"habits": [habit(150, "h150")], "habit_targets": [target(150, 150)]},
        "accepted": {"status": 201}, "refused": UNCH(409)}),
    ("F30", "R60", "bound", bound_param(
        "PATCH", "/v1/habits/{id}", "body.name", {"op": "max_len", "value": 100},
        {"path": f"/v1/habits/{u(100)}", "json": {"version": 1, "name": "stroll"}},
        accepted=200, stores="Habit.name", given=H100)),
    ("F31", "R60", "bound", bound_param(
        "PATCH", "/v1/habits/{id}", "body.target_count", {"op": "le", "value": 7},
        {"path": f"/v1/habits/{u(100)}", "json": {"version": 1, "target_count": 5}},
        accepted=200, given=H100)),
    ("F32", "R62", "bound", bound_param(
        "PATCH", "/v1/habits/{id}", "body.version", {"op": "eq", "value": 1},
        {"path": f"/v1/habits/{u(100)}", "json": {"version": 1, "description": "x"}},
        refused=409, accepted=200, given=H100)),
    ("F33", "R69", "row_limit", {
        "table": "Habit", "by": ["user_id"], "where": ACTIVE, "max": 50,
        "endpoint": "PATCH /v1/habits/{id}", "caller": "ann",
        "request": {"path": f"/v1/habits/{u(151)}", "json": {"version": 1, "archived": False}},
        "given": {"habits": [habit(151, "old", archived=True)],
                  "habit_targets": [target(151, 151)]},
        "accepted": {"status": 200}, "refused": UNCH(409)}),
    ("F34", "R77", "bound", bound_param(
        "POST", "/v1/habits/{habit_id}/completions", "body.note", {"op": "max_len", "value": 280},
        {"path": f"/v1/habits/{u(100)}/completions",
         "json": {"id": u(300), "date": "2026-03-02", "note": "n"}},
        accepted=201, stores="Completion.note", given=H100)),
    ("F35", "R78", "row_limit", {
        "table": "Completion", "by": ["habit_id", "date"], "where": {"deleted_at": None},
        "max": 1, "endpoint": "POST /v1/habits/{habit_id}/completions", "caller": "ann",
        "request": {"path": f"/v1/habits/{u(100)}/completions",
                    "json": {"id": u(301), "date": "2026-03-03"}},
        "given": {**H100, "completions": [completion(300, 100, "2026-03-02")]},
        "accepted": {"status": 201}, "refused": UNCH(409)}),
    ("F36", "R86", "bound", bound_param(
        "GET", "/v1/habits", "query.limit", {"op": "ge", "value": 1},
        {"path": "/v1/habits", "params": {"limit": 50}}, accepted=200)),
    ("F37", "R86", "bound", bound_param(
        "GET", "/v1/habits", "query.limit", {"op": "le", "value": 200},
        {"path": "/v1/habits", "params": {"limit": 50}})),
    ("F38", "R86", "bound", bound_param(
        "GET", "/v1/habits/{habit_id}/completions", "query.limit", {"op": "le", "value": 200},
        {"path": f"/v1/habits/{u(100)}/completions", "params": {"limit": 50}}, accepted=200,
        given=H100)),
    ("F39", "R92", "bound", bound_param(
        "GET", "/v1/sync", "query.limit", {"op": "ge", "value": 1},
        {"path": "/v1/sync", "params": {"limit": 100}}, accepted=200)),
    ("F40", "R92", "bound", bound_param(
        "GET", "/v1/sync", "query.limit", {"op": "le", "value": 200},
        {"path": "/v1/sync", "params": {"limit": 100}}, accepted=200)),
    ("F41", "R137", "bound", bound_param(
        "GET", "/v1/nudges", "query.limit", {"op": "le", "value": 200},
        {"path": "/v1/nudges", "params": {"limit": 50}}, accepted=200)),
    ("F42", "R147", "bound", bound_param(
        "GET", "/v1/habits/{id}/history", "query.limit", {"op": "ge", "value": 1},
        {"path": f"/v1/habits/{u(100)}/history", "params": {"limit": 12}}, accepted=200,
        given=H100_FEB)),
    ("F43", "R147", "bound", bound_param(
        "GET", "/v1/habits/{id}/history", "query.limit", {"op": "le", "value": 100},
        {"path": f"/v1/habits/{u(100)}/history", "params": {"limit": 12}}, accepted=200,
        given=H100_FEB)),
]
