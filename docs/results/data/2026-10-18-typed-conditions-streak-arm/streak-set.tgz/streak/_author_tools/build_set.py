"""Writes the Streak shape set into ../../streak (JSON files, the candidates for the 50/60 pair).
h_verdicts.json is written by hverdicts.py from the checker runs."""

import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from class_def import FORMED, NE  # noqa: E402
from extra_def import ATTEMPTS, INVALID, PAIRS  # noqa: E402
from forms_def import FORMS  # noqa: E402
from mutants_def import MUTANTS  # noqa: E402
from truth_def import CONTROL, FORM_GAP, HOLDS, HOLDS_OK, K6_RULES, VIOLATES  # noqa: E402

W = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(os.path.dirname(W), "streak")
RULES = json.load(open(os.path.join(W, "ref", "rules.json")))
TEXT = {r["id"]: r["text"] for r in RULES["rules"]}
LINKS = {r["id"]: r["links"] for r in RULES["rules"]}
CONTEXT = set(RULES["context"])


def canon(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def anchor(rule):
    if rule not in TEXT:
        return hashlib.sha256(b"no such rule").hexdigest()
    return hashlib.sha256(" ".join(TEXT[rule].split()).encode("utf-8")).hexdigest()


def entry(t):
    fid, rule, kind, form = t
    return {"id": fid, "rule": rule, "anchor": anchor(rule), "kind": kind, "form": form,
            "status": "approved", "author": "hand", "approved_by": "streak-shapes-agent",
            "approved_sha": hashlib.sha256(canon({"kind": kind, "form": form}).encode()).hexdigest()}


def resolve(x):
    return entry(next(f for f in FORMS if f[0] == x)) if isinstance(x, str) else entry(x)


def dump(rel, obj):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=1, ensure_ascii=False, sort_keys=False)
        fh.write("\n")


def main():
    scope = [r["id"] for r in RULES["rules"] if r["id"] not in CONTEXT]
    assert len(scope) == 146, len(scope)
    assert set(FORMED) | set(NE) == set(scope) and not set(FORMED) & set(NE)
    formed_rules = sorted({f[1] for f in FORMS}, key=lambda r: int(r[1:]))
    assert set(formed_rules) == set(FORMED), set(formed_rules) ^ set(FORMED)

    ne_map = {r: {"category": c, "reason": why} for r, (c, why) in
              sorted(NE.items(), key=lambda kv: int(kv[0][1:]))}
    forms_obj = {"schema": "lattice.forms/1", "source": "REQUIREMENTS.md",
                 "forms": [entry(f) for f in FORMS], "not_expressible": ne_map}
    dump("forms.json", forms_obj)

    # classification of every in-scope rule
    rows = []
    for r in scope:
        if r in FORMED:
            cov, states, leaves = FORMED[r]
            rows.append({"rule": r, "text": TEXT[r], "expressible": True,
                         "status": "formed", "coverage": cov,
                         "forms": [f[0] for f in FORMS if f[1] == r],
                         "kinds": sorted({f[2] for f in FORMS if f[1] == r}),
                         "states": states, "not_stated": leaves})
        else:
            cat, why = NE[r]
            rows.append({"rule": r, "text": TEXT[r], "expressible": False,
                         "status": f"not_expressible:{cat}", "category": cat, "reason": why})
    counts = {}
    for x in rows:
        k = "formed" if x["expressible"] else x["status"]
        counts[k] = counts.get(k, 0) + 1
    dump("classification.json", {
        "schema": "hstreak.classification/1", "app": "streak a0679e9",
        "scope": len(rows), "context_rules": sorted(CONTEXT), "counts": dict(sorted(counts.items())),
        "formed_rules": len(formed_rules), "forms": len(FORMS), "rules": rows})

    # hand-written checks per formed rule (Streak's own spec.py elements, by the trace's links)
    hw = {}
    for r in formed_rules:
        els = [x for x in LINKS[r] if x.startswith(("scenario:", "invariant:"))]
        hw[r] = {"elements": els, "profile_links": [x for x in LINKS[r] if x.startswith("profile:")],
                 "forms": [f[0] for f in FORMS if f[1] == r]}
    dump("handwritten.json", {
        "schema": "hstreak.handwritten/1",
        "source": "spec.py SPEC and spec.trace.json links of Streak a0679e9 (H = the trace's "
                  "scenario: and invariant: links of the rule; profile: links are not checks)",
        "rules": hw})

    # mutants
    ms = []
    for mid, kind, rules, aim, f, _old, _new in MUTANTS:
        data = open(os.path.join(OUT, "mutants", mid + ".diff"), "rb").read()
        ms.append({"name": mid, "kind": kind, "rules": rules, "aim": aim, "file": f,
                   "patch": f"mutants/{mid}.diff",
                   "patch_sha256": hashlib.sha256(data).hexdigest()})
    dump("mutants.json", {
        "schema": "hstreak.mutants/1", "base": "streak build/streak a0679e9 (git archive)",
        "apply": "cd <fresh archive>; git apply mutants/<name>.diff; go build ./... && go vet ./...",
        "mutants": ms})

    # truth
    apps = ["ok"] + [m[0] for m in MUTANTS]
    assert set(apps) == set(VIOLATES), set(apps) ^ set(VIOLATES)
    aim_ne = {"m_rewrite_resets_delivery": "R123", "m_dismiss_marks_suppressed": "R141",
              "m_date_too_old_59": "R75", "m_behind_one_decimal": "R117"}
    cells = {}
    nviol = 0
    for r in formed_rules:
        cells[r] = {}
        for a in apps:
            v = VIOLATES[a].get(r)
            if v:
                nviol += 1
                c = {"violates": True, "reason": "violated: " + v}
            elif a == "ok":
                c = {"violates": False, "reason": HOLDS_OK}
            elif a in aim_ne:
                c = {"violates": False, "reason": CONTROL.format(aim_ne[a])}
            else:
                c = {"violates": False, "reason": HOLDS}
            if (r, a) in FORM_GAP:
                assert c["violates"]
                c["form_gap"] = FORM_GAP[(r, a)]
            if r in K6_RULES:
                c["k6"] = True
            cells[r][a] = c
    for r, a in FORM_GAP:
        assert VIOLATES[a].get(r)
    for a, d in VIOLATES.items():
        for r in d:
            assert r in FORMED, (a, r)
    dump("truth.json", {
        "schema": "hstreak.truth/1",
        "judged": "from the English rule (REQUIREMENTS.md a0679e9) and the Go edit, never from a run",
        "apps": apps, "rules": formed_rules, "violated_cells": nviol,
        "cells_total": len(apps) * len(formed_rules),
        "flags": {"form_gap": "the violated part lies outside what the rule's forms state",
                  "k6": "a column-only bound (no endpoint): invariant only, sees a violation "
                        "only on states some scenario reaches"},
        "cells": cells})

    # pairs
    pairs = []
    for pid, cls, expect, fs, hwsc, pq, wit, why in PAIRS:
        p = {"id": pid, "class": cls, "expect": expect, "forms": [resolve(x) for x in fs],
             "path_or_query_bound": pq, "witness": wit, "why": why}
        if hwsc:
            p["handwritten"] = hwsc
        pairs.append(p)
    dump("pairs.json", {"schema": "hstreak.pairs/1", "pairs": pairs})

    inv = [{"id": iid, "code": code, "why": why, "forms": [entry(t) for t in fs]}
           for iid, code, why, fs in INVALID]
    dump("invalid.json", {"schema": "hstreak.invalid/1", "invalid": inv})

    ne_rows = []
    for i, r in enumerate(sorted(NE, key=lambda x: int(x[1:])), 1):
        cat, why = NE[r]
        att = ATTEMPTS.get(r)
        ne_rows.append({"id": f"N{i}", "app": "streak", "rule": r, "text": TEXT[r],
                        "category": cat, "reason": why,
                        "attempt": entry(att[0]) if att else None,
                        "outcome_db_nonliteral": bool(att and att[1])})
    assert set(ATTEMPTS) <= set(NE)
    dump("not_expressible.json", {"schema": "hstreak.not_expressible/1", "rules": ne_rows})

    # the 50 / 60 candidates (forms-only; same REQUIREMENTS.md, spec.py and trace as a0679e9)
    f29 = next(f for f in FORMS if f[0] == "F29")
    f60 = ("F29", "R56", "row_limit", {**f29[3], "max": 60})
    only = lambda fs: {"schema": "lattice.forms/1", "source": "REQUIREMENTS.md",  # noqa: E731
                       "forms": [entry(t) for t in fs]}
    dump("candidates/limit50/REQUIREMENTS.forms.json", only([f29]))
    dump("candidates/limit60/REQUIREMENTS.forms.json", only([f60]))
    dump("candidates/stated_twice/REQUIREMENTS.forms.json",
         only([f29, ("F44", "R56", "row_limit", {**f29[3], "max": 60})]))
    print("forms", len(FORMS), "formed rules", len(formed_rules), "ne", len(NE), counts)
    print("cells", len(apps) * len(formed_rules), "violated", nviol)


if __name__ == "__main__":
    main()
