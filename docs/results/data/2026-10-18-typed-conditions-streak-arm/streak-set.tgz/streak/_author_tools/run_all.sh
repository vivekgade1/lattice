#!/bin/bash
W=/private/tmp/claude-501/-Users-vivekgade-Documents-lattice/ee5b7f26-0758-4aaf-845d-fa75c50a8e80/scratchpad/h-streak-set/_work
for p in $(ls $W/../streak/mutants/*.diff | xargs -n1 basename | sed 's/\.diff$//'); do
  $W/tools/run1.sh $p
  echo "$p $(tr '\n' ' ' < $W/runs/$p/status)"
done
