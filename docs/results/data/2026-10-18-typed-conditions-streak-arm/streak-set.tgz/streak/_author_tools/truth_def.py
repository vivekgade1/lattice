"""Truth, judged from the English rule and the Go edit (never from a run).

VIOLATES[app] = {rule: reason}; every other (formed rule, app) cell holds.
FORM_GAP[(rule, app)] = why the violated part lies outside what the rule's forms state
(a planned blind spot of the closed form set, by construction)."""

VIOLATES = {
    "ok": {},
    "m_habit_limit_gt": {
        "R56": "a 51st active habit is created (the limit check lets the count reach 51)",
        "R69": "restoring an archived habit while 50 are active is accepted (shared check)"},
    "m_habit_limit_49": {
        "R56": "the 50th active habit is refused: the limit is 49, not 50",
        "R69": "restoring while 49 are active is refused: the limit is 49, not 50"},
    "m_restore_limit_skipped": {
        "R69": "restoring while 50 are active is accepted (no limit check on restore)",
        # correction made before the manifest, after the author's own check (README):
        "R56": "a restore takes the user to 51 active habits: 'at most 50 active habits' is "
               "a state rule, broken whatever request reached the state"},
    "m_name_max_101": {
        "R51": "a 101-character name is created",
        "R60": "a PATCH to a 101-character name is accepted (creation's bound not applied)"},
    "m_description_max_499": {
        "R51": "a 500-character description is refused on create",
        "R60": "a PATCH to a 500-character description is refused (creation's bound is 500)"},
    "m_target_week_max_8": {
        "R51": "a weekly target_count of 8 is created",
        "R60": "a PATCH of a weekly habit to target_count 8 is accepted"},
    "m_note_max_281": {"R77": "a 281-character note is stored"},
    "m_list_limit_max_201": {
        "R86": "?limit=201 is accepted on the habits and check-in lists",
        "R137": "?limit=201 is accepted on GET /v1/nudges"},
    "m_sync_limit_min_0": {"R92": "?limit=0 is accepted on GET /v1/sync"},
    "m_history_limit_max_101": {"R147": "?limit=101 is accepted on history"},
    "m_checkin_same_day_twice": {
        "R78": "a second non-deleted check-in on the same date (new id) is stored with 201"},
    "m_name_taken_case_sensitive": {
        "R55": "'WALK' is accepted beside 'walk': names are no longer compared case-insensitively"},
    "m_name_taken_create_skipped": {
        "R55": "a second habit named exactly like an existing one is created"},
    "m_get_habit_any_owner": {"R28": "ben reads ann's habit (200 instead of 404)"},
    "m_patch_habit_any_owner": {"R28": "ben changes ann's habit through PATCH (200 instead of 404)"},
    "m_dismiss_any_owner": {"R28": "ben dismisses ann's nudge (200 instead of 404, a write)"},
    "m_delete_device_any_owner": {
        "R28": "ben deletes ann's device (204 instead of 404, a write)",
        "R33": "DELETE removes a device row that is not the caller's"},
    "m_rewrite_resets_delivery": {},
    "m_dismiss_marks_suppressed": {},
    "m_patch_version_ignored": {
        "R62": "a PATCH with a stale version is applied (200) instead of 409 version_conflict"},
    "m_password_min_7": {"R9": "a 7-byte password registers a user"},
    "m_platform_unchecked": {
        "R31": "a platform other than ios/android is stored with 201",
        "R37": "devices.platform can hold a value outside {ios, android}"},
    "m_push_token_max_4097": {"R31": "a 4097-character push_token is stored"},
    "m_email_taken_422": {"R10": "a registered email answers 422, not 409"},
    "m_login_skip_password": {"R14": "a wrong (non-empty) password logs ann in (200, not 401)"},
    "m_refresh_unknown_422": {"R19": "an unknown refresh token answers 422, not 401"},
    "m_push_enabled_lenient": {
        "R25": "a non-boolean push_enabled answers 200 and writes push_enabled false"},
    "m_date_too_old_59": {},
    "m_behind_one_decimal": {},
}

FORM_GAP = {
    ("R60", "m_description_max_499"):
        "R60's forms state the name and weekly-target bounds on PATCH, not the description bound",
    ("R55", "m_name_taken_case_sensitive"):
        "R55's form counts exact (user_id, name) matches; case folding is not expressible",
    ("R28", "m_patch_habit_any_owner"):
        "an ownership form names endpoints without a request body; PATCH needs {version, ...}",
}

# column-only bounds (no endpoint): invariant only (class K6 of the round-2/3 preregs)
K6_RULES = {"R37", "R39", "R42"}

HOLDS = "holds: nothing this rule states is changed by the edit"
HOLDS_OK = "holds: the clean app a0679e9"
CONTROL = "holds: the edit is aimed at a rule that is not formed ({})"
