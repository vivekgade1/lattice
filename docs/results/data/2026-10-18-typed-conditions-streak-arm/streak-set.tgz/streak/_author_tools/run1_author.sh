#!/bin/bash
# usage: run1_author.sh ID: the author's own expansion of the forms (author_spec:SPEC), layers CD
set -u
W=/private/tmp/claude-501/-Users-vivekgade-Documents-lattice/ee5b7f26-0758-4aaf-845d-fa75c50a8e80/scratchpad/h-streak-set/_work
OUT=$W/../streak
ID=$1
T=$W/atrees/$ID; O=$W/runs_author/$ID
DRV=$W/../../perfengines/perfvenv/bin/python
LAT=/Users/vivekgade/Documents/lattice-ha
case "$T" in "$W"/atrees/*) rm -rf "$T";; *) exit 9;; esac
mkdir -p "$T" "$O"
cp -R $W/pristine/. "$T"/
cd "$T"
: > $O/status
if [ "$ID" != ok ]; then git apply $OUT/mutants/$ID.diff > $O/apply.log 2>&1; echo "apply=$?" >> $O/status; fi
go build -o bin/streak-api ./cmd/server > $O/build.log 2>&1; echo "bin=$?" >> $O/status
export UV_NO_SYNC=1 PYTHONDONTWRITEBYTECODE=1 LATTICE_CONTAINER_OWNER=h-streak-author
export PYTHONPATH=$T:$LAT:$W/tools
s=$(date +%s)
$DRV -m lattice.spec check --spec author_spec:SPEC --app harness:make_app --db harness:build_db \
  --runtime harness:RUNTIME --login harness:login --services harness:SERVICES --database mysql \
  --layers CD --json > $O/cd.json 2> $O/cd.err
echo "cd=$?" >> $O/status
echo "wall=$(( $(date +%s) - s ))" >> $O/status
