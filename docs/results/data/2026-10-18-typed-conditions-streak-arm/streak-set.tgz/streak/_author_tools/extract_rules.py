import json, sys, os
src = sys.argv[1]; out = sys.argv[2]
t = json.load(open(src))
json.dump({"context": t["context"], "unchecked": t["unchecked"],
           "rules": [{"id": r["id"], "text": r["text"], "section": r.get("section"),
                      "links": t["links"].get(r["id"], [])} for r in t["rules"]]},
          open(out, "w"), indent=1)
