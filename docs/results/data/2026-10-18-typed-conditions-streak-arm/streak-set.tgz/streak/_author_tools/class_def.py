"""Hand classification of Streak a0679e9's 146 in-scope rules (R3-R148; R1, R2 are context).

FORMED: rule -> (coverage, what the forms state, what they leave out).
NOT_EXPRESSIBLE: rule -> (D6 category, reason)."""

FORMED = {
    "R9": ("partial", "password 8..72 (min_len, max_len) on register",
           "email validity and IANA timezone are format checks; 'bytes' is read as characters "
           "(the witness is ASCII, where they agree)"),
    "R10": ("partial", "one user per email: a second registration of the same email is refused 409",
            "the case-insensitive comparison (Ann@ vs ann@): a count bound matches exact values"),
    "R14": ("full", "ann's login: any other password, or any other email, is refused 401",
            "(the error code invalid_credentials is a response-body value, as for every form)"),
    "R19": ("partial", "an unknown refresh token is refused 401 (a token other than the live one)",
            "expired (time) and revoked (a row state that is not a machine) tokens"),
    "R25": ("partial", "push_enabled must be a boolean: anything else is 422 with nothing changed",
            "the HH:MM format of quiet_start/quiet_end/nudge_time and IANA timezone (format "
            "checks); the 200 answer's body"),
    "R28": ("partial", "another user's habit (GET, DELETE, progress, history, check-in list), "
                       "nudge (dismiss) and device (DELETE) answers 404 and writes nothing; "
                       "anonymous answers 401",
            "endpoints that need a request body (PATCH habit, POST check-in, batch, DELETE "
            "check-in with two path ids): an ownership form carries no request body; the "
            "not_found code"),
    "R31": ("partial", "platform in {ios, android}; push_token 1..4096 characters",
            "timezone must be an IANA zone (format); the 201 body"),
    "R33": ("partial", "DELETE /v1/devices/{id}: the owner 204, another user 404 unchanged, anon 401",
            "that the row is gone afterwards (an accepted-outcome db count on the owned row is "
            "not stated)"),
    "R37": ("partial", "devices.platform is ios or android (a stored-value rule, invariant only)",
            "the rest is a schema declaration (columns, unique push_token)"),
    "R39": ("partial", "habits.version >= 1 and habits.period in {week, month, year} (invariants)",
            "the rest is a schema declaration (columns, defaults, nullability)"),
    "R42": ("partial", "nudges.kind and nudges.delivery are within their listed values (invariants)",
            "delivery_reason's values (nullable; null is outside the listed set), one row per "
            "(habit_id, for_date) with no refusing endpoint"),
    "R51": ("partial", "name 1..100, description <= 500, period in {week, month, year}, target_count "
                       ">= 1 and <= 7/31/366 for a week/month/year witness, each refused 422",
            "'not only whitespace' (a pattern over the value); the target's upper bound depends on "
            "another field (period), stated once per period through the witness"),
    "R55": ("partial", "a second non-deleted habit with the same name for the same user is refused 409",
            "case-insensitive comparison (Run vs run) and the rename path (PATCH name)"),
    "R56": ("full", "at most 50 active (non-archived, non-deleted) habits per user; the 51st "
                    "create is refused 409, the 50th accepted", "(the habit_limit code)"),
    "R60": ("partial", "PATCH applies creation's name and weekly target bounds (422)",
            "the version increment (a computed stored value), description/start/end validation "
            "on PATCH, the 200 body"),
    "R62": ("partial", "a PATCH naming version 2 against a habit at version 1 is refused 409, "
                       "unchanged",
            "the comparison with the stored version is stated through the given row's version "
            "(1); the 'current' body"),
    "R69": ("partial", "restoring (archived: false) with 50 active habits is refused 409; with 49 it "
                       "is accepted",
            "the archive/restore effect itself (archived stored as sent: effect_value)"),
    "R77": ("full", "note <= 280 characters, longer is 422 with nothing stored", ""),
    "R78": ("full", "one non-deleted check-in per (habit, date); another is refused 409", ""),
    "R86": ("partial", "?limit= 1..200 on GET /v1/habits (both ends) and on a habit's check-in list",
            "a non-numeric limit, the default 50, cursors (response_shape)"),
    "R92": ("partial", "sync ?limit= 1..200", "a non-numeric limit, the default 100"),
    "R137": ("partial", "GET /v1/nudges ?limit= at most 200",
             "the active-nudge filter (today's, undismissed, non-archived: time and "
             "response_shape), ordering, the default 50"),
    "R147": ("partial", "history ?limit= 1..100", "a non-numeric limit, the default 12"),
}

NE = {}


def ne(cat, reason, *rules):
    for r in rules:
        assert r not in NE and r not in FORMED, r
        NE[r] = (cat, reason)


ne("other", "a rule over the whole route table (every path under /v1) and one public route; a form "
   "names one endpoint and a row or value", "R3")
ne("response_shape", "the error body's shape (code, message, field)", "R4")
ne("other", "universal over every body and query value of every route; each bound form "
   "instantiates it for one field", "R5")
ne("other", "a request header (X-Client-Version) and a version comparison; a step cannot send "
   "headers", "R6")
ne("other", "universal over every 4xx answer of every route, with an exception (refresh reuse); "
   "each form's refused db states it for its own request", "R7")
ne("effect_value", "the stored email is the request's email lower-cased; the 201 body", "R8")
ne("cross_table", "registering writes a second table's row (notification_prefs) with defaults",
   "R11")
ne("response_shape", "no response contains the password, its hash or a token hash; the hash is "
   "bcrypt (not observable)", "R12")
ne("response_shape", "the login answer's shape (token_type, expires_in)", "R13")
ne("other", "JWT algorithm, key and claims: not observable by a step (unchecked)", "R15")
ne("time", "a 30-day validity and the token's entropy and digest", "R16")
ne("other", "a login revokes the installation's earlier tokens: a write to other rows, not a "
   "refusal", "R17")
ne("time", "a live token is one not expired (a validity window); rotation writes two rows", "R18")
ne("cross_request", "a token used twice: the second use revokes the session", "R20")
ne("other", "authentication of every route except three; ownership forms cover the anonymous "
   "case only for the endpoints they name", "R21")
ne("time", "access-token expiry after 15 minutes of the app's clock", "R22")
ne("cross_table", "logout revokes refresh tokens and deletes the device row of the session",
   "R23")
ne("response_shape", "the /v1/me body's shape", "R24")
ne("cross_table", "account deletion removes rows of seven tables", "R26")
ne("response_shape", "lists return only the caller's rows (the trace links R27 to list "
   "endpoints); an ownership form needs one addressed row", "R27")
ne("rate", "120 requests per clock minute per user", "R29")
ne("rate", "a sync or batch counts as one request towards the rate limit", "R30")
ne("other", "a known push_token moves to the caller: an update of another user's row, not a "
   "refusal", "R32")
ne("cross_table", "a device's timezone never changes the users row", "R34")
ne("other", "a schema declaration (columns, unique email, change_seq starts at 0); no "
   "condition with a trigger", "R35", "R36", "R38", "R40")
ne("other", "a schema declaration; its one-check-in-per-day count is R78's form (R41 states no "
   "refusing request)", "R41")
ne("other", "date and instant formats, malformed values answer 422 (a pattern over the value)",
   "R43")
ne("time", "the clock source", "R44")
ne("time", "today in the user's timezone", "R45")
ne("time", "calendar periods and their lengths", "R46")
ne("time", "a timezone change keeps check-in dates", "R47")
ne("time", "the target repeats per period between start and end", "R48")
ne("response_shape", "the create request and the 201 body's shape", "R49")
ne("time", "start_date defaults to today", "R50")
ne("time", "end_date >= start_date: a date compared with another field's date", "R52")
ne("cross_request", "a retried create (same id, same content) answers 200 and writes nothing",
   "R53")
ne("other", "an id conflict is judged by comparing the request's content with a stored row of "
   "any user", "R54")
ne("cross_table", "creating a habit writes its first habit_targets row (a second table)", "R57")
ne("response_shape", "the list's rows, order and the include_archived filter", "R58")
ne("other", "a deleted habit (deleted_at, not a machine state) answers 404", "R59")
ne("other", "the presence of a key (version missing) decides the answer, not its value", "R61")
ne("other", "the presence of a key (period) decides the answer, not its value", "R63")
ne("effect_value", "null in a PATCH clears the stored value", "R64")
ne("cross_table", "a target change writes a habit_targets row for the current period (and time)",
   "R65")
ne("cross_request", "the new target applies from the next request on", "R66")
ne("time", "start_date can change only before today reaches it", "R67")
ne("cross_table", "an end_date is checked against the habit's check-ins", "R68")
ne("cross_table", "a soft delete cascades to check-ins and nudges", "R70")
ne("effect_value", "the stored change_seq is the owner's incremented counter", "R71")
ne("response_shape", "the check-in request and 201 body's shape", "R72")
ne("time", "a date after the user's today", "R73")
ne("time", "a date outside start_date..end_date of the parent habit", "R74")
ne("time", "a date more than 60 days before today", "R75")
ne("time", "the priority order of three date rules", "R76")
ne("cross_request", "a retried check-in answers 200; a conflicting id 409", "R79")
ne("cross_table", "a check-in write is refused by a condition on the parent habit (archived)",
   "R80")
ne("response_shape", "order, the from/to filters; from after to is a comparison of two params",
   "R81")
ne("cross_table", "a check-in of another habit or already deleted answers 404 (two rows)", "R82")
ne("other", "1 to 100 items: the length of a list, not a text length", "R83")
ne("cross_request", "a batch is a sequence of creates processed in order", "R84", "R85")
ne("response_shape", "has_more and next_cursor", "R87")
ne("other", "a cursor the app did not issue: validity of an opaque signed value", "R88", "R94")
ne("response_shape", "the sync answer: changes, order, cursor", "R89", "R90", "R91", "R93")
ne("response_shape", "the progress body's shape", "R95")
ne("time", "progress over the current calendar period and today", "R96", "R97", "R99", "R100",
   "R101", "R106", "R107", "R108", "R109", "R110", "R111", "R112", "R113")
ne("aggregate", "computed arithmetic over counted rows (pro-rating, projection, rates, rounding)",
   "R98", "R102", "R103", "R104", "R105")
ne("response_shape", "the home body: habits with progress and today's nudges", "R114")
ne("effect_value", "a stored nudge kind/message computed from the progress status", "R115",
   "R116", "R117", "R118", "R119", "R120")
ne("time", "no nudge for a habit not started or already ended (relative to today), deleted or "
   "archived", "R121")
ne("cross_table", "a check-in write creates or rewrites a row of another table (nudges)", "R122")
ne("cross_table", "a check-in leaves the nudge's delivery unchanged: the nudge row needs its "
   "parent habit row, which a transition form cannot state (no given), and the write is on "
   "another table", "R123")
ne("background", "pending vs suppressed depends on the daily pass of the background nudger",
   "R124")
ne("cross_table", "a dismissed nudge (dismissed_at, not a machine) is not rewritten by check-in "
   "writes on another table; not pushed by the pass", "R125")
ne("background", "the nudger's schedule and daily pass", "R126", "R127")
ne("background", "a delivery rule of the daily pass (the only trigger of Nudge.delivery edges is "
   "the background nudger)", "R128", "R129", "R130", "R131", "R132", "R133", "R134")
ne("rate", "at most one push per habit per day and three per user per day", "R135")
ne("external", "pushes go only through the PushSender service", "R136")
ne("cross_request", "dismissing twice: the second dismissal answers 409", "R138")
ne("response_shape", "a dismissal removes the nudge from every list and shows in sync", "R139")
ne("external", "a silent clear push to the user's other devices", "R140")
ne("external", "a failing push does not fail the dismiss (and the delivery stays: a "
   "Nudge.delivery to-null edge that cannot state the parent habit row)", "R141")
ne("external", "a 409 dismiss sends no push", "R142")
ne("external", "clear pushes do not count towards the push limit", "R143")
ne("response_shape", "the history body's shape and order", "R144")
ne("time", "past periods relative to today, start and end", "R145", "R146")
ne("time", "a habit not started yet (today before start_date) answers 409", "R148")
